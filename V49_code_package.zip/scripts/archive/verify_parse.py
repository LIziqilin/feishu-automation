# -*- coding: utf-8 -*-
"""验证parser对各种格式的解析"""
import sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.path.insert(0, '.')

from learning_system import InstructionParser

parser = InstructionParser()
tests = [
    "创建任务：第三个测试",        # 正确格式
    "✅ 已创建任务：第三个测试",    # 用户实际发的（带回执前缀）
    "新建任务：测试任务 123",
    "✅ 已创建任务：另一个测试",
]
for t in tests:
    action, data = parser.parse(t, [])
    print(f"输入: {t}")
    print(f"  → action={action}, data={data}")
    print()
