#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
本地敏感配置文件（请勿提交到GitHub）
包含：Base Token、Chat ID、lark-cli路径等
"""
import os

# 飞书多维表格配置
BASE_TOKEN = "X8N1bvN3na99dFsyu0gcU8zTnHf"
TARGET_CHAT_ID = "oc_1fe154e172ab04622b7ffa810ac172bc"

# 表ID配置
FLOW_TABLE = "tblbznzCSpPhSz93"      # 复习流水表
CARD_TABLE = "tblpLvxyYpDJgF92"      # 学习卡片表
EVENT_LOG_TABLE = "tblPreh1ipB9LQpf" # 系统事件日志表
TASK_TABLE = "tblz3H4lV7PCrBrX"      # 任务总表
KNOWLEDGE_INDEX_TABLE = "tbl0NiUFeQzH2r3n"  # 知识索引表
SYSTEM_HEALTH_TABLE = "tblxJMndPNtZ7XyG"    # 系统健康表
HEARTBEAT_TABLE = "tblJmm0ZIgqlYmyt"  # 系统心跳表
INSIGHT_TABLE = "tblaqKBl87V9C0q1"    # 洞察笔记表
QUEUE_TABLE = "tblN2nL4hP9Qz7fK"      # 自动化队列表

# lark-cli路径
LARK_CLI = r"C:\Users\Administrator\AppData\Local\hermes\node\lark-cli.cmd"
LARK_NODE_EXE = r"C:\Users\Administrator\AppData\Local\hermes\node\node.exe"
LARK_CLI_SCRIPT = r"C:\Users\Administrator\AppData\Local\hermes\node\node_modules\@larksuite\cli\scripts\run.js"

# 管理员白名单（飞书用户ID或姓名）
ADMIN_WHITELIST = [
    "ou_placeholder_admin1",
    "管理员姓名",
]

# API密钥（如需要）
DEEPSEEK_API_KEY = os.environ.get("DEEPSEEK_API_KEY", "")
COZE_API_KEY = os.environ.get("COZE_API_KEY", "")
COZE_BOT_ID = os.environ.get("COZE_BOT_ID", "")
