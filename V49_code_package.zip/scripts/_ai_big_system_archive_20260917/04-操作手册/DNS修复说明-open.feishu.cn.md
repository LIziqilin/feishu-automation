# DNS 修复说明 · open.feishu.cn 解析失败

## 问题现象（2026-08-31 发现）

向飞书 Webhook 推送消息失败，报错：
- `getaddrinfo failed` / `未能解析此远程名称: 'open.feishu.cn'`
- 同时 baidu.com 等正常，`feishu.cn`/`www.feishu.cn` 也能解析，**唯独 `open.feishu.cn` 解析不出 IP**

## 根因

本机使用的 DNS 服务器（路由器 192.168.1.1 / 192.168.0.1）无法正确解析 `open.feishu.cn` 的 CNAME 链：
`open.feishu.cn → open.feishu.cn.bytedns1.com → open.feishu.cn.w.cdngslb.com`，导致最终没有 A 记录返回。
用公共 DNS（223.5.5.5 / 119.29.29.29）测试可正常解析，确认是路由器 DNS 的问题。

## 修复方法（已执行）

在 `C:\Windows\System32\drivers\etc\hosts` 末尾追加：
```
# AI大系统 DNS修复 open.feishu.cn (2026-08-31)
1.195.209.58 open.feishu.cn
1.194.30.65 open.feishu.cn
```
然后刷新 DNS 缓存：`ipconfig /flushdns`

备份文件：`C:\Windows\System32\drivers\etc\hosts.bak_20260831`

## 验证结果

- ✅ `open.feishu.cn` 已解析到 1.195.209.58
- ✅ Webhook 通过域名推送成功（code:0）
- ✅ 监控脚本（monitor.py）告警链路恢复

## 日后若再出现同样问题

1. 测试：`Resolve-DnsName open.feishu.cn`，若解析不出 IP → hosts 失效或 IP 变更
2. 获取新 IP：`nslookup open.feishu.cn 223.5.5.5` 末尾的 IP 列表
3. 用记事本以管理员身份打开 hosts，把旧 IP 换成新 IP（保留 # 注释行）
4. `ipconfig /flushdns` 后重试推送
5. 若想彻底解决（可选）：把网络适配器 DNS 改为公共 DNS 223.5.5.5 / 119.29.29.29（设置 → 网络 → 适配器属性 → IPv4 → DNS）
