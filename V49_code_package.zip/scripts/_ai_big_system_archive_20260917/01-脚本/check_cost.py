# -*- coding: utf-8 -*-
"""
============================================================
 check_cost.py - 个人AI系统 · 成本/余额查询脚本（P3 成本审计用）
============================================================
作用：
  一键查询 DeepSeek / 硅基流动 的余额与可用状态，
  供 P3「每月成本审计与自动化清理」工作流调用（经 Hermes /cost_check），
  也可本地命令行直接运行。

用法（命令行）：
  python check_cost.py           # 输出 JSON 成本快照
  python check_cost.py -v        # 输出人类可读格式

输出字段：
  deepseek.balance_cny    DeepSeek 余额（元）
  deepseek.available      账户是否可用
  siliconflow.available   硅基流动 Key 是否有效（模型列表可访问）
  siliconflow.note        余额接口已废弃说明
  check_time              查询时间

安全：API Key 从 ai_config.py 读取，不会打印明文 Key。
"""

import sys
import json
import urllib.request
import urllib.error
from datetime import datetime

import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import ai_config as cfg


def api_get(url, key):
    """GET 请求，返回 (http状态, JSON或错误文本)"""
    req = urllib.request.Request(url, method="GET")
    req.add_header("Authorization", "Bearer " + key)
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            body = r.read().decode("utf-8")
            try:
                return r.status, json.loads(body)
            except Exception:
                return r.status, {"_raw": body}
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8")[:300]
        return e.code, {"_http_error": e.code, "_body": body}
    except Exception as e:
        return "ERR", {"_error": str(e)}


def check_deepseek():
    """查 DeepSeek 余额"""
    try:
        status, data = api_get(cfg.DEEPSEEK_BALANCE_URL, cfg.DEEPSEEK_API_KEY)
        if status == 200 and isinstance(data, dict):
            infos = data.get("balance_infos", [])
            total = None
            for bi in infos:
                if bi.get("currency") == "CNY":
                    total = bi.get("total_balance")
                    break
            return {
                "available": data.get("is_available", False),
                "balance_cny": total,
                "detail": data,
            }
        return {"available": False, "balance_cny": None, "error": data}
    except Exception as e:
        return {"available": False, "balance_cny": None, "error": str(e)}


def check_siliconflow():
    """验证硅基流动 Key 可用性（余额接口已废弃，只能验证可用性）"""
    try:
        status, data = api_get(cfg.SILICONFLOW_MODELS_URL, cfg.SILICONFLOW_API_KEY)
        if status == 200 and isinstance(data, dict) and "data" in data:
            return {"available": True, "model_count": len(data["data"])}
        return {"available": False, "error": data}
    except Exception as e:
        return {"available": False, "error": str(e)}


if __name__ == "__main__":
    ds = check_deepseek()
    sf = check_siliconflow()
    result = {
        "check_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "deepseek": {
            "available": ds.get("available"),
            "balance_cny": ds.get("balance_cny"),
        },
        "siliconflow": {
            "available": sf.get("available"),
            "model_count": sf.get("model_count"),
            "note": "余额查询接口已废弃（官方410），余额请登录 cloud.siliconflow.cn 控制台查看",
        },
    }
    # 写本地成本日志（追加）
    try:
        log_path = os.path.join(os.path.dirname(cfg.MONITOR_LOG) if os.path.dirname(cfg.MONITOR_LOG) else ".", "cost_log.jsonl")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(result, ensure_ascii=False) + "\n")
    except Exception:
        pass

    verbose = "-v" in sys.argv
    if verbose:
        print("成本快照时间:", result["check_time"])
        print("DeepSeek 可用:", "是" if ds.get("available") else "否",
              "| 余额(CNY):", ds.get("balance_cny"))
        print("硅基流动 可用:", "是" if sf.get("available") else "否",
              "| 模型数:", sf.get("model_count"))
        print("硅基流动备注:", result["siliconflow"]["note"])
    else:
        print(json.dumps(result, ensure_ascii=False))
