# -*- coding: utf-8 -*-
"""从 .doc (OLE2) 提取正文文本（启发式：WordDocument 流 UTF-16 字符串提取）"""
import sys, re, struct
import olefile

def extract_doc(path, out_path):
    ole = olefile.OleFileIO(path)
    # 列出所有流
    streams = ole.listdir()
    print("流:", [ "/".join(s) for s in streams ])
    # WordDocument 流
    if ole.exists("WordDocument"):
        data = ole.openstream("WordDocument").read()
        print("WordDocument 长度:", len(data))
    else:
        data = b""
    # 尝试读取 0Table 或 1Table 的文本（正文文本在 WordDocument 流中，piece table 复杂）
    # 启发式：从 WordDocument 流提取 UTF-16LE 可读片段
    text_parts = []
    # 方式1：按 UTF-16LE 解码整段，过滤可读
    try:
        utf16 = data.decode("utf-16-le", errors="ignore")
        # 提取中英文连续片段
        for m in re.finditer(r"[\u4e00-\u9fff\u3000-\u303f\uff00-\uffefA-Za-z0-9，。：；、（）“”‘’！？\s\n\.\,\(\)\-\d%]+", utf16):
            s = m.group().strip()
            if len(s) >= 2 and (re.search(r"[\u4e00-\u9fff]", s) or len(s) >= 4):
                text_parts.append(s)
    except Exception as e:
        print("utf16 err:", e)
    # 方式2：直接 ASCII/GBK 提取（某些 doc 用 8-bit）
    try:
        for m in re.finditer(rb"[\x20-\x7e\x80-\xff]{6,}", data):
            s = m.group().decode("gbk", errors="ignore")
            if len(s) >= 4:
                text_parts.append(s)
    except Exception:
        pass
    # 去重保序
    seen = set()
    out = []
    for s in text_parts:
        if s not in seen and s:
            seen.add(s)
            out.append(s)
    text = "\n".join(out)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(text)
    print("提取 {} 片段，{:.0f} 字符 → {}".format(len(out), len(text), out_path))
    ole.close()

if __name__ == "__main__":
    extract_doc(r"D:\AI-Tools\feishu\飞书大系统方案\整体方案.doc", r"D:\AI\AI大系统\05-备份\方案_整体方案.txt")
    extract_doc(r"D:\AI-Tools\feishu\飞书大系统方案\最终落地方案\大系统2.0版本.doc", r"D:\AI\AI大系统\05-备份\方案_大系统2.0.txt")
