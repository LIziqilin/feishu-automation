# -*- coding: utf-8 -*-
"""
============================================================
 analyze_run_logs.py - 个人AI系统 · 运行日志统计（P3 数据源）
============================================================
作用：
  拉取飞书「运行日志表」的真实数据，统计各流程调用量、成功率、异常数，
  输出 JSON 供 P3「Prompt月度调优」和「成本审计」工作流使用，
  也可命令行直接查看。

用法（在 D:\\AI\\AI大系统\\01-脚本 目录）：
  python analyze_run_logs.py            # 输出 JSON
  python analyze_run_logs.py -v         # 人类可读

依赖：
  - lark-cli（已安装，读取飞书多维表格）
  - 运行日志表（base FDxjb8JtvaZa72sUp0tcygVVn0y / 表 tbl3hkFkgrSxlvUx）
"""

import sys
import os
import json
import subprocess
from datetime import datetime

BASE_TOKEN = "FDxjb8JtvaZa72sUp0tcygVVn0y"
TABLE_ID = "tbl3hkFkgrSxlvUx"


def fetch_records():
    """用 lark-cli 拉取运行日志表全部记录（lark-cli 单页上限 200）"""
    cmd = ["lark-cli", "base", "+record-list",
           "--base-token", BASE_TOKEN,
           "--table-id", TABLE_ID,
           "--limit", "200",
           "--as", "user"]
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", timeout=90)
    out = r.stdout
    if not out:
        raise RuntimeError(f"lark-cli 无输出，可能出错：{r.stderr[:300]}")
    # 解析 lark-cli 表格输出：跳过空行和表头分隔行
    rows = []
    for line in out.splitlines():
        line = line.strip()
        if not line or line.startswith("| _record_id") or line.startswith("| ---"):
            continue
        if not line.startswith("|"):
            continue
        cells = [c.strip() for c in line.strip("|").split("|")]
        if len(cells) >= 6:
            rows.append(cells)
    return rows


def parse_select(cell):
    """把 ['正常'] 或 '正常' 转成字符串；空返回 None"""
    if not cell or cell == "—":
        return None
    s = cell.strip("[]")
    s = s.strip("\"'")
    return s if s else None


def analyze(rows):
    """统计：总记录、各流程调用次数/成功率/异常、近7天活动"""
    total = len(rows)
    flow_stat = {}   # 流程名 -> {total, ok, err}
    component_stat = {}
    recent = []      # 今天有内容的记录
    today = datetime.now().strftime("%Y-%m-%d")
    today_count = 0

    for cells in rows:
        # 列顺序：_record_id 流程名 处理方式 状态 组件 错误信息 时间
        rec_id, flow, handle, status, comp, err, ts = cells[0], cells[1], cells[2], cells[3], cells[4], cells[5], cells[6]
        flow = parse_select(flow)
        comp = parse_select(comp)
        status = parse_select(status)
        if ts and ts.startswith(today):
            today_count += 1

        # 跳过空记录（无流程名无组件）
        if not flow and not comp:
            continue

        f = flow_stat.setdefault(flow or "未命名", {"total": 0, "ok": 0, "err": 0})
        f["total"] += 1
        if status == "异常":
            f["err"] += 1
        elif status == "正常" or status == "已恢复":
            f["ok"] += 1

        if comp:
            c = component_stat.setdefault(comp, 0)
            component_stat[comp] = c + 1

        if handle:
            recent.append({"flow": flow, "handle": handle, "ts": ts, "status": status})

    # 计算成功率
    flow_summary = []
    for name, st in flow_stat.items():
        rate = round(st["ok"] / st["total"] * 100, 1) if st["total"] else 0
        flow_summary.append({
            "flow": name, "total": st["total"], "ok": st["ok"], "err": st["err"],
            "success_rate": rate
        })

    return {
        "report_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "total_records": total,
        "today_records": today_count,
        "flow_stat": flow_summary,
        "component_stat": component_stat,
        "recent_activity": recent[-20:],  # 最近20条有内容的记录
    }


def main():
    rows = fetch_records()
    result = analyze(rows)
    if "-v" in sys.argv:
        print("=" * 50)
        print(" 系统运行日志统计")
        print(f" 报告时间：{result['report_time']}")
        print(f" 总记录数：{result['total_records']} ｜ 今日记录：{result['today_records']}")
        print("=" * 50)
        print("\n【各流程统计】")
        if result["flow_stat"]:
            for f in result["flow_stat"]:
                flag = "✅" if f["success_rate"] >= 95 else ("⚠️" if f["success_rate"] > 0 else "❌")
                print(f"  {flag} {f['flow']}: {f['total']}次 成功{f['ok']} 异常{f['err']} 成功率{f['success_rate']}%")
        else:
            print("  （暂无有效流程记录）")
        print("\n【各组件调用】")
        for comp, cnt in result["component_stat"].items():
            print(f"  {comp}: {cnt}次")
    else:
        # 输出单行紧凑 JSON（供工作流/接口解析，避免多行导致解析失败）
        print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
