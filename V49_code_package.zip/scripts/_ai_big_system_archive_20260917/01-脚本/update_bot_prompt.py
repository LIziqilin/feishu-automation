# -*- coding: utf-8 -*-
"""
P3「Prompt 动态调优」脚本 —— 安全更新 Coze 主 Bot 的人设与回复逻辑
=====================================================================
用法（在 D:\\AI\\AI大系统\\01-脚本 目录下）：
  # 1) 只读：查看当前 Prompt（并自动备份到 05-备份）
  python update_bot_prompt.py --get

  # 2) 更新：用文本文件内容替换 Bot 的 Prompt（需加 --yes 确认，更新前自动备份旧版）
  python update_bot_prompt.py --set-file "新prompt文件.txt" --yes

  # 3) 回滚：把某次备份文件内容还原为当前 Prompt
  python update_bot_prompt.py --set-file "05-备份\\coze_bot_prompt_基线_20260831.md" --yes

安全设计：
  - 不传 --yes 不会执行任何写入
  - 每次写入前自动把当前 Prompt 备份为 coze_prompt_backup_<时间戳>.md
  - 写入后回读验证是否生效
"""

import sys
import os
import json
import time
import urllib.request
import urllib.error

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import ai_config as cfg
except Exception as e:
    print("[错误] 无法读取 ai_config.py:", e)
    sys.exit(1)

TOKEN = getattr(cfg, "COZE_API_TOKEN", "")
BOT_ID = getattr(cfg, "COZE_BOT_ID", "")
API = "https://api.coze.cn"
BACKUP_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "05-备份")


def _req(path, method="GET", payload=None):
    req = urllib.request.Request(API + path, method=method)
    req.add_header("Authorization", "Bearer " + TOKEN)
    req.add_header("Content-Type", "application/json")
    if payload is not None:
        req.data = json.dumps(payload).encode("utf-8")
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8")
        print("[HTTP错误]", e.code, body[:300])
        sys.exit(1)


def get_prompt():
    d = _req(f"/v1/bots/{BOT_ID}")
    if d.get("code") != 0:
        print("[错误]", d.get("msg"))
        sys.exit(1)
    return d["data"].get("prompt_info", {}).get("prompt", "")


def backup(prompt, tag="backup"):
    os.makedirs(BACKUP_DIR, exist_ok=True)
    name = f"coze_prompt_{tag}_{time.strftime('%Y%m%d_%H%M%S')}.md"
    path = os.path.join(BACKUP_DIR, name)
    with open(path, "w", encoding="utf-8") as f:
        f.write(prompt + "\n")
    print("[备份] 已保存到", os.path.abspath(path))
    return path


def set_prompt(new_prompt):
    old = get_prompt()
    backup(old, "before_update")
    print("[更新] 正在更新 Bot Prompt ...")
    d = _req(f"/v1/bots/{BOT_ID}", "PATCH", {"prompt_info": {"prompt": new_prompt}})
    if d.get("code") != 0:
        print("[失败]", d.get("msg"))
        sys.exit(1)
    # 回读验证
    now = get_prompt()
    if now.strip() == new_prompt.strip():
        print("[验证] 回读一致，更新成功 ✅")
    else:
        print("[警告] 回读内容与提交不一致，请人工核对！")


def main():
    args = sys.argv[1:]
    if not args or "--get" in args:
        if "--get" in args:
            p = get_prompt()
            backup(p, "get_snapshot")
            print("[当前 Prompt 内容]")
            print("=" * 60)
            print(p)
            print("=" * 60)
        else:
            print(__doc__)
        return

    new_prompt = None
    if "--set-file" in args:
        i = args.index("--set-file")
        fp = args[i + 1]
        if not os.path.exists(fp):
            print("[错误] 文件不存在:", fp)
            sys.exit(1)
        with open(fp, "r", encoding="utf-8") as f:
            new_prompt = f.read()
    elif "--set" in args:
        i = args.index("--set")
        new_prompt = args[i + 1]

    if new_prompt is None:
        print("[错误] 请用 --set-file <文件> 或 --set <文本> 提供新 Prompt")
        return

    if "--yes" not in args:
        print("[提示] 这是真实写入操作（会修改你的 Coze Bot 行为）。")
        print("       确认执行请追加参数 --yes。本次未执行。")
        print("[预览] 新 Prompt 长度:", len(new_prompt), "字符")
        return

    set_prompt(new_prompt)


if __name__ == "__main__":
    main()
