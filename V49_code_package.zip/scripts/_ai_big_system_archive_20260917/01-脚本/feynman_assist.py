# -*- coding: utf-8 -*-
"""
============================================================
 feynman_assist.py - 个人AI系统 · 费曼学习辅助（P1 费曼工作流本地实现）
============================================================
作用：按需运行（学到新知识点时用），一条命令生成完整费曼四步：
  1. 大白话复述（无术语，≤200字）
  2. 一句话定义 + 生活类比（定义≤30字）
  3. 卡壳点提示（检查自己哪里讲不清）
  4. 口述验证脚本（1分钟脱稿提纲）
并把成果写入 Obsidian 费曼目录 + 学习打卡表。

用法（在 D:\\AI\\AI大系统\\01-脚本 目录）：
  python feynman_assist.py "CAPEX" "酒店工程" "资本性支出"     # 知识点 科目 原文/背景
  python feynman_assist.py "什么是倒置购房贷" "财商"          # 只有知识点和科目
  python feynman_assist.py --list                            # 列出已完成费曼的笔记
"""

import sys
import os
import json
import urllib.request
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import ai_config as cfg
except Exception:
    cfg = None
from daily_report import get_tenant_token, deepseek_chat, fmt_cell

STUDY_TABLE = "tbl0tfLmDWMD0o77"     # 学习打卡表
FEYNMAN_DIR = "D:/AI/finished Brain/04-思维方法库/费曼输出"


def write_run_log(msg):
    try:
        log_path = os.path.join(r"D:\AI\AI大系统\05-备份", "feynman_assist.log")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write("[{}] {}\n".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg))
    except Exception:
        pass


def resolve_single_select(token, table_id, field_name, value):
    """把期望的单选值映射到表内真实选项（兼容选项名带空格的情况）"""
    try:
        url = "https://open.feishu.cn/open-apis/bitable/v1/apps/{}/tables/{}/fields?page_size=100".format(
            "FDxjb8JtvaZa72sUp0tcygVVn0y", table_id)
        req = urllib.request.Request(url, headers={"Authorization": "Bearer " + token})
        with urllib.request.urlopen(req, timeout=15) as resp:
            d = json.loads(resp.read().decode("utf-8"))
        for it in d.get("data", {}).get("items", []):
            if it.get("field_name") == field_name and it.get("type") == 3:
                for o in it.get("property", {}).get("options", []):
                    oname = o.get("name", "")
                    if oname.strip() == value:
                        return oname
                # 无匹配：若选项列表非空且 value 为空，返回空；否则返回原值
                return value
        return value
    except Exception:
        return value


def add_study_record(subject, topic, feynman_text):
    """写入学习打卡表（费曼输出列）"""
    try:
        token = get_tenant_token()
        from datetime import datetime
        ts_ms = int(datetime.now().timestamp() * 1000)
        real_subject = resolve_single_select(token, STUDY_TABLE, "科目", subject)
        real_check = resolve_single_select(token, STUDY_TABLE, "费曼检验结果", "未检验")
        fields = {
            "科目": real_subject,
            "学习主题": topic,
            "费曼输出": feynman_text[:500],
            "费曼检验结果": real_check,
            "日期": ts_ms,
        }
        url = "https://open.feishu.cn/open-apis/bitable/v1/apps/{}/tables/{}/records".format(
            "FDxjb8JtvaZa72sUp0tcygVVn0y", STUDY_TABLE)
        payload = json.dumps({"fields": fields}, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(url, data=payload,
                                     headers={"Content-Type": "application/json",
                                              "Authorization": "Bearer " + token}, method="POST")
        with urllib.request.urlopen(req, timeout=20) as resp:
            d = json.loads(resp.read().decode("utf-8"))
        return d.get("code") == 0
    except Exception as e:
        print("[!] 写学习打卡表失败：", str(e)[:80])
        return False


def main():
    args = sys.argv[1:]
    if not args or "--help" in args or "-h" in args:
        print(__doc__)
        return

    if "--list" in args:
        d = os.path.join(FEYNMAN_DIR.replace("/", "\\"))
        if os.path.isdir(d):
            for fn in sorted(os.listdir(d)):
                if fn.endswith(".md"):
                    print("·", fn)
        else:
            print("费曼目录不存在：", d)
        return

    topic = args[0]
    subject = args[1] if len(args) > 1 else "认知升级"
    source = args[2] if len(args) > 2 else topic

    print("=== 费曼学习辅助：{}（{}）===".format(topic, subject))
    prompt = (
        "你是费曼学习法教练。对知识点「{}」执行费曼四步，原文/背景：{}。\n"
        "输出 4 个部分：\n"
        "1.【第一步·大白话复述】用纯口语、无专业术语地解释它，≤200字（假设对方是初中生）\n"
        "2.【第二步·一句话定义+类比】1句核心定义（≤30字）+ 1个生活化类比\n"
        "3.【第三步·卡壳自查】指出复述中最可能讲不清/遗漏的 2-3 个点，给出针对性补学建议\n"
        "4.【第四步·口述提纲】1分钟脱稿口述的分点提纲（4-6个要点）\n"
        "语言简洁直接，不要寒暄。".format(topic, source)
    )
    print("=== 生成费曼输出（DeepSeek）... ===")
    result = deepseek_chat(prompt, max_tokens=1200)
    print("=" * 50)
    print(result)
    print("=" * 50)

    # 写入 Obsidian 费曼目录
    fpath = ""
    try:
        target = FEYNMAN_DIR.replace("/", "\\")
        os.makedirs(target, exist_ok=True)
        fname = "费曼-{}.md".format(topic.replace(" ", "_").replace("/", "-"))
        fpath = os.path.join(target, fname)
        with open(fpath, "w", encoding="utf-8") as f:
            f.write("# 费曼：{}\n\n> 科目：{} ｜ 生成时间：{}\n\n{}".format(
                topic, subject, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), result))
        print("[OK] 已写入 Obsidian：", fpath)
    except Exception as e:
        print("[!] 写 Obsidian 失败：", str(e)[:80])

    # 写学习打卡表
    ok = add_study_record(subject, topic, result[:200])
    print("[OK] 已写入学习打卡表" if ok else "[!] 学习打卡表写入失败")

    write_run_log("费曼：{}（{}）｜归档={}｜打卡={}".format(topic, subject, fpath, ok))


if __name__ == "__main__":
    main()
