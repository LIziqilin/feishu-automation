# -*- coding: utf-8 -*-
"""
============================================================
 prompt_tune.py - 个人AI系统 · 每月 Prompt 动态调优（P3 Prompt 调优工作流本地实现）
============================================================
作用（每月2号 14:00 计划任务自动运行）：
  1. 读取当前 Coze 主 Bot 的系统 Prompt（复用 update_bot_prompt.py）
  2. 统计上月系统运行情况（运行日志表）作为调优依据
  3. 调用 DeepSeek 生成优化方案（新 Prompt 全文 + 修改说明）
  4. 推送飞书 → 等待你确认（不自动更新！确认后执行 update_bot_prompt.py --set-file 生效）

用法（在 D:\\AI\\AI大系统\\01-脚本 目录）：
  python prompt_tune.py            # 生成优化方案+推送
  python prompt_tune.py --dry      # 只打印不推送
  python prompt_tune.py --webhook <url>   # 推送到指定群

安全：方案需人工确认后才更新主 Bot，避免误改导致逻辑倒退。
"""

import sys
import os
import json
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import ai_config as cfg
except Exception:
    cfg = None
from daily_report import get_tenant_token, fetch_records, fmt_cell, deepseek_chat, push_feishu
from feishu_common import write_run_log_record as _write_run_log_record
import update_bot_prompt as ubp

RUN_LOG_TABLE = "tbl3hkFkgrSxlvUx"


def write_run_log(msg):
    try:
        log_path = os.path.join(r"D:\AI\AI大系统\05-备份", "prompt_tune.log")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write("[{}] {}\n".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg))
    except Exception:
        pass


def _ts_date(ts):
    try:
        return datetime.fromtimestamp(int(ts) / 1000).strftime("%Y-%m-%d")
    except Exception:
        return str(ts)[:10]


def month_run_stats(token):
    """统计上月运行日志：各流程调用数/成功率，作为调优数据依据"""
    records = fetch_records(RUN_LOG_TABLE, token)
    now = datetime.now()
    first = now.replace(day=1)
    lm_end = first - timedelta(days=1)
    lm_start = lm_end.replace(day=1)
    start_s, end_s = lm_start.strftime("%Y-%m-%d"), lm_end.strftime("%Y-%m-%d")
    stats = {}
    for rec in records:
        fields = rec.get("fields", {})
        flow = fmt_cell(fields.get("流程名", "未知"))
        status = fmt_cell(fields.get("状态", ""))
        d = _ts_date(fmt_cell(fields.get("时间", "")))
        if not d or not (start_s <= d <= end_s):
            continue
        s = stats.setdefault(flow, {"count": 0, "ok": 0})
        s["count"] += 1
        if status == "正常":
            s["ok"] += 1
    return stats


def main():
    dry = "--dry" in sys.argv
    webhook = None
    if "--webhook" in sys.argv:
        webhook = sys.argv[sys.argv.index("--webhook") + 1]

    now = datetime.now()
    first = now.replace(day=1)
    lm_end = first - timedelta(days=1)
    ym = "{}年{}月".format(lm_end.strftime("%Y"), lm_end.strftime("%m"))
    print("=== Prompt 动态调优（依据：{} 运行情况）===".format(ym))

    # 1. 读取当前主 Bot Prompt
    try:
        cur_prompt = ubp.get_prompt()
    except Exception as e:
        cur_prompt = None
        print("[!] 读取主 Bot Prompt 失败：", str(e)[:80])
    print("  当前 Prompt 长度:", len(cur_prompt) if cur_prompt else 0, "字符")

    # 2. 统计上月运行情况
    token = get_tenant_token()
    stats = month_run_stats(token)
    run_lines = "\n".join("· {}：{} 次调用，成功率 {:.0%}".format(
        f, s["count"], s["ok"] / s["count"] if s["count"] else 0)
        for f, s in sorted(stats.items(), key=lambda x: -x[1]["count"])) or "（上月无运行日志）"
    print("  上月流程调用情况:\n" + run_lines)

    # 3. DeepSeek 生成优化方案
    prompt = (
        "你是 AI 助手 Prompt 优化专家。基于以下信息优化 Coze 主 Bot 的系统 Prompt。\n"
        "要求：\n"
        "1. 完整保留原 Prompt 的核心职责与意图识别规则\n"
        "2. 针对高频调用场景优化回复逻辑与输出格式\n"
        "3. 修正负向反馈集中的问题，补充对应约束规则\n"
        "4. 强化用户偏好的表达风格（专业、简洁、结构化、按钮级）\n"
        "输出两部分：\n"
        "【新Prompt全文】完整的优化后 Prompt\n"
        "【修改说明】逐条列出修改点、修改原因\n\n"
        "=== 当前主 Bot Prompt ===\n{}\n\n"
        "=== 上月系统运行情况 ===\n{}\n\n"
        "如果原 Prompt 已是通用模板且信息有限，请基于个人AI助理定位（查任务/查学习/知识检索/个人助理）给出更贴合个人使用的优化版。".format(
            cur_prompt[:3000] if cur_prompt else "（读取失败，请基于个人AI助理定位生成）",
            run_lines)
    )
    print("=== 生成优化方案（DeepSeek）... ===")
    result = deepseek_chat(prompt, max_tokens=2500)

    report = (
        "🔧 【Prompt 月度优化方案】{}\n\n{}".format(ym, result)
    )
    report += (
        "\n\n—————————\n"
        "⚠️ 请确认是否更新主 Bot Prompt？\n"
        "· 回复「确认更新」→ 我将用 update_bot_prompt.py 应用新 Prompt（先备份旧版）\n"
        "· 回复「暂缓」→ 本次不更新\n"
        "安全说明：确认前会先备份当前 Prompt 到 Obsidian 系统运维/Prompt备份，可随时回滚。"
    )
    print("=" * 50)
    print(report)
    print("=" * 50)

    if dry:
        write_run_log("dry-run：Prompt 优化方案生成完成")
        return

    # 4. 推送飞书
    ok = push_feishu(report, webhook)
    write_run_log("Prompt调优方案推送：{} ｜推送={}".format(ym, "成功" if ok else "失败"))

    # 5. 运行日志沉淀
    try:
        _write_run_log_record("Prompt调优", "本地脚本", "正常", "")
    except Exception:
        pass


if __name__ == "__main__":
    main()
