# -*- coding: utf-8 -*-
"""
============================================================
 feishu_common.py - 个人AI系统 · 公共能力模块（P2 全局异常告警 + 运行日志沉淀）
============================================================
提供两个 P2 验收强制项的本地实现：
  1. write_run_log_record()  把脚本运行结果写入飞书「运行日志表」
     → 解决 P2「每日正常产生运行日志」验收项，数据自然增长
  2. send_alert()            脚本失败时推送飞书告警（webhook）
     → 实现 P2 4.2「全局异常告警机制」的本地版

用法：
  from feishu_common import write_run_log_record, send_alert
  write_run_log_record("每日日报", "本地脚本", "正常", "")
  send_alert("【系统告警】每日日报执行失败：xxx")
"""

import sys
import os
import json
import urllib.request
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import ai_config as cfg
except Exception:
    cfg = None

BASE_TOKEN = "FDxjb8JtvaZa72sUp0tcygVVn0y"
RUN_LOG_TABLE = "tbl3hkFkgrSxlvUx"   # 运行日志表（已验证 Coze 应用可写）

_tenant_token = None


def get_tenant_token():
    """用 Coze 飞书应用凭证换取 tenant_access_token（2h 有效，进程内缓存）"""
    global _tenant_token
    if _tenant_token:
        return _tenant_token
    app_id = getattr(cfg, "COZE_FEISHU_APP_ID", "")
    app_secret = getattr(cfg, "COZE_FEISHU_APP_SECRET", "")
    req = urllib.request.Request(
        "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
        data=json.dumps({"app_id": app_id, "app_secret": app_secret}).encode("utf-8"),
        headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=20) as resp:
        d = json.loads(resp.read().decode("utf-8"))
    if d.get("code") != 0 or not d.get("tenant_access_token"):
        raise RuntimeError("获取飞书 tenant_access_token 失败: " + str(d))
    _tenant_token = d["tenant_access_token"]
    return _tenant_token


def write_run_log_record(flow_name, component="本地脚本", status="正常", error_info=""):
    """向飞书运行日志表写入一条运行记录；失败静默降级（不阻断主流程）"""
    try:
        token = get_tenant_token()
        fields = {
            "流程名": flow_name,
            "组件": component,
            "状态": status,
            "时间": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }
        if error_info:
            fields["错误信息"] = error_info
        url = "https://open.feishu.cn/open-apis/bitable/v1/apps/{}/tables/{}/records".format(
            BASE_TOKEN, RUN_LOG_TABLE)
        payload = json.dumps({"fields": fields}, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(url, data=payload,
                                     headers={"Content-Type": "application/json",
                                              "Authorization": "Bearer " + token}, method="POST")
        with urllib.request.urlopen(req, timeout=20) as resp:
            d = json.loads(resp.read().decode("utf-8"))
        return d.get("code") == 0
    except Exception:
        return False


def send_alert(text, webhook=None):
    """脚本失败时推送飞书告警（webhook）；webhook 缺省取 ai_config.FEISHU_WEBHOOK"""
    url = webhook or getattr(cfg, "FEISHU_WEBHOOK", "")
    if not url:
        return False
    try:
        payload = json.dumps({"msg_type": "text", "content": {"text": text}}, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(url, data=payload,
                                     headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=20) as resp:
            d = json.loads(resp.read().decode("utf-8"))
        return d.get("code") == 0
    except Exception:
        return False


def safe_run(flow_name, fn, *args, **kwargs):
    """包装器：执行主函数，成功写'正常'日志；异常写'异常'日志并推送告警。返回 (ok, result)"""
    try:
        result = fn(*args, **kwargs)
        write_run_log_record(flow_name, "本地脚本", "正常", "")
        return True, result
    except Exception as e:
        msg = str(e)[:200]
        write_run_log_record(flow_name, "本地脚本", "异常", msg)
        send_alert("⚠️ 【系统告警】{} 执行失败\n错误：{}".format(flow_name, msg))
        return False, None
