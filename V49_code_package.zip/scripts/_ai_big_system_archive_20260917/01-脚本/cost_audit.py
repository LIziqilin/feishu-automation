# -*- coding: utf-8 -*-
"""
============================================================
 cost_audit.py - 个人AI系统 · 每月成本审计（P3 成本审计工作流本地实现）
============================================================
作用（每月最后一天 23:00 计划任务自动运行）：
  1. 查询 DeepSeek / 硅基流动 余额与可用状态（复用 check_cost.py）
  2. 统计运行日志表过去30天各流程调用量与成功率 → 识别无效流程
  3. 预算校验：月预算红线 20 元（超支告警 / 正常通知）
  4. 生成审计报告：成本明细 + 预算执行 + 清理建议
  5. 推送飞书 + 归档 Obsidian「系统运维/成本审计」

用法（在 D:\\AI\\AI大系统\\01-脚本 目录）：
  python cost_audit.py            # 生成+推送+归档
  python cost_audit.py --dry      # 只打印不推送不写入
  python cost_audit.py --webhook <url>   # 推送到指定群
"""

import sys
import os
import json
import urllib.request
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import ai_config as cfg
except Exception:
    cfg = None
# 复用日报脚本的 API 层 + check_cost 的成本查询 + feishu_common 的日志/告警
from daily_report import get_tenant_token, fetch_records, fmt_cell, deepseek_chat, push_feishu
from feishu_common import write_run_log_record as _write_run_log_record, send_alert
import check_cost

RUN_LOG_TABLE = "tbl3hkFkgrSxlvUx"   # 运行日志表
MONTHLY_BUDGET = 20.0                 # 月预算红线（元）
EST_COST_PER_RUN = 0.02              # 每次工作流调用估算成本（元，DeepSeek 大模型）


def write_run_log(msg):
    try:
        log_path = os.path.join(r"D:\AI\AI大系统\05-备份", "cost_audit.log")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write("[{}] {}\n".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg))
    except Exception:
        pass


def _ts_date(ts):
    """把飞书时间字段（毫秒时间戳）转成 YYYY-MM-DD；非法返回 ''"""
    try:
        v = int(ts)
        return datetime.fromtimestamp(v / 1000).strftime("%Y-%m-%d")
    except Exception:
        return str(ts)[:10]


def analyze_run_logs(token):
    """统计运行日志表过去30天：各流程调用数/成功率/最近调用时间"""
    records = fetch_records(RUN_LOG_TABLE, token)
    cutoff = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d")
    stats = {}
    for rec in records:
        fields = rec.get("fields", {})
        flow = fmt_cell(fields.get("流程名", "未知"))
        status = fmt_cell(fields.get("状态", ""))
        d = _ts_date(fmt_cell(fields.get("时间", "")))
        if not d or d < cutoff:
            continue
        s = stats.setdefault(flow, {"count": 0, "ok": 0, "err": 0, "last": ""})
        s["count"] += 1
        if status == "正常":
            s["ok"] += 1
        else:
            s["err"] += 1
        if d > s["last"]:
            s["last"] = d
    return stats


def main():
    dry = "--dry" in sys.argv
    webhook = None
    if "--webhook" in sys.argv:
        webhook = sys.argv[sys.argv.index("--webhook") + 1]

    now = datetime.now()
    month = now.strftime("%Y年%m月")

    # 月末守卫：仅当月最后一天真正执行（任务注册为每月28-31日23:00，非月末跳过）
    tomorrow = (now + timedelta(days=1)).replace(day=1)
    if now.day != (tomorrow - timedelta(days=1)).day:
        print("非当月最后一天（{}日），跳过成本审计。".format(now.day))
        return

    print("=== 每月成本审计（{}）===".format(month))

    # 1. 余额与可用性
    ds = check_cost.check_deepseek()
    sf = check_cost.check_siliconflow()
    ds_bal = ds.get("balance_cny")
    print("  DeepSeek 余额:", ds_bal, "| 可用:", ds.get("available"))
    print("  硅基流动 可用:", sf.get("available"), "| 模型数:", sf.get("model_count"))

    # 2. 运行日志统计（估算成本 + 无效流程）
    token = get_tenant_token()
    stats = analyze_run_logs(token)
    total_runs = sum(s["count"] for s in stats.values())
    est_cost = total_runs * EST_COST_PER_RUN
    # 无效流程识别：调用次数为0 或 成功率<50%（排除流程名为空的记录，避免字段映射误报）
    invalid = []
    for flow, s in stats.items():
        if not flow or flow == "未知":
            continue
        rate = s["ok"] / s["count"] if s["count"] else 0
        if rate < 0.5:
            invalid.append("{}（成功率 {:.0%}，{} 次调用）".format(flow, rate, s["count"]))
    flow_lines = "\n".join(
        "· {}：{}次调用，成功率 {:.0%}，最近 {}".format(f, s["count"], s["ok"] / s["count"], s["last"][:10])
        for f, s in sorted(stats.items(), key=lambda x: -x[1]["count"]))

    # 3. 预算校验
    try:
        ds_bal_f = float(ds_bal) if ds_bal is not None else None
    except (TypeError, ValueError):
        ds_bal_f = None
    if ds_bal_f is not None and ds_bal_f < MONTHLY_BUDGET:
        budget_note = "⚠️ 预算预警：DeepSeek 余额 {} 元已低于月度红线 {} 元，建议充值或缩减调用".format(ds_bal, MONTHLY_BUDGET)
        budget_status = "超预算预警"
    else:
        budget_note = "✅ 预算正常：DeepSeek 余额 {} 元（红线 {} 元）".format(ds_bal, MONTHLY_BUDGET)
        budget_status = "正常"

    # 4. 生成报告
    report = (
        "💰 【每月成本审计报告】{}\n\n"
        "一、账户状态\n"
        "· DeepSeek 可用：{} ｜ 余额：{} 元\n"
        "· 硅基流动 可用：{}（{} 个模型）\n\n"
        "二、调用与成本（过去30天）\n"
        "· 运行日志总调用：{} 次\n"
        "· 估算费用：约 {} 元（按每次 {} 元估算，实际以账单为准）\n\n"
        "三、预算执行\n{}\n\n"
        "四、流程健康度\n{}\n\n"
        "五、无效流程与清理建议\n{}\n\n"
        "六、说明\n· 硅基流动余额查询接口已官方废弃，请登录 cloud.siliconflow.cn 控制台核对实际余额\n"
        "· 精确账单请以 DeepSeek/硅基平台月度账单为准，本报告为监控型估算\n"
        "· 无效流程清理需人工确认（不自动禁用）".format(
            month,
            "是" if ds.get("available") else "否", ds_bal,
            "是" if sf.get("available") else "否", sf.get("model_count"),
            total_runs, round(est_cost, 2), EST_COST_PER_RUN,
            budget_note,
            flow_lines if flow_lines else "（30天内无运行日志）",
            "\n".join("· {}".format(x) for x in invalid) if invalid else "✅ 未发现明显无效流程（调用成功率均≥50%）",
        )
    )
    print("=" * 50)
    print(report)
    print("=" * 50)

    if dry:
        write_run_log("dry-run：成本审计完成，估算 {} 元".format(round(est_cost, 2)))
        return

    # 5. 归档 Obsidian 系统运维/成本审计
    fpath = ""
    try:
        target = os.path.join(cfg.OBSIDIAN_VAULT.replace("/", "\\"), "系统运维", "成本审计")
        os.makedirs(target, exist_ok=True)
        fname = "月度成本审计_{}.md".format(now.strftime("%Y%m"))
        fpath = os.path.join(target, fname)
        with open(fpath, "w", encoding="utf-8") as f:
            f.write("# 月度成本审计 {}\n\n> 生成方式：cost_audit.py（P3 成本审计工作流本地实现）\n> 生成时间：{}\n\n".format(
                month, now.strftime("%Y-%m-%d %H:%M:%S")) + report)
        print("[OK] 已归档：", fpath)
    except Exception as e:
        print("[!] 归档失败：", str(e)[:80])

    # 6. 推送飞书
    ok = push_feishu(report, webhook)
    write_run_log("成本审计：{} ｜预算={} ｜推送={} ｜归档={}".format(month, budget_status, "成功" if ok else "失败", fpath))

    # 7. 运行日志沉淀
    try:
        _write_run_log_record("成本审计", "本地脚本", "正常", "")
    except Exception:
        pass


if __name__ == "__main__":
    main()
