# -*- coding: utf-8 -*-
"""
============================================================
 test_e2e.py - 个人AI系统 · 端到端自检脚本（Day 13 辅助）
============================================================
作用：
  双击运行本脚本，一键自动检查你系统的"本地可自动验证"部分，
  直接告诉你每项通没通过，帮你快速完成 Day 13 的端到端测试。

  自动检测 8 项里的 5 项（本地部分）：
    ① AnythingLLM 服务在线
    ② AnythingLLM 知识库问答正常（RAG）
    ③ Ollama 服务在线
    ④ Hermes 桥接服务在线（7860）
    ⑤ 飞书告警 Webhook 可用

  其余 3 项（飞书↔Coze对话、建任务/查任务、微信桥接）需要你在飞书里手动测，
  脚本最后会打印一份"待手动测试"清单。

用法：
  双击运行本文件，或命令行执行：  python test_e2e.py
"""

import sys
import os
import json
import socket
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import ai_config as cfg

GREEN = "✅ 通过"
RED = "❌ 未过"
MANUAL = "⚠️ 需手动"


def check_http(url, timeout=10):
    """GET 检查服务在线"""
    try:
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            resp.read(1024)
        return True
    except urllib.error.HTTPError:
        return True  # 有响应（4xx/5xx）也算在线
    except Exception:
        return False


def check_anyllm_rag():
    """实测 AnythingLLM RAG 问答"""
    try:
        sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "bridge"))
        import anyllm_query as aq
        ans = aq.query_knowledge("CAPEX是什么")
        return bool(ans and len(ans) > 20)
    except Exception as e:
        print(f"      （RAG 检测详情：{e}）")
        return False


def check_webhook():
    """测试飞书 Webhook 是否可用"""
    if not cfg.FEISHU_WEBHOOK:
        print("      （Webhook 尚未配置，跳过）")
        return False
    try:
        payload = json.dumps({"msg_type": "text", "content": {"text": "🩺 端到端自检：Webhook 连通性测试"}}, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(cfg.FEISHU_WEBHOOK, data=payload, headers={"Content-Type": "application/json"})
        resp = json.loads(urllib.request.urlopen(req, timeout=10).read())
        return resp.get("StatusCode") == 0 or resp.get("code") == 0
    except Exception as e:
        print(f"      （Webhook 检测详情：{e}）")
        return False


def main():
    print("=" * 56)
    print(" 个人AI系统 · 端到端自检")
    print(f" 时间：{__import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 56)
    results = []

    # 1. AnythingLLM 服务
    print("\n[1/5] AnythingLLM 服务 ...")
    ok = check_http(cfg.ANYLLM_BASE_URL)
    print(f"     {GREEN if ok else RED} AnythingLLM ({cfg.ANYLLM_BASE_URL})")
    results.append(("AnythingLLM 服务在线", ok))

    # 2. AnythingLLM RAG 问答
    print("[2/5] AnythingLLM 知识库问答（RAG）...")
    ok = check_anyllm_rag()
    print(f"     {GREEN if ok else RED} 提问「CAPEX是什么」能引用笔记回答")
    results.append(("AnythingLLM RAG 问答", ok))

    # 3. Ollama
    print("[3/5] Ollama 服务 ...")
    ok = check_http(cfg.SERVICES["Ollama"])
    print(f"     {GREEN if ok else RED} Ollama ({cfg.SERVICES['Ollama']})")
    results.append(("Ollama 服务在线", ok))

    # 4. Hermes 桥接
    print("[4/5] Hermes 桥接服务 ...")
    ok = check_http(cfg.SERVICES["Hermes桥接"])
    print(f"     {GREEN if ok else RED} 桥接服务 ({cfg.SERVICES['Hermes桥接']})")
    results.append(("Hermes 桥接服务", ok))

    # 5. Webhook
    print("[5/5] 飞书告警 Webhook ...")
    ok = check_webhook()
    print(f"     {GREEN if ok else RED} Webhook 发送测试消息")
    results.append(("飞书告警 Webhook", ok))

    # 汇总
    passed = sum(1 for _, ok in results if ok)
    print("\n" + "=" * 56)
    print(f" 本地自动检测结果：{passed}/{len(results)} 项通过")
    for name, ok in results:
        print(f"   {'✅' if ok else '❌'} {name}")
    print("=" * 56)
    print("\n⚠️  以下 3 项需你在飞书手动测试：")
    print("   ① 群里 @机器人「你好」→ 机器人回复（飞书↔Coze）")
    print("   ② @机器人「明天下午3点提醒我复习机电系统」→ 回复已创建 + 任务表有记录")
    print("   ③ @机器人「我今天有什么任务」→ 返回任务列表")
    if not cfg.FEISHU_WEBHOOK:
        print("\n💡 提示：FEISHU_WEBHOOK 还没配置，请先填 ai_config.py")
    print("\n（其余项如微信桥接，配置了 Work Buddy 后自行验证）")


if __name__ == "__main__":
    main()
