# -*- coding: utf-8 -*-
"""执行数据清理：
1. 删除旧表多维表格 app: SOHybNGNnaj0BMs5hN6cDtxQnAb（用户已确认整个删除）
2. 清空数据中枢任务表(FDxjb8JtvaZa72sUp0tcygVVn0y/tblHyGFQ3uzH0IyF)中任务名称为空的记录（保留有任务名的3条）
"""
import sys, json, urllib.request, urllib.error
sys.path.insert(0, r"D:\AI\AI大系统\01-脚本")
from daily_report import get_tenant_token, fmt_cell

token = get_tenant_token()
H = {"Authorization": "Bearer " + token, "Content-Type": "application/json"}
APP_HUB = "FDxjb8JtvaZa72sUp0tcygVVn0y"
TASK_TBL = "tblHyGFQ3uzH0IyF"
OLD_APP = "SOHybNGNnaj0BMs5hN6cDtxQnAb"

def req(method, url, payload=None):
    r = urllib.request.Request(url, data=(json.dumps(payload).encode("utf-8") if payload else None),
                               headers=H, method=method)
    with urllib.request.urlopen(r, timeout=20) as resp:
        return json.loads(resp.read().decode("utf-8"))

# ===== 1. 删除旧表整个多维表格 =====
print("=== 1. 删除旧表多维表格 ===")
try:
    d = req("DELETE", "https://open.feishu.cn/open-apis/bitable/v1/apps/{}".format(OLD_APP))
    print("删除结果 code:", d.get("code"), "|", d.get("msg", ""))
except urllib.error.HTTPError as e:
    print("删除旧表 HTTP", e.code, e.read().decode("utf-8")[:200])
except Exception as e:
    print("删除旧表失败:", str(e)[:150])

# ===== 2. 清空数据中枢任务表空任务名记录 =====
print("\n=== 2. 清空数据中枢任务表空任务名记录 ===")
url = "https://open.feishu.cn/open-apis/bitable/v1/apps/{}/tables/{}/records?page_size=100".format(APP_HUB, TASK_TBL)
try:
    d = req("GET", url)
    items = d.get("data", {}).get("items", [])
    print("任务表当前 {} 条：".format(len(items)))
    empty_ids = []
    for it in items:
        f = it.get("fields", {})
        name = fmt_cell(f.get("任务名称"))
        rid = it.get("record_id")
        if not name or name == "None":
            empty_ids.append(rid)
            print("  将删除空记录:", rid)
        else:
            print("  保留:", repr(name))
    print("空记录 {} 条".format(len(empty_ids)))
    for rid in empty_ids:
        try:
            dd = req("DELETE", "https://open.feishu.cn/open-apis/bitable/v1/apps/{}/tables/{}/records/{}".format(APP_HUB, TASK_TBL, rid))
            print("  删除 {} → code {}".format(rid, dd.get("code")))
        except Exception as e:
            print("  删除 {} 失败: {}".format(rid, str(e)[:100]))
    # 验证
    d2 = req("GET", url)
    items2 = d2.get("data", {}).get("items", [])
    print("清理后任务表 {} 条：".format(len(items2)))
    for it in items2:
        print("  -", repr(fmt_cell(it.get("fields", {}).get("任务名称"))))
except urllib.error.HTTPError as e:
    print("查询任务表 HTTP", e.code, e.read().decode("utf-8")[:200])
