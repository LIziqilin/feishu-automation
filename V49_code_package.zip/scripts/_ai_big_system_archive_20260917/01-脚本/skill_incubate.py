# -*- coding: utf-8 -*-
"""
============================================================
 skill_incubate.py - 个人AI系统 · Skill 孵化（P2 工作流本地实现）
============================================================
作用（每周日 23:00 计划任务自动运行）：
  1. 拉取飞书「运行日志表」过去 7 天数据（飞书 API）
  2. 调用 DeepSeek 识别可固化的重复模式
  3. 推送 Skill 孵化建议到飞书（不自动写入 _Skills，等用户确认后由 write_skill 写入）

用法（在 D:\\AI\\AI大系统\\01-脚本 目录）：
  python skill_incubate.py            # 分析+推送
  python skill_incubate.py --dry      # 只打印不推送
"""

import sys
import os
import json
import urllib.request
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import ai_config as cfg
except Exception:
    cfg = None
from daily_report import get_tenant_token, fetch_records, fmt_cell, deepseek_chat, push_feishu
from feishu_common import write_run_log_record as _write_run_log_record

RUN_LOG_TABLE = "tbl3hkFkgrSxlvUx"   # 运行日志表


def write_run_log(msg):
    try:
        log_path = os.path.join(r"D:\AI\AI大系统\05-备份", "skill_incubate.log")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write("[{}] {}\n".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg))
    except Exception:
        pass


def main():
    dry = "--dry" in sys.argv
    webhook = None
    if "--webhook" in sys.argv:
        webhook = sys.argv[sys.argv.index("--webhook") + 1]

    dates = [(datetime.now() - timedelta(days=i)).strftime("%Y-%m-%d") for i in range(7)]
    print("=== 拉取运行日志（过去7天 {} ~ {}）===".format(dates[-1], dates[0]))
    token = get_tenant_token()
    records = fetch_records(RUN_LOG_TABLE, token)
    rows = []
    for rec in records:
        fields = rec.get("fields", {})
        line = " | ".join("{}={}".format(k, fmt_cell(v)) for k, v in fields.items() if fmt_cell(v))
        if any(d in line for d in dates):
            rows.append(line)
    print("  过去7天运行日志: {} 条".format(len(rows)))

    data_text = "\n".join(rows) if rows else "（过去7天无运行日志记录）"
    prompt = (
        "你是专业的流程优化专家，分析以下过去7天的系统运行日志，识别可固化的重复模式。\n"
        "分析规则：\n"
        "1. 统计每个「流程名」出现的次数和执行状态\n"
        "2. 找出连续出现≥3次、执行成功率高的重复操作\n"
        "3. 判断该操作是否可以固化为标准化Skill\n"
        "4. 每个符合条件模式输出：模式名称、出现次数、核心执行步骤、固化为Skill的建议、预期收益\n"
        "输出格式（无符合条件模式则只输出：无符合条件的重复模式）：\n"
        "【可固化Skill 1】\n模式名称：xxx\n出现次数：x次\n核心步骤：1.xxx 2.xxx\n固化建议：xxx\n预期收益：xxx\n\n"
        "运行日志：\n" + data_text
    )
    print("=== 生成模式识别（DeepSeek）... ===")
    analysis = deepseek_chat(prompt, max_tokens=1500)

    report = (
        "🤖 【Skill 孵化建议】\n分析时间：{}\n\n{}".format(
            datetime.now().strftime("%Y-%m-%d"), analysis)
    )
    print("=" * 50)
    print(report)
    print("=" * 50)

    if dry:
        write_run_log("dry-run：模式识别完成")
        return

    ok = push_feishu(report, webhook)
    write_run_log("Skill孵化推送：{} ｜推送={}".format(datetime.now().strftime("%Y-%m-%d"), "成功" if ok else "失败"))
    if ok:
        print("[OK] 已推送。如需固化，回复确认后我再写入 _Skills（或手动调 /write_skill）")

    # P2 运行日志沉淀
    try:
        _write_run_log_record("Skill孵化", "本地脚本", "正常", "")
    except Exception:
        pass


if __name__ == "__main__":
    main()
