# -*- coding: utf-8 -*-
"""
============================================================
 daily_briefing.py - 个人AI系统 · 每日晨间简报（P1 晨间简报工作流本地实现）
============================================================
作用（每天 07:00 计划任务自动运行）：
  1. 拉取飞书 任务表/学习打卡表/间隔重复表 真实数据
     - 今日待办（状态=待办/进行中 + 今日截止）
     - 昨日学习复盘（学习打卡表昨日记录）
     - 今日复习提醒（间隔重复表今日到期）
  2. 调用 DeepSeek 生成个性化晨间简报（比固定模板更智能）
  3. 推送飞书 webhook（个人/告警群）
  4. 写入运行日志表

用法（在 D:\\AI\\AI大系统\\01-脚本 目录）：
  python daily_briefing.py            # 生成+推送
  python daily_briefing.py --dry      # 只打印不推送
  python daily_briefing.py --webhook <url>   # 推送到指定群
"""

import sys
import os
import json
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import ai_config as cfg
except Exception:
    cfg = None
from daily_report import get_tenant_token, fetch_records, fmt_cell, deepseek_chat, push_feishu
from feishu_common import write_run_log_record as _write_run_log_record

TASK_TABLE = "tblHyGFQ3uzH0IyF"      # 任务表
STUDY_TABLE = "tbl0tfLmDWMD0o77"     # 学习打卡表
REVIEW_TABLE = "tblPtciwNAUxkc1U"    # 间隔重复表


def write_run_log(msg):
    try:
        log_path = os.path.join(r"D:\AI\AI大系统\05-备份", "daily_briefing.log")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write("[{}] {}\n".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg))
    except Exception:
        pass


def _ts_date(ts):
    try:
        return datetime.fromtimestamp(int(ts) / 1000).strftime("%Y-%m-%d")
    except Exception:
        return str(ts)[:10]


def main():
    dry = "--dry" in sys.argv
    webhook = None
    if "--webhook" in sys.argv:
        webhook = sys.argv[sys.argv.index("--webhook") + 1]

    now = datetime.now()
    today = now.strftime("%Y-%m-%d")
    yesterday = (now - timedelta(days=1)).strftime("%Y-%m-%d")
    print("=== 晨间简报（{}）===".format(today))
    token = get_tenant_token()

    # 1. 任务表：待办/进行中任务 + 今日截止
    task_recs = fetch_records(TASK_TABLE, token)
    open_tasks, today_deadline = [], []
    for rec in task_recs:
        f = rec.get("fields", {})
        name = fmt_cell(f.get("任务名称"))
        status = fmt_cell(f.get("状态", ""))
        prio = fmt_cell(f.get("优先级", ""))
        deadline = _ts_date(fmt_cell(f.get("截止时间", "")))
        if not name or name == "None":
            continue
        if status in ("待办", "进行中", ""):
            open_tasks.append("{}（{}）{}".format(name, status or "待办", "截止{}".format(deadline) if deadline else ""))
            if deadline == today:
                today_deadline.append(name)

    # 2. 学习打卡表：昨日学习
    study_recs = fetch_records(STUDY_TABLE, token)
    yesterday_study = []
    for rec in study_recs:
        f = rec.get("fields", {})
        d = _ts_date(fmt_cell(f.get("日期", "")))
        if d == yesterday:
            subj = fmt_cell(f.get("科目", ""))
            topic = fmt_cell(f.get("学习主题", ""))
            dur = fmt_cell(f.get("学习时长", ""))
            yesterday_study.append("{}｜{}｜{}分钟".format(subj, topic, dur))

    # 3. 间隔重复表：今日复习
    review_recs = fetch_records(REVIEW_TABLE, token)
    today_review = []
    for rec in review_recs:
        f = rec.get("fields", {})
        d = _ts_date(fmt_cell(f.get("下次复习日期", "")))
        if d == today:
            q = fmt_cell(f.get("正面（问题）", ""))
            subj = fmt_cell(f.get("科目", ""))
            today_review.append("{}（{}）".format(q[:20], subj) if q else "未命名卡片")

    # 4. DeepSeek 生成简报
    prompt = (
        "你是个人效率晨间助手，根据以下数据生成一份简洁的晨间简报，今天日期 {}。\n"
        "包含模块：\n"
        "1. 昨日复盘：若昨日有学习记录则总结，无则提示'昨日无学习打卡'\n"
        "2. 今日待办：列出待办任务（重点标注今日截止项），无则提示无\n"
        "3. 复习提醒：列出今日需复习的卡片（间隔重复），无则提示无\n"
        "4. 今日提示：给 1 条精炼的行动建议\n"
        "风格：简短、友好、数据化，控制在 200 字以内，用 emoji 点缀。\n\n"
        "=== 数据 ===\n"
        "昨日学习（{}）：{}\n"
        "今日待办：{} 条｜今日截止：{}\n"
        "待办明细：{}\n"
        "今日复习：{} 条｜{}".format(
            today,
            yesterday, "；".join(yesterday_study) if yesterday_study else "无",
            len(open_tasks), "；".join(today_deadline) if today_deadline else "无",
            "；".join(open_tasks[:8]) if open_tasks else "无",
            len(today_review), "；".join(today_review[:6]) if today_review else "无")
    )
    print("=== 生成晨间简报（DeepSeek）... ===")
    try:
        brief = deepseek_chat(prompt, max_tokens=500)
    except Exception as e:
        brief = (
            "【晨间简报】{}\n\n"
            "1. 昨日复盘：{}（{} 条学习记录）\n"
            "2. 今日待办：{} 条（今日截止 {}）\n"
            "3. 复习提醒：{} 条\n"
            "4. 提示：请打开飞书/滴答清单确认今日安排".format(
                today,
                "有学习" if yesterday_study else "无",
                len(yesterday_study),
                len(open_tasks), "；".join(today_deadline) if today_deadline else "无",
                len(today_review))
        )
        write_run_log("DeepSeek 生成失败，使用模板简报")

    report = "☀️ 【晨间简报】{}\n\n{}".format(today, brief)
    print("=" * 50)
    print(report)
    print("=" * 50)

    if dry:
        write_run_log("dry-run：晨间简报生成完成")
        return

    ok = push_feishu(report, webhook)
    write_run_log("晨间简报推送：{} ｜推送={}".format(today, "成功" if ok else "失败"))
    try:
        _write_run_log_record("晨间简报", "本地脚本", "正常", "")
    except Exception:
        pass


if __name__ == "__main__":
    main()
