# -*- coding: utf-8 -*-
"""
============================================================
 health_check.py - 个人AI系统 · 知识库体检（P2 工作流本地实现）
============================================================
作用（每周一 02:00 计划任务自动运行）：
  1. 扫描 Obsidian Vault：空文档 / 测试笔记 / 孤立节点
  2. 调用 DeepSeek 做知识缺口分析 + 生成待办任务（JSON）
  3. 把待办任务写入飞书「任务表」（如权限允许）
  4. 推送体检报告到飞书 webhook

用法（在 D:\\AI\\AI大系统\\01-脚本 目录）：
  python health_check.py            # 扫描+分析+推送
  python health_check.py --dry      # 只打印不推送不写入
"""

import sys
import os
import re
import json
import urllib.request
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import ai_config as cfg
except Exception:
    cfg = None
from daily_report import get_tenant_token, fetch_records, fmt_cell, deepseek_chat, push_feishu
from feishu_common import write_run_log_record as _write_run_log_record

VAULT = cfg.OBSIDIAN_VAULT
TASK_TABLE = "tblHyGFQ3uzH0IyF"   # 飞书任务表
EMPTY_THRESHOLD = 50
TEST_KEYWORDS = ["test", "测试", "草稿", "temp"]
STUDY_GOALS = ["酒店工程", "PMP考证", "认知升级", "沟通技巧"]


def scan_vault():
    """扫描 Vault，返回空文档/测试笔记/孤立统计"""
    notes = []
    all_links = set()
    for root, dirs, files in os.walk(VAULT):
        dirs[:] = [d for d in dirs if not d.startswith(".") and d not in ("node_modules", ".git")]
        for fn in files:
            if not fn.endswith(".md"):
                continue
            abs_path = os.path.join(root, fn)
            rel = os.path.relpath(abs_path, VAULT)
            try:
                with open(abs_path, "r", encoding="utf-8") as f:
                    content = f.read()
            except Exception:
                content = ""
            title = fn[:-3]
            for m in re.findall(r"\[\[([^\]|#]+)", content):
                all_links.add(m.strip().split("/")[-1])
            notes.append({"title": title, "rel": rel.replace("\\", "/"), "chars": len(content)})
    empty_docs = [n for n in notes if n["chars"] < EMPTY_THRESHOLD]
    test_notes = [n for n in notes if any(k.lower() in n["title"].lower() for k in TEST_KEYWORDS)]
    isolated = [n for n in notes if not any(n["title"] == lk or n["title"] in lk for lk in all_links)]
    return {
        "total_notes": len(notes),
        "empty_docs": empty_docs,
        "test_notes": test_notes,
        "isolated_count": len(isolated),
    }


def write_run_log(msg):
    try:
        log_path = os.path.join(r"D:\AI\AI大系统\05-备份", "health_check.log")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write("[{}] {}\n".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg))
    except Exception:
        pass


def add_task_to_feishu(task_name, priority, deadline_hint):
    """尝试写飞书任务表（如权限允许）"""
    token = get_tenant_token()
    url = "https://open.feishu.cn/open-apis/bitable/v1/apps/{}/tables/{}/records".format(
        "FDxjb8JtvaZa72sUp0tcygVVn0y", TASK_TABLE)
    # 任务表字段：任务名称/归属/优先级/状态/截止时间等
    fields = {"任务名称": task_name, "优先级": priority, "状态": "待办", "归属": "知识库体检"}
    if deadline_hint:
        fields["截止时间"] = deadline_hint
    payload = json.dumps({"fields": fields}, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=payload,
                                 headers={"Content-Type": "application/json",
                                          "Authorization": "Bearer " + token}, method="POST")
    with urllib.request.urlopen(req, timeout=20) as resp:
        d = json.loads(resp.read().decode("utf-8"))
        return d.get("code") == 0


def main():
    dry = "--dry" in sys.argv
    push = "--push" not in sys.argv or "--push" in sys.argv
    webhook = None
    if "--webhook" in sys.argv:
        webhook = sys.argv[sys.argv.index("--webhook") + 1]

    print("=== 扫描 Vault ({}) ===".format(VAULT))
    result = scan_vault()
    print("  总笔记: {} | 空文档: {} | 测试: {} | 孤立: {}".format(
        result["total_notes"], len(result["empty_docs"]), len(result["test_notes"]), result["isolated_count"]))

    scan_text = json.dumps({
        "total_notes": result["total_notes"],
        "empty_docs": [{"title": d["title"], "path": d["rel"], "chars": d["chars"]} for d in result["empty_docs"][:30]],
        "test_notes": [{"title": t["title"], "path": t["rel"]} for t in result["test_notes"][:30]],
        "isolated_count": result["isolated_count"],
    }, ensure_ascii=False)

    prompt = (
        "你是知识库管理专家，根据以下Vault扫描结果，完成3项任务。\n"
        "任务1：问题清单整理（空文档、测试笔记、孤立节点，列出关键项）\n"
        "任务2：知识缺口分析：对照学习目标【{}】，找出3个最核心的知识缺口\n"
        "任务3：生成待办任务：针对每个问题和缺口生成待办，含任务名称/优先级(高/中/低)/建议完成时间(如3天后)。\n"
        "输出：先输出问题清单和缺口分析，最后输出严格JSON数组格式的待办任务：\n"
        "[{{\"task_name\":\"...\",\"priority\":\"高\",\"deadline\":\"3天后\"}},...]\n"
        "不要多余寒暄。\n\n扫描结果：\n{}".format("、".join(STUDY_GOALS), scan_text)
    )
    print("=== 生成缺口分析（DeepSeek）... ===")
    analysis = deepseek_chat(prompt, max_tokens=1500)

    report = (
        "📊 【每周知识库体检报告】\n扫描时间：{}\n\n{}\n\n总笔记 {} 篇".format(
            datetime.now().strftime("%Y-%m-%d"), analysis, result["total_notes"])
    )
    print("=" * 50)
    print(report)
    print("=" * 50)

    if dry:
        write_run_log("dry-run：体检完成，总{}篇/空{}".format(result["total_notes"], len(result["empty_docs"])))
        return

    # 写飞书任务表（尝试提取 JSON 待办；无权限则并入推送报告）
    task_note = ""
    try:
        m = re.search(r"\[.*\]", analysis, re.S)
        if m:
            tasks = json.loads(m.group(0))
            ok_count = 0
            for t in tasks[:10]:
                if add_task_to_feishu(t.get("task_name", "未命名"), t.get("priority", "中"), t.get("deadline", "")):
                    ok_count += 1
            if ok_count > 0:
                print("[OK] 已写入任务表 {} 条".format(ok_count))
                write_run_log("写任务表 {} 条（共 {} 条待办）".format(ok_count, len(tasks)))
            else:
                task_note = "\n\n✅ 已生成待办任务（写表无权限，已列于此，请手动建任务）：\n" + "\n".join(
                    "- [{}] {}（{}）".format(t.get("priority", "中"), t.get("task_name", ""), t.get("deadline", ""))
                    for t in tasks[:10])
                print("[!] 写任务表无权限，待办已并入推送报告")
                write_run_log("写任务表无权限（403），待办并入报告 {} 条".format(len(tasks)))
    except Exception as e:
        print("[!] 写任务表失败：", str(e)[:100])
        write_run_log("写任务表失败：{}".format(str(e)[:100]))

    # 推送飞书（含待办清单）
    if task_note:
        report += task_note
    ok = push_feishu(report, webhook)
    write_run_log("体检推送：{} ｜推送={}".format(datetime.now().strftime("%Y-%m-%d"), "成功" if ok else "失败"))

    # P2 运行日志沉淀
    try:
        _write_run_log_record("知识库体检", "本地脚本", "正常", "")
    except Exception:
        pass


if __name__ == "__main__":
    main()
