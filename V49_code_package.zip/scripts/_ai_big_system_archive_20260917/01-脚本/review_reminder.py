# -*- coding: utf-8 -*-
"""
============================================================
 review_reminder.py - 个人AI系统 · 每日间隔复习提醒（P1「间隔重复复习提醒体系」本地实现）
============================================================
作用（每天 20:00 计划任务自动运行，对应 P1 手册「每日20:00执行当日间隔复习」）：
  1. 读取飞书「间隔重复表」今日到期卡片（下次复习日期=今天）
  2. 有到期卡片 → 推送飞书复习清单（问题+科目+难度）
  3. 无到期卡片 → 静默（不打扰）
  4. 顺带提醒学习打卡（若今天还没打卡）

用法（在 D:\\AI\\AI大系统\\01-脚本 目录）：
  python review_reminder.py            # 检查+推送
  python review_reminder.py --dry      # 只打印不推送
  python review_reminder.py --webhook <url>   # 推送到指定群
"""

import sys
import os
import json
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import ai_config as cfg
except Exception:
    cfg = None
from daily_report import get_tenant_token, fetch_records, fmt_cell, push_feishu
from feishu_common import write_run_log_record as _write_run_log_record

REVIEW_TABLE = "tblPtciwNAUxkc1U"    # 间隔重复表
STUDY_TABLE = "tbl0tfLmDWMD0o77"     # 学习打卡表


def write_run_log(msg):
    try:
        log_path = os.path.join(r"D:\AI\AI大系统\05-备份", "review_reminder.log")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write("[{}] {}\n".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg))
    except Exception:
        pass


def _ts_date(ts):
    try:
        return datetime.fromtimestamp(int(ts) / 1000).strftime("%Y-%m-%d")
    except Exception:
        return str(ts)[:10]


def main():
    dry = "--dry" in sys.argv
    webhook = None
    if "--webhook" in sys.argv:
        webhook = sys.argv[sys.argv.index("--webhook") + 1]

    now = datetime.now()
    today = now.strftime("%Y-%m-%d")
    print("=== 复习提醒（{}）===".format(today))
    token = get_tenant_token()

    # 1. 今日到期复习卡片
    due = []
    try:
        recs = fetch_records(REVIEW_TABLE, token)
        for rec in recs:
            f = rec.get("fields", {})
            d = _ts_date(fmt_cell(f.get("下次复习日期", "")))
            if d == today:
                q = fmt_cell(f.get("正面（问题）", "")) or "未命名卡片"
                subj = fmt_cell(f.get("科目", "")) or ""
                diff = fmt_cell(f.get("难度", "")) or ""
                cnt = fmt_cell(f.get("已复习次数", "")) or "0"
                due.append("· {}（{}{}，已复习{}次）".format(q[:30], subj, "，难度" + diff if diff else "", cnt))
    except Exception as e:
        print("[!] 间隔重复表读取失败：", str(e)[:60])

    # 2. 今天是否已学习打卡
    checked_today = False
    try:
        study_recs = fetch_records(STUDY_TABLE, token)
        for rec in study_recs:
            d = _ts_date(fmt_cell(rec.get("fields", {}).get("日期", "")))
            if d == today:
                checked_today = True
                break
    except Exception:
        pass

    lines = []
    if due:
        lines.append("🔁 **今日复习（{}张卡片）**：\n{}".format(len(due), "\n".join(due)))
        lines.append("复习方法：先盖住答案自测→记不住标「模糊」→明天再复习")
    else:
        lines.append("🔁 今日无到期复习卡片，记忆负担为零。")
    if not checked_today:
        lines.append("📚 今天还没学习打卡——学 25 分钟并打卡，保持链条不断。")

    report = "⏰ 【复习提醒】{}\n\n{}".format(today, "\n".join(lines))
    print("=" * 50)
    print(report)
    print("=" * 50)

    if dry:
        write_run_log("dry-run：复习 {} 张，打卡={}".format(len(due), checked_today))
        return

    ok = push_feishu(report, webhook)
    write_run_log("复习提醒推送：今日{}张｜已打卡={}｜推送={}".format(len(due), checked_today, "成功" if ok else "失败"))
    try:
        _write_run_log_record("复习提醒", "本地脚本", "正常", "")
    except Exception:
        pass


if __name__ == "__main__":
    main()
