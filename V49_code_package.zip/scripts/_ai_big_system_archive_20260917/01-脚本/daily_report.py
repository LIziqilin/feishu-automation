# -*- coding: utf-8 -*-
"""
============================================================
 daily_report.py - 个人AI系统 · 每日日报生成（P2 日报工作流本地参考实现）
============================================================
作用：
  1. 用飞书开放平台 API 拉取 任务表/学习打卡表/运行日志表 今日真实数据
     （不依赖 lark-cli 登录态，可在 Windows 计划任务环境稳定运行）
  2. 调用 DeepSeek 生成结构化日报
  3. 归档到 Obsidian 日志/日报/年/月/
  4. --push 时通过飞书 webhook 推送（接入飞书自动化）

用法（在 D:\\AI\\AI大系统\\01-脚本 目录）：
  python daily_report.py            # 生成并归档今日日报
  python daily_report.py --dry      # 只打印不写入
  python daily_report.py --push     # 生成+归档+推送飞书
  python daily_report.py --push --webhook <url>   # 推送到指定群
"""

import sys
import os
import json
import urllib.request
import urllib.error
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import ai_config as cfg
except Exception:
    cfg = None
from feishu_common import write_run_log_record as _write_run_log_record

BASE_TOKEN = "FDxjb8JtvaZa72sUp0tcygVVn0y"
TABLES = {
    "任务表": "tblHyGFQ3uzH0IyF",
    "学习打卡表": "tbl0tfLmDWMD0o77",
    "运行日志表": "tbl3hkFkgrSxlvUx",
}
TODAY = datetime.now().strftime("%Y-%m-%d")


# ------------------------------------------------------------
# 飞书开放平台 API 直读（稳定，不依赖 lark-cli 登录态）
# ------------------------------------------------------------
_tenant_token = None


def get_tenant_token():
    """用 Coze 飞书应用凭证换取 tenant_access_token（2h 有效，进程内缓存）"""
    global _tenant_token
    if _tenant_token:
        return _tenant_token
    app_id = getattr(cfg, "COZE_FEISHU_APP_ID", "")
    app_secret = getattr(cfg, "COZE_FEISHU_APP_SECRET", "")
    req = urllib.request.Request(
        "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
        data=json.dumps({"app_id": app_id, "app_secret": app_secret}).encode("utf-8"),
        headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=20) as resp:
        d = json.loads(resp.read().decode("utf-8"))
    if d.get("code") != 0 or not d.get("tenant_access_token"):
        raise RuntimeError("获取飞书 tenant_access_token 失败: " + str(d))
    _tenant_token = d["tenant_access_token"]
    return _tenant_token


def feishu_get(path, token):
    req = urllib.request.Request("https://open.feishu.cn" + path,
                                 headers={"Authorization": "Bearer " + token}, method="GET")
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


def fetch_records(table_id, token=None, page_size=200):
    """拉取表全部记录（自动分页），返回 [{record_id, fields}]"""
    token = token or get_tenant_token()
    all_items = []
    page_token = None
    for _ in range(10):  # 最多 10 页
        url = "/open-apis/bitable/v1/apps/{}/tables/{}/records?page_size={}".format(
            BASE_TOKEN, table_id, page_size)
        if page_token:
            url += "&page_token=" + page_token
        d = feishu_get(url, token)
        if d.get("code") != 0:
            raise RuntimeError("读表失败 {}: {}".format(table_id, d.get("msg")))
        items = d.get("data", {}).get("items", [])
        all_items.extend(items)
        if not d.get("data", {}).get("has_more"):
            break
        page_token = d.get("data", {}).get("page_token")
    return all_items


def fmt_cell(v):
    """把字段值转成可读文本"""
    if v is None:
        return ""
    if isinstance(v, list):
        return ",".join(str(x.get("text", x)) if isinstance(x, dict) else str(x) for x in v)
    if isinstance(v, dict):
        return str(v.get("text", v))
    return str(v)


def table_today_text(name, records):
    """把表记录转成文本，只保留含今日日期的记录；无则返回提示"""
    today_rows = []
    for rec in records:
        fields = rec.get("fields", {})
        line = " | ".join("{}={}".format(k, fmt_cell(v)) for k, v in fields.items() if fmt_cell(v))
        if TODAY in line:
            today_rows.append(line)
    if today_rows:
        return "【{} 今日数据（{}条）】\n{}".format(name, len(today_rows), "\n".join(today_rows))
    return "【{} 今日数据（0条）】无今日记录".format(name)


def deepseek_chat(prompt, max_tokens=800):
    """调用 DeepSeek 生成日报"""
    key = getattr(cfg, "DEEPSEEK_API_KEY", "")
    req = urllib.request.Request(
        "https://api.deepseek.com/chat/completions",
        data=json.dumps({
            "model": "deepseek-chat",
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens,
            "temperature": 0.3,
        }).encode("utf-8"),
        headers={"Content-Type": "application/json", "Authorization": "Bearer " + key},
        method="POST")
    with urllib.request.urlopen(req, timeout=120) as resp:
        d = json.loads(resp.read().decode("utf-8"))
        return d["choices"][0]["message"]["content"]


def write_run_log(msg):
    """把运行摘要追加到 daily_report.log（供计划任务/手动调用统一留痕）"""
    try:
        log_path = os.path.join(r"D:\AI\AI大系统\05-备份", "daily_report.log")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write("[{}] {}\n".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg))
    except Exception:
        pass


def push_feishu(text, webhook=None):
    """通过飞书自定义机器人 webhook 推送日报（接入飞书自动化）"""
    url = webhook or getattr(cfg, "FEISHU_WEBHOOK", "")
    if not url:
        print("[!] 未配置飞书 webhook，跳过推送")
        return False
    payload = json.dumps({"msg_type": "text", "content": {"text": text}}, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=payload,
                                 headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=20) as resp:
        d = json.loads(resp.read().decode("utf-8"))
        ok = d.get("code") == 0
        print("[OK] 已推送飞书" if ok else "[!] 飞书推送失败：" + str(d))
        return ok


def main():
    dry = "--dry" in sys.argv
    push = "--push" in sys.argv
    webhook = None
    if "--webhook" in sys.argv:
        webhook = sys.argv[sys.argv.index("--webhook") + 1]

    print("=== 拉取今日数据 ({}) ===".format(TODAY))
    token = get_tenant_token()
    sections = []
    for name, tid in TABLES.items():
        records = fetch_records(tid, token)
        print("  {}: 共{}条".format(name, len(records)))
        sections.append(table_today_text(name, records))

    data_text = "\n\n".join(sections)
    prompt = (
        "你是个人效率助手，根据以下今日数据生成一份简洁的每日工作学习日报。\n"
        "包含模块：\n"
        "1. 任务概览：完成数、待办数、逾期数、Top重点任务（无则写无）\n"
        "2. 学习产出：学习总时长、知识点、费曼输出情况（无则写无）\n"
        "3. 系统状态：运行日志中流程调用情况、是否有异常\n"
        "4. 明日重点：3件优先级最高的事（根据数据合理推断）\n"
        "风格：简洁、数据化、无废话，控制在300字以内。\n\n"
        "今日数据：\n" + data_text
    )
    print("=== 生成日报中（DeepSeek）... ===")
    report = deepseek_chat(prompt)

    full = (
        "# 日报 {}\n\n> 生成方式：daily_report.py（P2 日报工作流本地实现）\n> 生成时间：{}\n\n".format(
            TODAY, datetime.now().strftime("%Y-%m-%d %H:%M:%S")) + report
    )
    print("=" * 50)
    print(full)
    print("=" * 50)

    fpath = ""
    if not dry:
        # 归档到 日志/日报/年/月/
        y = datetime.now().strftime("%Y")
        m = datetime.now().strftime("%m")
        target = os.path.join(cfg.OBSIDIAN_VAULT.replace("/", "\\"), "日志", "日报", y, m)
        os.makedirs(target, exist_ok=True)
        fname = "日报-{}.md".format(TODAY.replace("-", ""))
        fpath = os.path.join(target, fname)
        with open(fpath, "w", encoding="utf-8") as f:
            f.write(full)
        print("[OK] 已归档：", fpath)
    else:
        print("(dry-run，未写入)")

    # 接入飞书自动化：生成后推送飞书（可用 --webhook 指定群，默认告警群）
    if push and not dry:
        push_text = "📅 今日日报 {}\n\n{}".format(TODAY, report)
        ok = push_feishu(push_text, webhook)
        write_run_log("日报生成+推送：{} ｜归档={} ｜推送={}".format(TODAY, fpath, "成功" if ok else "失败"))
    elif not dry:
        write_run_log("日报生成（未推送）：{} ｜归档={}".format(TODAY, fpath))
    else:
        write_run_log("dry-run：{}".format(TODAY))

    # P2 运行日志沉淀：本次运行结果写入飞书运行日志表（失败不阻断）
    try:
        _write_run_log_record("每日日报", "本地脚本", "正常", "")
    except Exception:
        pass


if __name__ == "__main__":
    main()
