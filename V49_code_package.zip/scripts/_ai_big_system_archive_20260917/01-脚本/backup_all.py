# -*- coding: utf-8 -*-
"""
============================================================
 backup_all.py - 个人AI系统 · 全量备份（P3 实施前强制前置操作 + 每周运维备份）
============================================================
作用：
  1. 导出飞书多维表格全部 7 张表 → CSV 快照（含表字段名）
  2. 导出 Coze 工作流定义 → JSON 快照（经 Coze API）
  3. 备份 Obsidian Vault 关键目录 → 复制到备份目录
  4. 备份 ai_config.py 等核心脚本配置
  5. 写入运行日志表 + 本地备份日志

用法（在 D:\\AI\\AI大系统\\01-脚本 目录）：
  python backup_all.py            # 全量备份到 05-备份/backup/YYYYMMDD/
  python backup_all.py --tables   # 只备份多维表格
  python backup_all.py --coze     # 只备份 Coze 工作流
  python backup_all.py --vault    # 只备份 Obsidian Vault
"""

import sys
import os
import json
import csv
import io
import shutil
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import ai_config as cfg
except Exception:
    cfg = None
from daily_report import get_tenant_token, fetch_records

APP_TOKEN = "FDxjb8JtvaZa72sUp0tcygVVn0y"
TABLES = {
    "任务表": "tblHyGFQ3uzH0IyF",
    "学习打卡表": "tbl0tfLmDWMD0o77",
    "间隔重复表": "tblPtciwNAUxkc1U",
    "运行日志表": "tbl3hkFkgrSxlvUx",
    "知识入库表": "tblcXpMnbAYcnjs6",
    "决策日志表": "tblQLwLpYnXXHown",
    "用户画像总表": "tbl2OqIYZXRyXa5P",
}
BACKUP_ROOT = r"D:\AI\AI大系统\05-备份\backup"
VAULT_DIR = r"D:\AI\finished Brain"          # Obsidian Vault 根目录
SCRIPT_DIR = r"D:\AI\AI大系统\01-脚本"


def write_run_log(msg):
    try:
        log_path = os.path.join(r"D:\AI\AI大系统\05-备份", "backup.log")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write("[{}] {}\n".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg))
    except Exception:
        pass


def fmt_val(v):
    """把单元格值转为字符串（多值/对象处理）"""
    if v is None:
        return ""
    if isinstance(v, (list, dict)):
        return json.dumps(v, ensure_ascii=False)
    return str(v)


def backup_tables():
    print("=== 导出多维表格 7 张表 ===")
    token = get_tenant_token()
    day = datetime.now().strftime("%Y%m%d")
    tdir = os.path.join(BACKUP_ROOT, day, "tables")
    os.makedirs(tdir, exist_ok=True)
    counts = {}
    for name, tid in TABLES.items():
        recs = fetch_records(tid, token)
        if not recs:
            counts[name] = 0
            with open(os.path.join(tdir, name + ".csv"), "w", encoding="utf-8-sig", newline="") as f:
                f.write("（无记录）\n")
            continue
        fields = list(recs[0].get("fields", {}).keys())
        path = os.path.join(tdir, name + ".csv")
        with open(path, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f)
            w.writerow(fields)
            for rec in recs:
                fld = rec.get("fields", {})
                w.writerow([fmt_val(fld.get(k)) for k in fields])
        counts[name] = len(recs)
        print("  {}：{} 条".format(name, len(recs)))
    write_run_log("表格备份：{}".format(json.dumps(counts, ensure_ascii=False)))
    return counts


def backup_coze():
    print("=== 导出 Coze 工作流定义 ===")
    import urllib.request
    cdir = os.path.join(BACKUP_ROOT, datetime.now().strftime("%Y%m%d"), "coze")
    os.makedirs(cdir, exist_ok=True)
    headers = {
        "Authorization": "Bearer " + cfg.COZE_API_TOKEN,
        "Content-Type": "application/json",
    }
    try:
        # 1. 拉取工作流列表（个人空间）
        list_url = "https://api.coze.cn/v1/workflows?workspace_id={}&page_num=1&page_size=30&publish_status=all".format(cfg.COZE_WORKSPACE_ID)
        req = urllib.request.Request(list_url, headers=headers)
        with urllib.request.urlopen(req, timeout=20) as r:
            d = json.loads(r.read().decode("utf-8"))
        items = d.get("data", {}).get("items", []) or []
        print("  发现工作流 {} 个".format(len(items)))
        saved = 0
        for wf in items:
            wf_id = wf.get("workflow_id")
            wf_name = wf.get("workflow_name") or wf_id
            if not wf_id:
                continue
            try:
                detail_url = "https://api.coze.cn/v1/workflows/{}".format(wf_id)
                req2 = urllib.request.Request(detail_url, headers=headers)
                with urllib.request.urlopen(req2, timeout=20) as r2:
                    dd = json.loads(r2.read().decode("utf-8"))
                fname = "workflow-{}.json".format(str(wf_name).replace("/", "-")[:40])
                with open(os.path.join(cdir, fname), "w", encoding="utf-8") as f:
                    json.dump(dd, f, ensure_ascii=False, indent=2)
                saved += 1
                print("  已备份：{}".format(wf_name))
            except Exception as e:
                write_run_log("Coze 工作流备份失败 {}：{}".format(wf_name, str(e)[:80]))
        write_run_log("Coze 备份：{} 个工作流".format(saved))
        return saved
    except Exception as e:
        write_run_log("Coze 工作流列表失败：" + str(e)[:120])
        print("  [!] Coze 备份失败：", str(e)[:120])
        return 0


def backup_vault():
    print("=== 备份 Obsidian Vault ===")
    day = datetime.now().strftime("%Y%m%d")
    vdir = os.path.join(BACKUP_ROOT, day, "vault")
    if not os.path.isdir(VAULT_DIR):
        print("  [!] Vault 目录不存在：", VAULT_DIR)
        return 0
    # 只复制 md 文件（避免过大），保留目录结构
    os.makedirs(vdir, exist_ok=True)
    n = 0
    for root, dirs, files in os.walk(VAULT_DIR):
        rel = os.path.relpath(root, VAULT_DIR)
        if rel.startswith(".obsidian") or rel.startswith(".trash"):
            continue
        dest = os.path.join(vdir, rel)
        if not os.path.isdir(dest):
            os.makedirs(dest, exist_ok=True)
        for fn in files:
            if fn.endswith(".md") or fn.endswith(".txt"):
                try:
                    shutil.copy2(os.path.join(root, fn), os.path.join(dest, fn))
                    n += 1
                except Exception:
                    pass
    # 压缩为 zip
    try:
        import zipfile
        zpath = os.path.join(BACKUP_ROOT, day, "vault-backup.zip")
        with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
            for root, dirs, files in os.walk(vdir):
                for fn in files:
                    full = os.path.join(root, fn)
                    arc = os.path.relpath(full, vdir)
                    z.write(full, arc)
        print("  已备份 {} 个 md/txt 文件 → {}".format(n, zpath))
        write_run_log("Vault 备份：{} 文件".format(n))
        return n
    except Exception as e:
        write_run_log("Vault zip 失败：" + str(e)[:80])
        return n


def backup_scripts():
    print("=== 备份核心配置脚本 ===")
    day = datetime.now().strftime("%Y%m%d")
    sdir = os.path.join(BACKUP_ROOT, day, "scripts")
    os.makedirs(sdir, exist_ok=True)
    n = 0
    for fn in os.listdir(SCRIPT_DIR):
        if fn.endswith(".py") and fn not in ("backup_all.py",):
            try:
                shutil.copy2(os.path.join(SCRIPT_DIR, fn), os.path.join(sdir, fn))
                n += 1
            except Exception:
                pass
    print("  已备份 {} 个脚本".format(n))
    write_run_log("脚本备份：{} 个".format(n))
    return n


def main():
    args = sys.argv[1:]
    want_tables = not args or "--tables" in args
    want_coze = not args or "--coze" in args
    want_vault = not args or "--vault" in args
    want_scripts = not args

    summary = {}
    if want_tables:
        summary["tables"] = backup_tables()
    if want_coze:
        summary["coze_workflows"] = backup_coze()
    if want_vault:
        summary["vault_files"] = backup_vault()
    if want_scripts:
        summary["scripts"] = backup_scripts()

    day = datetime.now().strftime("%Y%m%d")
    print("\n=== 备份完成，保存至：{}".format(os.path.join(BACKUP_ROOT, day)))
    # 写运行日志表
    try:
        from feishu_common import write_run_log_record
        write_run_log_record("全量备份", "本地脚本", "正常", "")
    except Exception:
        pass
    return summary


if __name__ == "__main__":
    main()
