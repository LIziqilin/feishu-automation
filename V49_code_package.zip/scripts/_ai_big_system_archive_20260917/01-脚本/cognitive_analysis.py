# -*- coding: utf-8 -*-
"""
============================================================
 cognitive_analysis.py - 个人AI系统 · 每月认知分析（P3 认知分析工作流本地实现）
============================================================
作用（每月1号 10:00 计划任务自动运行）：
  1. 读取飞书「决策日志表」上月全部决策记录（授权后 5 条起）
  2. 调用 DeepSeek 生成深度认知分析（4 部分：跨领域规律/认知盲区/能力迁移/下月提升建议）
  3. 归档 Obsidian「03-技术笔记库/认知复盘/月度分析」
  4. 推送飞书报告
  5. 写入运行日志表

用法（在 D:\\AI\\AI大系统\\01-脚本 目录）：
  python cognitive_analysis.py            # 生成+归档+推送
  python cognitive_analysis.py --dry      # 只打印不写入
  python cognitive_analysis.py --webhook <url>   # 推送到指定群
"""

import sys
import os
import json
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import ai_config as cfg
except Exception:
    cfg = None
from daily_report import get_tenant_token, fetch_records, fmt_cell, deepseek_chat, push_feishu
from feishu_common import write_run_log_record as _write_run_log_record

BASE_TOKEN = "FDxjb8JtvaZa72sUp0tcygVVn0y"
DECISION_TABLE = "tblQLwLpYnXXHown"   # 决策日志表


def write_run_log(msg):
    try:
        log_path = os.path.join(r"D:\AI\AI大系统\05-备份", "cognitive_analysis.log")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write("[{}] {}\n".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg))
    except Exception:
        pass


def _ts_date(ts):
    try:
        return datetime.fromtimestamp(int(ts) / 1000).strftime("%Y-%m-%d")
    except Exception:
        return str(ts)[:10]


def last_month_records(token):
    """读取决策日志表上月记录；上月无记录时降级返回全量并标注来源"""
    records = fetch_records(DECISION_TABLE, token)
    now = datetime.now()
    first = now.replace(day=1)
    lm_end = first - timedelta(days=1)
    lm_start = lm_end.replace(day=1)
    start_s, end_s = lm_start.strftime("%Y-%m-%d"), lm_end.strftime("%Y-%m-%d")

    def to_line(rec):
        fields = rec.get("fields", {})
        return " | ".join("{}={}".format(k, fmt_cell(v)) for k, v in fields.items() if fmt_cell(v))

    month_rows = []
    for rec in records:
        d = _ts_date(fmt_cell(rec.get("fields", {}).get("决策日期", "")))
        if start_s <= d <= end_s:
            month_rows.append(to_line(rec))

    if month_rows:
        return month_rows, "上月（{}）决策记录 {} 条".format(ym_str(lm_end), len(month_rows))
    all_rows = [to_line(rec) for rec in records]
    return all_rows, "上月无决策记录，降级使用全量 {} 条（建议本月开始记录决策）".format(len(all_rows))


def ym_str(date):
    return "{}年{}月".format(date.strftime("%Y"), date.strftime("%m"))


def main():
    dry = "--dry" in sys.argv
    webhook = None
    if "--webhook" in sys.argv:
        webhook = sys.argv[sys.argv.index("--webhook") + 1]

    now = datetime.now()
    first = now.replace(day=1)
    lm_end = first - timedelta(days=1)
    ym = "{}年{}月".format(lm_end.strftime("%Y"), lm_end.strftime("%m"))
    print("=== 月度认知分析（决策日志：{}）===".format(ym))

    token = get_tenant_token()
    rows, src_note = last_month_records(token)
    print("  {}".format(src_note))
    data_text = "\n".join(rows) if rows else "（{}）".format(src_note)

    prompt = (
        "你是资深认知发展顾问。基于用户的决策日志，输出 4 部分结构化分析：\n"
        "1. 跨领域规律：提炼不同决策领域的共性底层逻辑、通用思考框架\n"
        "2. 认知盲区：识别反复出现的判断偏差、知识短板、思维惯性陷阱\n"
        "3. 能力迁移：指出可从一个领域复用迁移到其他领域的方法与经验\n"
        "4. 下月提升建议：给出 3 条具体、可落地、有优先级的行动建议\n"
        "要求：结合具体决策案例分析，不泛泛而谈；语言专业凝练，每部分不超过 300 字。\n\n"
        "数据说明：{}。\n"
        "=== 决策日志 ===\n{}".format(src_note, data_text)
    )
    print("=== 生成认知分析（DeepSeek）... ===")
    result = deepseek_chat(prompt, max_tokens=2000)

    full = (
        "# 月度认知分析 {}\n\n> 生成方式：cognitive_analysis.py（P3 认知分析工作流本地实现）\n"
        "> 生成时间：{}\n> 数据源：决策日志表（{}）\n\n{}".format(
            ym, now.strftime("%Y-%m-%d %H:%M:%S"), ym, result)
    )
    print("=" * 50)
    print(full)
    print("=" * 50)

    fpath = ""
    if not dry:
        target = cfg.COGNITION_DIR.replace("/", "\\") + "\\月度分析"
        os.makedirs(target, exist_ok=True)
        fname = "月度认知分析-{}.md".format(ym)
        fpath = os.path.join(target, fname)
        with open(fpath, "w", encoding="utf-8") as f:
            f.write(full)
        print("[OK] 已归档：", fpath)
    else:
        print("(dry-run，未写入)")

    if not dry:
        push_text = "📊 【月度认知分析报告】{}\n\n{}".format(ym, result)
        ok = push_feishu(push_text, webhook)
        write_run_log("认知分析：{} ｜记录{}条 ｜推送={} ｜归档={}".format(
            ym, len(rows), "成功" if ok else "失败", fpath))
        # 运行日志沉淀
        try:
            _write_run_log_record("月度认知分析", "本地脚本", "正常", "")
        except Exception:
            pass
    else:
        write_run_log("dry-run：{}".format(ym))


if __name__ == "__main__":
    main()
