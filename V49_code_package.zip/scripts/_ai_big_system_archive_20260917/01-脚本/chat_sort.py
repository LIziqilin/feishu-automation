# -*- coding: utf-8 -*-
"""
============================================================
 chat_sort.py - 个人AI系统 · 每日聊天整理（P2「聊天记录整理」工作流本地实现）
============================================================
作用（每天 22:00 计划任务自动运行）：
  1. 读取 D:\\AI\\AI大系统\\05-备份\\wechat_today.txt（Work Buddy 导出的当日微信消息，一行一条）
  2. 若无文件或为空 → 静默退出（不打扰）
  3. 有内容 → DeepSeek 抽取 待办/洞察/学习记录 三类信息
  4. 把抽取结果推送飞书「洞察卡片」+ 写运行日志

启用方式（可选）：
  把当日微信消息粘到 D:\\AI\\AI大系统\\05-备份\\wechat_today.txt（一行一条）即可自动启用；
  不想要可删除计划任务「AI大系统-聊天整理」。

用法：
  python chat_sort.py            # 处理并推送
  python chat_sort.py --dry      # 只打印不推送
"""

import sys
import os
import json
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import ai_config as cfg
except Exception:
    cfg = None
from daily_report import get_tenant_token, deepseek_chat, push_feishu
from feishu_common import write_run_log_record as _write_run_log_record

SORT_FILE = r"D:\AI\AI大系统\05-备份\wechat_today.txt"
LOG_FILE = r"D:\AI\AI大系统\05-备份\chat_sort.log"


def write_run_log(msg):
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write("[{}] {}\n".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg))
    except Exception:
        pass


def main():
    dry = "--dry" in sys.argv
    if not os.path.isfile(SORT_FILE):
        write_run_log("无 wechat_today.txt，跳过")
        return
    with open(SORT_FILE, encoding="utf-8") as f:
        content = f.read().strip()
    if not content:
        write_run_log("wechat_today.txt 为空，跳过")
        return

    print("=== 聊天整理（{}字）===".format(len(content)))
    prompt = (
        "你是个人助理，从以下微信聊天记录中抽取三类信息，今天日期 {}。\n"
        "1. 【待办】别人请你做/你答应做的事（写清事项+对象）\n"
        "2. 【洞察】有价值的观点/信息（写清要点+价值）\n"
        "3. 【学习】值得记的知识点（写清知识点+来源）\n"
        "若无则写'无'。格式：每类一个列表，简洁，每条≤30字。\n\n"
        "=== 聊天记录 ===\n{}".format(datetime.now().strftime("%Y-%m-%d"), content[:4000])
    )
    print("=== DeepSeek 抽取... ===")
    try:
        result = deepseek_chat(prompt, max_tokens=800)
    except Exception as e:
        result = "【抽取失败】{}".format(str(e)[:100])
        write_run_log("抽取失败：" + str(e)[:100])

    card = "🧠 【每日洞察卡片】{}\n\n{}".format(datetime.now().strftime("%Y-%m-%d"), result)
    print("=" * 50)
    print(card)
    print("=" * 50)

    if dry:
        write_run_log("dry-run：已抽取")
        return

    ok = push_feishu(card)
    # 处理完清空文件，避免重复
    try:
        with open(SORT_FILE, "w", encoding="utf-8") as f:
            f.write("")
        write_run_log("已推送并清空文件，推送={}".format(ok))
    except Exception:
        pass
    try:
        _write_run_log_record("聊天整理", "本地脚本", "正常" if ok else "异常", "")
    except Exception:
        pass


if __name__ == "__main__":
    main()
