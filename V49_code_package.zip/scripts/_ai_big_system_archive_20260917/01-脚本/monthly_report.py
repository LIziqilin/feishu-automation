# -*- coding: utf-8 -*-
"""
============================================================
 monthly_report.py - 个人AI系统 · 每月月报生成（P2 月报工作流本地实现）
============================================================
作用：
  1. 用飞书开放平台 API 拉取 全部核心表+扩展表（任务/学习/间隔重复/运行日志/
     知识入库/决策日志）上月全量数据
  2. 调用 DeepSeek 生成结构化月报
  3. 归档到 Obsidian 日志/月报/月报-{YYYY}年{MM}月.md
  4. --push 时通过飞书 webhook 推送（接入飞书自动化）

用法（在 D:\\AI\\AI大系统\\01-脚本 目录）：
  python monthly_report.py            # 生成并归档上月月报
  python monthly_report.py --dry      # 只打印不写入
  python monthly_report.py --push     # 生成+归档+推送飞书
"""

import sys
import os
import json
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import ai_config as cfg
except Exception:
    cfg = None
# 复用日报脚本的飞书 API 直读 / DeepSeek / 推送层
from daily_report import get_tenant_token, fetch_records, fmt_cell, deepseek_chat, push_feishu
from feishu_common import write_run_log_record as _write_run_log_record

BASE_TOKEN = "FDxjb8JtvaZa72sUp0tcygVVn0y"
TABLES = {
    "任务表": "tblHyGFQ3uzH0IyF",
    "学习打卡表": "tbl0tfLmDWMD0o77",
    "间隔重复表": "tblPtciwNAUxkc1U",
    "运行日志表": "tbl3hkFkgrSxlvUx",
    "知识入库表": "tblcXpMnbAYcnjs6",
    "决策日志表": "tblQLwLpYnXXHown",
}


def last_month_dates():
    """返回上个月的全部日期字符串列表（YYYY-MM-DD）"""
    now = datetime.now()
    first_this_month = now.replace(day=1)
    last_month_end = first_this_month - timedelta(days=1)
    last_month_start = last_month_end.replace(day=1)
    total = (last_month_end - last_month_start).days + 1
    return [(last_month_start + timedelta(days=i)).strftime("%Y-%m-%d") for i in range(total)]


def table_month_text(name, records, dates):
    """把表记录转成文本，只保留含上月日期的记录"""
    month_rows = []
    for rec in records:
        fields = rec.get("fields", {})
        line = " | ".join("{}={}".format(k, fmt_cell(v)) for k, v in fields.items() if fmt_cell(v))
        if any(d in line for d in dates):
            month_rows.append(line)
    if month_rows:
        return "【{} 上月数据（{}条）】\n{}".format(name, len(month_rows), "\n".join(month_rows))
    return "【{} 上月数据（0条）】无记录".format(name)


def write_run_log(msg):
    """把运行摘要追加到 monthly_report.log（统一留痕）"""
    try:
        log_path = os.path.join(r"D:\AI\AI大系统\05-备份", "monthly_report.log")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write("[{}] {}\n".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg))
    except Exception:
        pass


def main():
    dry = "--dry" in sys.argv
    push = "--push" in sys.argv
    webhook = None
    if "--webhook" in sys.argv:
        webhook = sys.argv[sys.argv.index("--webhook") + 1]

    # 上月范围
    now = datetime.now()
    first_this_month = now.replace(day=1)
    lm_end = first_this_month - timedelta(days=1)
    lm_start = lm_end.replace(day=1)
    dates = last_month_dates()
    ym = lm_end.strftime("%Y年%m月")
    print("=== 拉取上月数据（{} ~ {}）===".format(dates[0], dates[-1]))
    token = get_tenant_token()
    sections = []
    no_perm = []
    for name, tid in TABLES.items():
        try:
            records = fetch_records(tid, token)
            print("  {}: 共{}条".format(name, len(records)))
            sections.append(table_month_text(name, records, dates))
        except Exception as e:
            no_perm.append(name)
            print("  {}: 跳过（{}）".format(name, str(e)[:60]))
            sections.append("【{} 上月数据（跳过）】无读取权限：{}".format(name, str(e)[:40]))

    if no_perm:
        write_run_log("无权限表：{}（如需月报包含扩展表，请在飞书把 Coze 应用加为这些表协作者）".format(",".join(no_perm)))

    data_text = "\n\n".join(sections)
    prompt = (
        "你是个人成长深度复盘顾问，根据以下上月全量数据生成月度深度复盘报告。\n"
        "包含模块：\n"
        "1. 核心数据概览：任务、学习、复习、系统四大维度数据\n"
        "2. 趋势分析：本月环比变化，核心规律\n"
        "3. 能力成长：本月掌握的核心技能、认知提升\n"
        "4. 问题与不足：核心短板、改进方向\n"
        "5. 下月目标：3个核心目标+拆解路径\n"
        "专业、深刻、有数据支撑，1500字以内。\n\n"
        "上月数据（{}）：\n".format(ym) + data_text
    )
    print("=== 生成月报中（DeepSeek）... ===")
    report = deepseek_chat(prompt, max_tokens=2000)

    fname = "月报-{}.md".format(ym)
    full = (
        "# 月报 {}（{} ~ {}）\n\n> 生成方式：monthly_report.py（P2 月报工作流本地实现）\n> 生成时间：{}\n\n".format(
            ym, dates[0], dates[-1], now.strftime("%Y-%m-%d %H:%M:%S")) + report
    )
    print("=" * 50)
    print(full)
    print("=" * 50)

    fpath = ""
    if not dry:
        target = os.path.join(cfg.OBSIDIAN_VAULT.replace("/", "\\"), "日志", "月报")
        os.makedirs(target, exist_ok=True)
        fpath = os.path.join(target, fname)
        with open(fpath, "w", encoding="utf-8") as f:
            f.write(full)
        print("[OK] 已归档：", fpath)
    else:
        print("(dry-run，未写入)")

    if push and not dry:
        push_text = "📈 月报 {}\n\n{}".format(ym, report)
        ok = push_feishu(push_text, webhook)
        write_run_log("月报生成+推送：{} ｜归档={} ｜推送={}".format(ym, fpath, "成功" if ok else "失败"))
    elif not dry:
        write_run_log("月报生成（未推送）：{} ｜归档={}".format(ym, fpath))
    else:
        write_run_log("dry-run：{}".format(ym))

    # P2 运行日志沉淀
    try:
        _write_run_log_record("每月月报", "本地脚本", "正常", "")
    except Exception:
        pass


if __name__ == "__main__":
    main()
