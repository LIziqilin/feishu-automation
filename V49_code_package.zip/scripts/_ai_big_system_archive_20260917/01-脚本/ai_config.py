# -*- coding: utf-8 -*-
"""
============================================================
 ai_config.py - 个人AI系统 · 集中配置文件
============================================================
说明：
  本文件是所有脚本（bridge / monitor）共用的"唯一配置中心"。
  你只需要在这里填写一次信息，其他脚本都会自动读取，不用到处改。

使用方法：
  1. 用"记事本"打开本文件
  2. 把下面【需要你填写】的位置改成你的真实信息
  3. 保存即可（注意：不要动引号和格式）

------------------------------------------------------------
★ 每一项是什么、去哪找，都写在注释里，照抄就行 ★
------------------------------------------------------------
"""

# ============================================================
# 一、AnythingLLM 配置（Day 9 已完成，一般不用改）
# ============================================================

# AnythingLLM 的本地地址（默认 http://127.0.0.1:3001，不要改）
ANYLLM_BASE_URL = "http://127.0.0.1:3001"

# 【需要你填写】AnythingLLM 的 API Key
# 在哪找：打开 AnythingLLM → 左下角设置 ⚙ → 左侧「API」→ 复制 API Key
ANYLLM_API_KEY = "sk-8f2807a36536caef757c1245eae3b135e81a0173b50c87110e7d14fb4acaa4d9"

# 【需要你填写】默认使用哪个知识库工作区（填名字即可）
# 可用的工作区（你电脑上已有的）：
#   "工程总监学习"   - 你的工程知识库（推荐默认）
#   "我的第二大脑"   - obsidian 笔记
#   "认知框架"
#   "个人知识库"
ANYLLM_WORKSPACE = "工程总监学习"

# ============================================================
# 二、Obsidian 知识库（Vault）路径
# ============================================================

# 【需要你填写】你的 Obsidian 笔记库（Vault）的完整路径
# 你电脑上的路径是：D:\AI\finished Brain
# 注意：这里要用正斜杠 / 或双反斜杠 \\，否则脚本会报错
OBSIDIAN_VAULT = "D:/AI/finished Brain"

# Obsidian 里放"技能/方法论"的目录（P2 Skill 孵化要写入这里）
SKILL_DIR = "D:/AI/finished Brain/_Skills"

# 日报 / 周报 / 月报 归档目录（P2 报告体系要写入这里）
DIARY_DIR = "D:/AI/finished Brain/日志/日报"
WEEKLY_DIR = "D:/AI/finished Brain/日志/周报"
MONTHLY_DIR = "D:/AI/finished Brain/日志/月报"

# 认知复盘目录（P3 认知分析要写入这里）
COGNITION_DIR = "D:/AI/finished Brain/03-技术笔记库/认知复盘"

# ============================================================
# 三、飞书告警 Webhook（Day 12 要填）
# ============================================================

# 【已填写 2026-08-31】飞书"系统告警群"自定义机器人的 Webhook 地址
FEISHU_WEBHOOK = "https://open.feishu.cn/open-apis/bot/v2/hook/295ccce2-4947-40b7-bcf8-989fc0d902af"

# ============================================================
# 三-b、API Key（2026-08-31 用户提供，用于成本审计/成本查询）
# ============================================================

# DeepSeek API Key（查余额/用量，成本审计用）
# 在哪找：platform.deepseek.com → API Keys
DEEPSEEK_API_KEY = "sk-14a5d1810331429c9091760bc31c3e06"

# 硅基流动 API Key（嵌入等模型调用，成本审计用）
# 在哪找：cloud.siliconflow.cn → API 密钥
# 注意：硅基流动余额查询接口已官方废弃（410），余额需登录控制台查看
SILICONFLOW_API_KEY = "sk-lnzbmcipwanjsnbvuqxueelhnjqaejgyrpcezppdpazezbnr"

# DeepSeek 余额查询接口（P0 成本基线已实测：余额 8.71 元 CNY）
DEEPSEEK_BALANCE_URL = "https://api.deepseek.com/user/balance"
# 硅基流动模型列表接口（验证 Key 可用性）
SILICONFLOW_MODELS_URL = "https://api.siliconflow.cn/v1/models"

# ============================================================
# 三-c、Coze「个人AI助理」飞书应用凭证（2026-08-31 用户提供）
# ============================================================

# 这是 Coze「个人AI助理」Bot 接入飞书生成的应用凭证（App ID/Secret）
# 已验证有效：可换取飞书 tenant_access_token（用于飞书开放平台 API）
# 注意：P3「Prompt动态调优」更新 Coze Bot Prompt 需要的是 Coze 平台的
#       Personal Access Token（Coze → 个人设置 → API 令牌），不是本凭证。
COZE_FEISHU_APP_ID = "cli_aa04f132f5f95bb7"
COZE_FEISHU_APP_SECRET = "DPb8JZztNGxmPRstRCCsyhRmmpewwPaU"
# Coze API 令牌（P3 Prompt 调优用，2026-08-31 用户提供并已验证有效）
COZE_API_TOKEN = "pat_r3mARXOrdaZ8ChF0Fs9qApCo1umNcrY3hIbsgGQ4n2XdaE63f8ZaaVbvkkU964Gr"
# Coze 工作空间 ID（个人空间，已验证）
COZE_WORKSPACE_ID = "7678133526931832838"
# 主 Bot「finished Brain个人AI助理」Bot ID（已验证）
COZE_BOT_ID = "7678145027994550291"

# 本地桥接服务地址（Hermes 桥接，端口 7860，供各脚本调用 /health /write_note /write_skill /get_wechat_msg /query_kb /run_stats 等接口）
BRIDGE_URL = "http://127.0.0.1:7860"

# ============================================================
# 四、本地服务检查清单（监控脚本用）
# ============================================================

# 要监控的本地服务，格式：显示名 = (检查用的网址)
# 如果你以后新增了服务，按同样格式加一行即可
SERVICES = {
    "AnythingLLM": "http://127.0.0.1:3001",   # 知识库
    "Ollama":       "http://127.0.0.1:11434",  # 本地模型（备用）
    "Hermes桥接":    "http://127.0.0.1:7860",   # 本地中转服务（本套脚本提供）
    "HermesAgent":  "http://127.0.0.1:8644/health",  # Hermes Agent 桌面应用（2026-08-31 用户确认端口）
}

# 磁盘剩余空间告警线（单位：GB，低于这个值就告警）
DISK_WARN_GB = 10

# ============================================================
# 五、监控脚本自身配置
# ============================================================

# 端口速记（2026-08-31 确认）：
#   3001 = AnythingLLM（127.0.0.1 仅本机）
#   7860 = Hermes 桥接服务（本套脚本）
#   11434 = Ollama
#   8644 = Hermes Agent 桌面应用 webhook 服务（0.0.0.0，可公网访问——如不需要对外请改本机监听）

# 心跳检查间隔（秒），默认 300 秒 = 5 分钟
CHECK_INTERVAL = 300

# 是否开机自启（True=是 / False=否，改这里不会自动生效，
# 需要配合 start_monitor.bat 使用，见《操作手册》）
AUTO_START = True

# 监控日志保存位置（脚本会自动创建）
MONITOR_LOG = "D:/AI/AI大系统/05-备份/monitor.log"
