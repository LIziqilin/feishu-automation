# -*- coding: utf-8 -*-
"""
============================================================
 daily_reminder.py - 个人AI系统 · 每日督办提醒（整体方案P1「督办工作流」+「连续3天未打卡告警」本地实现）
============================================================
作用（每天 09:00 计划任务自动运行）：
  1. 任务督办：检查任务表 → 今日截止 / 明日截止 / 已逾期 任务
  2. 学习监督：检查学习打卡表 → 连续 ≥3 天未打卡则告警
  3. 推送飞书提醒（有督办事项才推，全无则静默）
  4. 写入运行日志表

用法（在 D:\\AI\\AI大系统\\01-脚本 目录）：
  python daily_reminder.py            # 检查+推送
  python daily_reminder.py --dry      # 只打印不推送
  python daily_reminder.py --webhook <url>   # 推送到指定群
"""

import sys
import os
import json
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import ai_config as cfg
except Exception:
    cfg = None
from daily_report import get_tenant_token, fetch_records, fmt_cell, push_feishu
from feishu_common import write_run_log_record as _write_run_log_record

TASK_TABLE = "tblHyGFQ3uzH0IyF"      # 任务表
STUDY_TABLE = "tbl0tfLmDWMD0o77"     # 学习打卡表


def write_run_log(msg):
    try:
        log_path = os.path.join(r"D:\AI\AI大系统\05-备份", "daily_reminder.log")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write("[{}] {}\n".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg))
    except Exception:
        pass


def _ts_date(ts):
    try:
        return datetime.fromtimestamp(int(ts) / 1000).strftime("%Y-%m-%d")
    except Exception:
        return str(ts)[:10]


def main():
    dry = "--dry" in sys.argv
    webhook = None
    if "--webhook" in sys.argv:
        webhook = sys.argv[sys.argv.index("--webhook") + 1]

    now = datetime.now()
    today = now.strftime("%Y-%m-%d")
    tomorrow = (now + timedelta(days=1)).strftime("%Y-%m-%d")
    print("=== 每日督办提醒（{}）===".format(today))
    token = get_tenant_token()

    # 1. 任务督办
    due_today, due_tomorrow, overdue = [], [], []
    try:
        task_recs = fetch_records(TASK_TABLE, token)
        for rec in task_recs:
            f = rec.get("fields", {})
            name = fmt_cell(f.get("任务名称"))
            status = fmt_cell(f.get("状态", ""))
            prio = fmt_cell(f.get("优先级", ""))
            deadline = _ts_date(fmt_cell(f.get("截止时间", "")))
            if not name or name == "None" or not deadline:
                continue
            if status in ("已完成", "已取消"):
                continue
            tag = "[{}]".format(prio) if prio else ""
            if deadline < today:
                overdue.append("{}{}（逾期{}天）".format(tag, name, (datetime.strptime(today, "%Y-%m-%d") - datetime.strptime(deadline, "%Y-%m-%d")).days))
            elif deadline == today:
                due_today.append("{}{}".format(tag, name))
            elif deadline == tomorrow:
                due_tomorrow.append("{}{}".format(tag, name))
    except Exception as e:
        print("[!] 任务表读取失败：", str(e)[:60])

    # 2. 学习打卡监督：检查最近连续未打卡天数
    no_checkin_days = 0
    study_dates = set()
    try:
        study_recs = fetch_records(STUDY_TABLE, token)
        for rec in study_recs:
            d = _ts_date(fmt_cell(rec.get("fields", {}).get("日期", "")))
            if d:
                study_dates.add(d)
        for i in range(1, 8):  # 回看 7 天
            d = (now - timedelta(days=i)).strftime("%Y-%m-%d")
            if d not in study_dates:
                no_checkin_days += 1
            else:
                break  # 找到最近打卡日，断档天数 = i-1
    except Exception as e:
        print("[!] 学习表读取失败：", str(e)[:60])

    # 3. 组装提醒
    lines = []
    if overdue:
        lines.append("🔴 **逾期任务（{}）**：\n{}".format(len(overdue), "\n".join("· " + x for x in overdue[:8])))
    if due_today:
        lines.append("⏰ **今日截止（{}）**：\n{}".format(len(due_today), "\n".join("· " + x for x in due_today[:8])))
    if due_tomorrow:
        lines.append("🗓 **明日截止（{}）**：\n{}".format(len(due_tomorrow), "\n".join("· " + x for x in due_tomorrow[:8])))
    if no_checkin_days >= 3:
        lines.append("📚 **学习监督**：已连续 {} 天未学习打卡，请补卡（防止学习链条断裂）".format(no_checkin_days))

    if not lines:
        print("  今日无督办事项，静默。")
        if not dry:
            write_run_log("督办：无事项（{}）".format(today))
            try:
                _write_run_log_record("任务督办", "本地脚本", "正常", "无督办事项")
            except Exception:
                pass
        return

    report = "📌 【每日督办提醒】{}\n\n{}".format(today, "\n\n".join(lines))
    print("=" * 50)
    print(report)
    print("=" * 50)

    if dry:
        write_run_log("dry-run：督办 {} 条".format(len(lines)))
        return

    ok = push_feishu(report, webhook)
    write_run_log("督办推送：{} ｜逾期{}今日{}明日{}未打卡{} ｜推送={}".format(
        today, len(overdue), len(due_today), len(due_tomorrow), no_checkin_days, "成功" if ok else "失败"))
    try:
        _write_run_log_record("任务督办", "本地脚本", "正常", "")
    except Exception:
        pass


if __name__ == "__main__":
    main()
