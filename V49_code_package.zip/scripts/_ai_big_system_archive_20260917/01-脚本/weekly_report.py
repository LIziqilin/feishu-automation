# -*- coding: utf-8 -*-
"""
============================================================
 weekly_report.py - 个人AI系统 · 每周周报生成（P2 周报工作流本地实现）
============================================================
作用：
  1. 用飞书开放平台 API 拉取 任务表/学习打卡表/间隔重复表/运行日志表 本周（7天）数据
  2. 调用 DeepSeek 生成结构化周报
  3. 归档到 Obsidian 日志/周报/周报-{YYYY}年第{周数}周.md
  4. --push 时通过飞书 webhook 推送（接入飞书自动化）

用法（在 D:\\AI\\AI大系统\\01-脚本 目录）：
  python weekly_report.py            # 生成并归档本周周报
  python weekly_report.py --dry      # 只打印不写入
  python weekly_report.py --push     # 生成+归档+推送飞书
"""

import sys
import os
import json
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import ai_config as cfg
except Exception:
    cfg = None
# 复用日报脚本的飞书 API 直读 / DeepSeek / 推送层（同一套稳定实现）
from daily_report import get_tenant_token, fetch_records, fmt_cell, deepseek_chat, push_feishu
from feishu_common import write_run_log_record as _write_run_log_record

BASE_TOKEN = "FDxjb8JtvaZa72sUp0tcygVVn0y"
TABLES = {
    "任务表": "tblHyGFQ3uzH0IyF",
    "学习打卡表": "tbl0tfLmDWMD0o77",
    "间隔重复表": "tblPtciwNAUxkc1U",
    "运行日志表": "tbl3hkFkgrSxlvUx",
}


def week_dates(n=7):
    """返回最近 n 天的日期字符串列表（YYYY-MM-DD）"""
    today = datetime.now()
    return [(today - timedelta(days=i)).strftime("%Y-%m-%d") for i in range(n)]


def table_week_text(name, records, dates):
    """把表记录转成文本，只保留含本周（7天内）日期的记录"""
    week_rows = []
    for rec in records:
        fields = rec.get("fields", {})
        line = " | ".join("{}={}".format(k, fmt_cell(v)) for k, v in fields.items() if fmt_cell(v))
        if any(d in line for d in dates):
            week_rows.append(line)
    if week_rows:
        return "【{} 本周数据（{}条）】\n{}".format(name, len(week_rows), "\n".join(week_rows))
    return "【{} 本周数据（0条）】无本周记录".format(name)


def write_run_log(msg):
    """把运行摘要追加到 weekly_report.log（统一留痕）"""
    try:
        log_path = os.path.join(r"D:\AI\AI大系统\05-备份", "weekly_report.log")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write("[{}] {}\n".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg))
    except Exception:
        pass


def main():
    dry = "--dry" in sys.argv
    push = "--push" in sys.argv
    webhook = None
    if "--webhook" in sys.argv:
        webhook = sys.argv[sys.argv.index("--webhook") + 1]

    dates = week_dates(7)
    print("=== 拉取本周数据（{} ~ {}）===".format(dates[-1], dates[0]))
    token = get_tenant_token()
    sections = []
    for name, tid in TABLES.items():
        records = fetch_records(tid, token)
        print("  {}: 共{}条".format(name, len(records)))
        sections.append(table_week_text(name, records, dates))

    data_text = "\n\n".join(sections)
    prompt = (
        "你是个人效率复盘顾问，根据以下本周（7天）数据生成周度复盘报告。\n"
        "包含模块：\n"
        "1. 本周成果：任务完成率、学习总时长、核心产出\n"
        "2. 数据趋势：对比上周，进步和退步的地方\n"
        "3. 问题与反思：遇到的问题、原因分析\n"
        "4. 下周计划：3个核心目标+关键任务\n"
        "结构清晰，数据支撑，800字以内。\n\n"
        "本周数据：\n" + data_text
    )
    print("=== 生成周报中（DeepSeek）... ===")
    report = deepseek_chat(prompt, max_tokens=1200)

    now = datetime.now()
    iso = now.isocalendar()
    fname = "周报-{}年第{}周.md".format(now.strftime("%Y"), iso[1])
    full = (
        "# 周报 {}年第{}周（{} ~ {}）\n\n> 生成方式：weekly_report.py（P2 周报工作流本地实现）\n> 生成时间：{}\n\n".format(
            now.strftime("%Y"), iso[1], dates[-1], dates[0],
            now.strftime("%Y-%m-%d %H:%M:%S")) + report
    )
    print("=" * 50)
    print(full)
    print("=" * 50)

    fpath = ""
    if not dry:
        target = os.path.join(cfg.OBSIDIAN_VAULT.replace("/", "\\"), "日志", "周报")
        os.makedirs(target, exist_ok=True)
        fpath = os.path.join(target, fname)
        with open(fpath, "w", encoding="utf-8") as f:
            f.write(full)
        print("[OK] 已归档：", fpath)
    else:
        print("(dry-run，未写入)")

    if push and not dry:
        push_text = "📊 周报 {}年第{}周\n\n{}".format(now.strftime("%Y"), iso[1], report)
        ok = push_feishu(push_text, webhook)
        write_run_log("周报生成+推送：{}年第{}周 ｜归档={} ｜推送={}".format(
            now.strftime("%Y"), iso[1], fpath, "成功" if ok else "失败"))
    elif not dry:
        write_run_log("周报生成（未推送）：{}年第{}周 ｜归档={}".format(now.strftime("%Y"), iso[1], fpath))
    else:
        write_run_log("dry-run：{}年第{}周".format(now.strftime("%Y"), iso[1]))

    # P2 运行日志沉淀
    try:
        _write_run_log_record("每周周报", "本地脚本", "正常", "")
    except Exception:
        pass


if __name__ == "__main__":
    main()
