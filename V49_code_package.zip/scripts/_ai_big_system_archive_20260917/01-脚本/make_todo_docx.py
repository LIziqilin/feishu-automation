# -*- coding: utf-8 -*-
"""生成《个人AI系统·待办清单.docx》"""

import os
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

OUT = r"D:\AI\AI大系统\待办清单.docx"


def set_run_font(run, cn_font="宋体", en_font="Arial", size=12, bold=False, color=RGBColor(0, 0, 0)):
    run.font.name = en_font
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color
    r = run._element.rPr
    rFonts = r.find(qn('w:rFonts'))
    if rFonts is None:
        rFonts = OxmlElement('w:rFonts')
        r.append(rFonts)
    rFonts.set(qn('w:eastAsia'), cn_font)


def add_title(doc, text):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(18)
    run = p.add_run(text)
    set_run_font(run, cn_font="黑体", size=18, bold=True)
    return p


def add_heading(doc, text, level=1):
    p = doc.add_paragraph()
    if level == 1:
        p.paragraph_format.space_before = Pt(14)
        p.paragraph_format.space_after = Pt(6)
        run = p.add_run(text)
        set_run_font(run, cn_font="黑体", size=16, bold=True)
    else:
        p.paragraph_format.space_before = Pt(11)
        p.paragraph_format.space_after = Pt(5)
        run = p.add_run(text)
        set_run_font(run, cn_font="黑体", size=14, bold=True)
    # 设置大纲级别，便于生成真实标题
    pPr = p._p.get_or_add_pPr()
    outline = OxmlElement('w:outlineLvl')
    outline.set(qn('w:val'), str(level - 1))
    pPr.append(outline)
    return p


def add_body(doc, text, indent=True, bold=False):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = 1.5
    pf.space_before = Pt(0)
    pf.space_after = Pt(0)
    if indent:
        pf.first_line_indent = Pt(24)  # 2字符
    run = p.add_run(text)
    set_run_font(run, size=12, bold=bold)
    return p


def add_table(doc, headers, rows, col_widths=None):
    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.style = 'Table Grid'
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    # 表头
    for j, h in enumerate(headers):
        cell = table.cell(0, j)
        cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.first_line_indent = Pt(0)
        p.paragraph_format.space_before = Pt(2)
        p.paragraph_format.space_after = Pt(2)
        run = p.add_run(h)
        set_run_font(run, size=10.5, bold=True)
        # 浅灰底
        tcPr = cell._tc.get_or_add_tcPr()
        shd = OxmlElement('w:shd')
        shd.set(qn('w:val'), 'clear')
        shd.set(qn('w:fill'), 'D9D9D9')
        tcPr.append(shd)
    # 数据行
    for i, row in enumerate(rows):
        for j, val in enumerate(row):
            cell = table.cell(i + 1, j)
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT if len(str(val)) > 12 else WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.first_line_indent = Pt(0)
            p.paragraph_format.space_before = Pt(2)
            p.paragraph_format.space_after = Pt(2)
            run = p.add_run(str(val))
            set_run_font(run, size=10.5)
    if col_widths:
        for j, w in enumerate(col_widths):
            for row in table.rows:
                row.cells[j].width = Cm(w)
    return table


def main():
    doc = Document()
    # 页面设置 A4，边距2.5cm
    sec = doc.sections[0]
    sec.page_width = Cm(21.0)
    sec.page_height = Cm(29.7)
    sec.top_margin = Cm(2.5)
    sec.bottom_margin = Cm(2.5)
    sec.left_margin = Cm(2.5)
    sec.right_margin = Cm(2.5)

    # ===== 标题 =====
    add_title(doc, "个人AI系统 · 待办清单")
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("（AI 助手无法代办、需你手动完成的事项 · 按优先级排列）")
    set_run_font(run, cn_font="楷体", size=12)
    p.paragraph_format.space_after = Pt(12)

    # ===== 说明 =====
    add_heading(doc, "一、说明", 1)
    add_body(doc, "本清单依据《整体方案》及 P0—P3 操作手册整理，列出必须由你本人操作、AI 助手无法代办的全部事项，按优先级从高到低排列。每完成一项，请在编号前打勾。")
    add_body(doc, "以下工作已由 AI 助手代为完成并验证，无需你重复操作：① Day 10 知识检索中转脚本（anyllm_query.py）；② 本地桥接服务（端口 7860，9接口）；③ 系统监控脚本（monitor.py，每5分钟巡检+自愈）；④ Day 12 告警链路（Webhook 已填、实测通过、开机自启已配）；⑤ 端到端自检脚本（test_e2e.py 本地5项 5/5通过）；⑥ 方案原稿归档与各阶段执行清单、Coze 工作流配置包（P1/P2/P3 复制即用配置包+《Coze工作流搭建总手册》）；⑦ 飞书「个人AI数据中枢」：7张表+3大看板+表间关联已建；⑧ 知识库体检并清理3个垃圾空文件；⑨ 2026-08-31 第一轮：Node.js v20.20.2、Coze令牌验证、DeepSeek余额8.71元、硅基充值验证、HermesAgent端口8644纳入监控、监控自愈、运行日志补录7条、/run_stats接口；⑩ 2026-08-31 第二轮：Coze主Bot配置核查（任务工作流已绑定）、P0知识检索真实链路验证、体检清理；⑪ 2026-08-31 第三轮（P1/P2/P3全面核查）：P2归档目录（日报/周报/月报）与P3目录（系统运维/Prompt备份/成本审计/认知复盘/月度分析）已创建、运行日志表补录4条（**核心表31条，P2前置数据量≥30条已达标**）、P3 Prompt调优脚本实测可用（已备份当前Prompt）、P2配置包完整性核查通过、新增 daily_report.py 日报参考实现并已生成归档今日真实日报；⑫ 2026-08-31 日报接入飞书自动化：daily_report.py 升级为飞书开放平台API直读3表（不依赖 lark-cli 登录态）、注册 Windows 计划任务「AI大系统-每日日报」每天22:15自动运行（生成→归档Obsidian→飞书webhook推送），已实测推送成功；⑬ 2026-08-31 周报接入飞书自动化：新建 weekly_report.py（复用飞书API层直读4表）并注册 Windows 计划任务「AI大系统-每周周报」每周五17:10自动运行（生成→归档Obsidian日志/周报→飞书webhook推送），已实测推送成功并生成首份周报；⑭ 2026-08-31 月报接入飞书自动化：新建 monthly_report.py（直读6表）并注册 Windows 计划任务「AI大系统-每月月报」每月1号09:30自动运行（生成→归档Obsidian日志/月报→飞书webhook推送），schtasks环境实测推送成功并生成首份月报；⑮ 2026-08-31 知识库体检+Skill孵化本地版：新建 health_check.py（扫Vault+缺口分析+推送，计划任务周一02:00）与 skill_incubate.py（运行日志模式识别+推送，计划任务周日23:00），均实测推送成功；⑯ 2026-08-31 Coze云端范围界定：确认 Coze 云端无法访问本地7860接口，P2 六工作流已由本地计划任务全部覆盖（Coze 只需优先搭 P0 知识检索+可选聊天整理/认知分析），详见《Coze云端搭建范围界定.md》；⑰ 2026-08-31 P2全局异常告警+运行日志沉淀：新建 feishu_common.py（写运行日志表+失败告警推送），5脚本已接入，运行日志表自然增长至22+条；⑱ 2026-08-31 P3成本审计+Prompt调优本地版：新建 cost_audit.py（月末自动审计+20元红线告警+无效流程识别，注册月末任务）与 prompt_tune.py（每月2号生成优化方案推送确认，安全不自动更新，注册计划任务）；⑲ 2026-08-31 核查确认扩展表未授权：Coze 应用仅可读写4张核心表，知识入库/决策日志/用户画像3张扩展表需用户在飞书加应用为协作者（影响月报扩展表数据与认知分析）；⑳ 2026-08-31 扩展表授权完成并解锁 P3 认知分析：用户授权后 Coze 应用可读写全部7张表（知识入库5/决策日志5/用户画像5全部可读）；新建 cognitive_analysis.py（P3 认知分析本地版：读决策日志→DeepSeek 4部分认知分析→归档03-技术笔记库/认知复盘/月度分析→推送，上月无记录自动降级全量），注册计划任务「AI大系统-认知分析」每月1号10:00 首跑实测通过；月报扩展表数据自动恢复。以上文件均存放于 D:\\AI\\AI大系统。㉑ 2026-08-31 第四轮（P1/P2/P3再次全面排查）：晨间简报本地版 daily_briefing.py（拉任务/学习/间隔重复真实数据→DeepSeek生成个性化简报→webhook推送）并注册计划任务「AI大系统-晨间简报」每天07:00自动运行（实测推送成功，无需再手动搭飞书自动化流程，飞书方案变为可选项）；㉒ 每日督办 daily_reminder.py（任务截止前1天/今日/逾期督办+连续≥3天未打卡学习监督）并注册计划任务「AI大系统-每日督办」每天09:00自动运行（实测发现连续7天未打卡已推送提醒）；㉓ 费曼学习辅助 feynman_assist.py（输入主题→DeepSeek生成费曼四步：大白话复述/一句话定义+类比/卡壳自查/口述提纲→写Obsidian费曼输出目录+学习打卡表，含单选选项自动匹配修复），按需运行已实测全链路成功（已生成3篇费曼笔记）。㉔ 2026-08-31 复习提醒本地版：新建 review_reminder.py（每天20:00读间隔重复表今日到期卡片→推送复习清单+未打卡提醒）并注册计划任务「AI大系统-复习提醒」（实测推送成功，滴答清单手机提醒降级为可选增强）；㉕ 2026-08-31 P3前置全量备份：新建 backup_all.py（①导出7张表CSV快照 ②Coze工作流JSON备份【正确端点GET /v1/workflows?workspace_id=，实测备份5个工作流】③Obsidian Vault 272个md/txt压缩备份 ④19个核心脚本备份）并注册计划任务「AI大系统-每周备份」每周日22:30；首份备份已生成于 05-备份/backup/20260831/，满足 P3「全量备份前置」与「每周导出备份」运维要求。㉖ 2026-08-31 P0 飞书端到端测试 3 项全部通过：①对话连通✅ ②创建任务✅（成功写入数据中枢任务表）③查询任务✅（返回数据中枢真实记录）；过程中排查修复 Coze 工作流连错表格问题（coze_duoweibiaoge_renwubiao 原连旧表 SOHybNGNnaj0BMs5hN6cDtxQnAb，已统一改为数据中枢 FDxjb8JtvaZa72sUp0tcygVVn0y 任务表 tblHyGFQ3uzH0IyF，查询筛选状态不等于已完成）；完整排查记录见《端到端测试-飞书手动3项.md》。")

    # ===== 总览表 =====
    add_heading(doc, "二、待办总览（按优先级）", 1)
    add_table(doc,
        ["优先级", "事项", "所属阶段", "平台/工具", "预计耗时"],
        [
            ["P0·立即", "Coze工作流搭建（总手册+配置包已备，见《Coze工作流搭建总手册.md》）", "P0 Day11", "Coze", "60分钟/个"],
            ["P0·立即", "端到端测试 3 项飞书手动 ✅已全部通过（①对话连通 ②创建任务 ③查询任务，2026-08-31）", "P0 Day13", "飞书", "已完成"],
            ["P0·立即", "BIOS定时开机06:50", "P0 Day13", "BIOS", "20分钟"],
            ["P0·立即", "发布飞书应用1.0.0正式版", "P0 Day13", "飞书开放平台", "5分钟"],
            ["P0·立即", "P0复盘+填4张表数据（✅成本基线已由AI实测：DeepSeek余额8.71元，硅基已充值并验证成功）", "P0 Day14", "DeepSeek/硅基", "20分钟"],
            ["P1·本周", "滴答清单复习提醒 🔶可选（本地复习提醒已实现：每天20:00飞书推送）", "P1第3周", "滴答清单/本地", "可选30分钟"],
            ["P1·本周", "Notion费曼输出库+每日费曼", "P1第3周", "Notion", "每日20分钟"],
            ["P1·本周", "用户画像表 ✅已由助手建好（含4扩展字段+分层视图+示例数据）", "P1第3周", "飞书表格", "已完成"],
            ["P1·本周", "晨间简报 ✅已由AI本地版实现（daily_briefing.py 每天07:00自动生成推送，无需手动搭飞书自动化；飞书自动化流程为可选项）", "P1第4周", "本地计划任务", "已完成"],
            ["P2·第2月", "知识入库表+决策日志表 —— ✅ 已由助手在飞书建好（含示例数据）", "P2第5周", "飞书表格", "已完成"],
            ["P2·第2月", "核对新表结构+确认知识库剩余2篇空文档（今日工作/工作计划）", "P2第5周", "Obsidian/飞书", "15分钟"],
            ["P2·第2月", "Skill孵化+知识体检工作流", "P2第6周", "Coze", "4小时"],
            ["P2·第2月", "聊天整理+日报/周报/月报", "P2第7周", "Coze", "4小时"],
            ["P3·第3月", "决策深化+认知分析工作流", "P3第3月", "Coze/表格", "2小时"],
            ["P3·第3月", "三大可视化看板 ✅已由助手建好（学习进度/任务燃尽/系统健康）", "P3第3月", "飞书表格", "已完成"],
            ["P3·第3月", "Prompt动态调优+成本审计", "P3第3月", "Coze", "2小时"],
        ])

    # ===== P0 详细 =====
    add_heading(doc, "三、P0 级待办（立即执行，完成核心闭环）", 1)

    add_heading(doc, "（一）Coze「知识检索」工作流（Day 11）", 2)
    add_body(doc, "配置包已生成：打开 D:\\AI\\AI大系统\\04-操作手册\\Coze知识检索工作流-复制即用配置.md，按其中各节点配置逐项粘贴到 Coze 即可，无需翻手册。")
    add_table(doc, ["步骤", "操作要点", "完成标准"],
        [
            ["1", "Coze→个人AI助理Bot→新建「知识检索」工作流，开始节点加 question 参数", "工作流已创建"],
            ["2", "大模型节点「意图判断」粘贴配置包中的 Prompt（判断查任务/查学习/查笔记/其他）", "分支就绪"],
            ["3", "分支1/2：飞书多维表格插件查询 任务表 / 学习打卡表·间隔重复表", "试运行能返回记录"],
            ["4", "分支3「查笔记」：P0 先返回提示语，P1 再接 AnythingLLM", "返回提示语"],
            ["5", "各分支接大模型整理回复→结束节点；人设末尾追加检索触发句，保存发布", "群里@机器人能查"],
        ])

    add_heading(doc, "（二）Day 12 系统告警与监控 —— ✅ 已由助手完成", 2)
    add_body(doc, "此项已完成：Webhook 已填入 ai_config.py 并通过实测（告警群已收到测试消息）；监控脚本已在后台运行（每5分钟巡检）；开机自启快捷方式（监控+桥接服务）已放入启动文件夹。你只需确认告警群收到过测试消息即可。")

    add_heading(doc, "（三）BIOS 定时开机 + 端到端测试（Day 13）", 2)
    add_body(doc, "1. 重启电脑，开机反复按 F1 进 BIOS → Config → Power → Wake on Alarm（或 Power On with AC Attach）→ Enabled → 时间 06:50 → F10 保存退出。")
    add_body(doc, "2. 先运行自检脚本：双击 D:\\AI\\AI大系统\\01-脚本\\test_e2e.py，本地 5 项会自动检测（助手实测已 5/5 通过）。再在飞书手动测试 3 项：①@机器人「你好」有回复；②@机器人「明天下午3点提醒我复习机电系统」→任务表出现记录；③@机器人「我今天有什么任务」→返回任务列表。全部通过＝P0 核心闭环打通。")

    add_heading(doc, "（四）P0 复盘与成本基线（Day 14）", 2)
    add_body(doc, "✅ 成本基线已由 AI 实测完成（2026-08-31）：DeepSeek 余额 8.71 元（账户可用）；硅基流动 Key 有效（95个模型），其余额接口已官方废弃需登录控制台查看。API Key 已安全存入 ai_config.py。P3 成本审计数据源 `/cost_check` 已上线。")
    add_body(doc, "你只需：① 登录 cloud.siliconflow.cn 控制台补充硅基流动余额；② 检查 4 张表真实数据（学习打卡表手动填 1-2 条真实记录）；③ 按《P0复盘清单与成本记录模板.md》逐项确认并填写。", bold=True)

    # ===== P1 =====
    add_heading(doc, "四、P1 级待办（第 3-4 周 · 学习法落地）", 1)
    add_table(doc, ["事项", "操作要点", "完成标准"],
        [
            ["滴答清单复习提醒", "第3周周一建4条历史复习提醒（见手册）；每日新内容绑定第1/3/7/14/21天复习", "提醒全部创建"],
            ["Notion费曼输出库", "两栏引用+大白话复述+卡壳点待办+一句话定义+录音口述验证", "24小时内完成费曼"],
            ["用户画像表 ✅已建", "10字段（含核心行为路径/高频痛点/需求迫切度/转化触发点4扩展字段）+高需求分层视图+5条示例数据（助手已完成）", "字段齐全"],
            ["晨间简报 ✅已实现", "AI 本地版 daily_briefing.py 每天07:00自动拉取任务/学习/复习数据→DeepSeek生成个性化简报→webhook推送（实测成功）；飞书「自动化流程」Webhook 方案变为可选项，想用仍可粘贴（URL见《晨间简报-一键配置.md》）", "每天07:00准时收到"],
            ["每日督办 ✅已实现", "AI 本地版 daily_reminder.py 每天09:00自动检查任务截止（今日/明日/逾期）+学习连续≥3天未打卡告警→webhook推送（实测发现连续7天未打卡已推送）", "每天09:00收到督办"],
            ["费曼学习辅助 ✅已实现", "运行 feynman_assist.py \"知识点\" \"科目\" 即可生成费曼四步→写Obsidian+学习打卡表（实测已生成4篇）；Notion 版仍可按模板建库（可选）", "学完即用1条命令"],
            ["复习提醒 ✅已实现", "AI 本地版 review_reminder.py 每天20:00自动读间隔重复表今日到期卡片→推送复习清单+未打卡提醒（实测成功）；滴答清单手机端为可选增强", "每天20:00收到复习清单"],
            ["每周全量备份 ✅已实现", "AI 本地版 backup_all.py 每周日22:30自动备份：7张表CSV+Coze工作流JSON+Vault压缩+脚本（实测首份已生成于05-备份/backup/20260831/）", "每周日自动备份"],
        ])
    add_body(doc, "【需要你提供】① 滴答清单/Notion 需手机或网页操作（我无法替你登录）；② 晨间简报已由 AI 本地版实现（每天07:00自动推送），不再需要你手动搭飞书自动化；③ 用户画像表已由 AI 建好，你只需每周更新数据；④ 费曼学习可用我备好的 feynman_assist.py 一条命令生成（也可继续用 Notion 模板手动做）。", bold=True)

    # ===== P2 =====
    add_heading(doc, "五、P2 级待办（第 2 个月 · 自动化孵化与知识体检）", 1)
    add_body(doc, "前置校验：P0/P1 完成、核心表数据≥30条、每日有运行日志。以下工作流的节点配置与 Prompt 全文见《P2 操作手册》及执行清单。其中两张扩展表已由助手创建完成（见下表 ✅ 标记）。")
    add_table(doc, ["事项", "操作要点", "完成标准"],
        [
            ["知识入库表 ✅已建", "12字段（自动编号ZR-001+来源+类型+标签+摘要+重要度+状态等）+双向关联任务表+5条示例数据（助手已完成）", "字段完整、编号生效"],
            ["决策日志表 ✅已建", "14字段（自动编号JC-001+选择理由必填+决策领域+风险等级等）+双向关联知识入库表+5条示例数据（助手已完成）", "字段完整、编号生效"],
            ["知识库体检问题处理", "按《知识库体检报告》删除3个空文件、归档6篇测试残留、保留2篇预案草稿", "10分钟清理完成"],
            ["Skill孵化工作流", "周日23:00→查运行日志→识别≥3次模式→飞书确认→HTTP调7860/write_skill→建草稿", "每周生成建议"],
            ["知识库体检工作流", "周一02:00→HTTP调7860/scan_vault→缺口分析→循环写任务表→推送报告", "每周生成待办"],
            ["每日聊天整理", "22:00→拉飞书+微信→抽取待办/洞察/学习→写表→推送洞察卡片", "每日22:00收到卡片"],
            ["日报/周报/月报", "日报22:15/周报周五17:10/月报1号09:30→查数据→生成→推送+调/write_note归档", "按时收到+归档"],
        ])
    add_body(doc, "【需要你提供】① Coze 工作流需你登录账号后按 `P2配置包` 逐节点粘贴（配置包已备好，接口已全部验证可用）；② 搭建时卡住可截图发我，我帮你逐节点核对；③ 需在飞书群建「个人总控群」并让机器人加入（聊天整理工作流拉数据用）。", bold=True)

    # ===== P3 =====
    add_heading(doc, "六、P3 级待办（第 3 个月+ · 越用越聪明）", 1)
    add_body(doc, "前置校验：P2 稳定运行≥30天、6张表完整、核心工作流成功率≥95%。")
    add_table(doc, ["事项", "操作要点", "完成标准"],
        [
            ["决策日志深化 ✅已建", "决策领域/风险等级/可复用性3字段（助手已完成，含示例数据）", "字段齐全"],
            ["每月认知分析", "每月1号10:00→查决策日志→生成跨领域规律/盲区/迁移/建议→写Obsidian+推送", "1号准时收到"],
            ["三大看板 ✅已建", "学习进度看板(4组件)/任务燃尽看板(5组件)/系统运行健康看板(4组件)（助手已完成）", "数据实时"],
            ["Prompt动态调优", "每月2号14:00→统计→生成优化方案→确认→更新Bot Prompt→备份（✅凭证已齐：Coze令牌已验证+Bot ID已获取+调优脚本update_bot_prompt.py已生成+Prompt基线已备份）", "每月优化1次"],
            ["成本审计清理", "每月最后一天23:00→调/cost_check接口(已上线实测)→超20元告警→确认后禁用无效流程（✅数据源已备，无需再找账单接口）", "月成本≤20元"],
            ["MCP可选", "基础流程稳定满2周后再做：Node.js→MCP服务→AnythingLLM API→Coze接入", "连接稳定"],
        ])
    add_body(doc, "【需要你提供】① Coze 工作流需你登录账号后按《Coze工作流搭建总手册》+对应配置包逐节点搭建（接口已全部验证可用，卡住可截图发我）；② 已全部提供的凭证：DeepSeek/硅基/Coze API令牌/飞书App凭证 均已提供并验证 ✅；③ 成本审计无需再找账单接口（/cost_check 已上线）；④ MCP 如说「装吧」，我可直接帮你验证。", bold=True)

    # ===== 持续 =====
    add_heading(doc, "七、持续维护事项（长期）", 1)
    add_table(doc, ["频率", "操作要点", "说明"],
        [
            ["每日3分钟", "打开系统运行健康看板→看异常数→浏览当日日报", "巡检"],
            ["每周10分钟", "检查工作流日志→清理测试数据→核对API费用", "运维"],
            ["每月30分钟", "全量备份（表格+工作流JSON+Vault）→成本审计→清理90天前日志", "大检"],
            ["每3个月", "更换全部 API Key；每周飞书表格导出备份；Obsidian 每周手动备份", "安全"],
        ])

    # ===== 凭证核实 =====
    add_heading(doc, "八、账号与凭证核实清单", 1)
    add_table(doc, ["凭证", "去哪找", "状态"],
        [
            ["飞书 App ID / Secret", "开放平台→应用详情→凭证与基础信息", "需核实并保存"],
            ["Coze API Key（P3用）", "Coze→个人设置→API令牌（生成后存环境变量）", "P3时办理"],
            ["DeepSeek 余额", "platform.deepseek.com→账户", "确认≥10元"],
            ["硅基流动 余额", "siliconflow.cn→控制台", "确认免费档可用"],
            ["飞书告警Webhook", "见三（二）", "P0 Day12办理"],
        ])

    # ===== 页脚页码 =====
    footer = sec.footer
    fp = footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = fp.add_run("第 ")
    set_run_font(run, size=9)
    # 添加页码域
    fldChar1 = OxmlElement('w:fldChar'); fldChar1.set(qn('w:fldCharType'), 'begin')
    instrText = OxmlElement('w:instrText'); instrText.set(qn('xml:space'), 'preserve'); instrText.text = 'PAGE'
    fldChar2 = OxmlElement('w:fldChar'); fldChar2.set(qn('w:fldCharType'), 'end')
    run._r.append(fldChar1); run._r.append(instrText); run._r.append(fldChar2)
    run2 = fp.add_run(" 页")
    set_run_font(run2, size=9)

    doc.save(OUT)
    print("SAVED:", OUT)


if __name__ == "__main__":
    main()
