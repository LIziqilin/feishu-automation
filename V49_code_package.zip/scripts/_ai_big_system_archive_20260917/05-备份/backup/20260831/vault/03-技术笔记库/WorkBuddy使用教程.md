# WorkBuddy 使用教程与配置检查报告

> 📅 生成时间：2026-08-17
> 💻 适用环境：Windows 10 + Obsidian v1.13.4 + WorkBuddy v5.3.13
> 👤 面向用户：初学者（每步都有详细说明，照着做就行）

---

## 一、配置检查结果总览（✅ 全部就绪）

在动手使用前，我先帮你的 WorkBuddy 做了完整体检。**结论：所有功能已配置完成，可以直接使用！**

| 检查项目 | 状态 | 说明 |
|---------|------|------|
| WorkBuddy 桌面程序 | ✅ 运行中 | 11 个进程正常运行 |
| WorkBuddy 版本 | ✅ 5.3.13 | 安装文件 `WorkBuddy-win32-x64-user-5.3.13` |
| Obsidian | ✅ 运行中 | v1.13.4，4 个进程 |
| Obsidian 第三方插件 | ✅ 正常 | 共 20 个插件已启用 |
| **Workbuddian 插件** | ✅ **v2.3.1** | AI 聊天核心插件，已启用 |
| **Local REST API 插件** | ✅ **v5.1.0** | 端口 27124（HTTPS），认证正常 |
| **API 读写闭环测试** | ✅ **通过** | 写入 / 读取 / 删除 全部成功 |
| CodeBuddy CLI 后端 | ✅ 就绪 | AI 对话功能依赖 |
| **Obsidian 技能包（3个）** | ✅ **已安装** | markdown / canvas / bases |
| Hermes MCP 集成 | ✅ 已配置 | obsidian-rocket（13 工具）+ kb-tools |

> 🎉 **一句话总结：你的 WorkBuddy 已经完全配好，包括 AI 聊天、技能包、Obsidian 笔记联动全部在线，随时可以开用！**

---

## 二、WorkBuddy 是什么？（3 秒钟理解）

**WorkBuddy 是你的"AI 助理 + Obsidian 笔记管家"。** 它把三样东西合在一起：

1. 🧑‍💻 **AI 对话** — 在 Obsidian 笔记里直接和 AI 聊天（基于 WorkBuddian 插件）
2. 📝 **笔记操作** — 让 AI 帮你读取、新建、修改 Obsidian 里的笔记
3. 🧩 **技能包** — 让 AI 拥有"特殊能力"（读写笔记、做思维导图画布、管理知识库）

打个比方：**WorkBuddy 像给你雇了一个懂工程又懂笔记的助理，你只要说人话，他就在你的笔记库里干活。**

---

## 三、核心组件的功能和位置

### 1. WorkBuddy 桌面程序
- 📍 位置：`D:\AI-Tools\WorkBuddy\`
- 🚀 启动：双击桌面 `WorkBuddy.lnk` 快捷方式
- 🔄 运行方式：多进程架构（正常是 5-11 个进程）
- ⚙️ 作用：AI 对话的后台引擎，负责调用 CodeBuddy CLI 处理 AI 请求

### 2. CodeBuddy CLI（AI 后端）
- 📍 位置：`D:\AI-Tools\WorkBuddy\resources\app.asar.unpacked\cli\bin\codebuddy`
- ⚙️ 作用：真正的 AI 大脑，Workbuddian 插件靠它实现聊天、@引用、图片识别、MCP 等

### 3. Workbuddian 插件（AI 聊天界面）
- 📍 位置：Obsidian 库 `D:\AI\finished Brain\.obsidian\plugins\workbuddian\`
- ⚙️ 作用：装进了 Obsidian 的 AI 聊天插件，让你在笔记里直接和 AI 对话
- ✨ 功能亮点：
  - 💬 流式回复
  - @ 引用笔记
  - 🖼️ 图片视觉识别
  - 🔧 MCP 管理
  - ↩️ 行级 diff 一键撤销（改错了能撤回）

### 4. Obsidian 技能包（AI 的特殊能力）
- 📍 位置：`D:\AI-Tools\WorkBuddy\skills\obsidian\`
- 📦 共 3 个技能包：

| 技能包 | 文件 | 作用（AI 能做的事） |
|-------|------|-------------------|
| **obsidian-markdown** | 944 B | 读写/新建/修改 markdown 笔记、支持连接和标签 |
| **json-canvas** | 1.9 KB | 创建/编辑 Obsidian 思维导图画布、添加节点和连线 |
| **obsidian-bases** | 2.8 KB | 管理文件夹、标签、模板、批量操作、知识库统计 |

### 5. Local REST API（数据通道）
- ⚙️ 插件版本：v5.1.0
- 🌐 端口：27124（HTTPS，安全连接）
- 🔑 认证：Bearer Token（自动生成）
- 📍 配置：`D:\AI\finished Brain\.obsidian\plugins\obsidian-local-rest-api\data.json`
- ⚙️ 作用：AI 和笔记库之间的"高速公路"，读写笔记全靠它

---

## 四、动手使用教程（按场景）

### 场景 A：在 Obsidian 里和 AI 聊天（最常用）

这是最常用的功能，**你只需要等结果**，全程不用敲代码。

1. 打开 Obsidian（双击桌面 `Obsidian.lnk`）
2. 打开你的笔记库（finished Brain）
3. 页面右侧会有一个 **AI 聊天面板**（Workbuddian 的界面）
4. 在聊天框里用**中文**输入你的需求，例如：
   - "帮我新建一个今日工作笔记"
   - "总结一下 [[项目会议记录]] 的要点"
   - "把这段话改得更正式"

> 💡 **第一次使用提示**：如果聊天面板没出现，去 `设置 → 第三方插件` 确认 **Workbuddian** 已开启（显示 v2.3.1），然后重启 Obsidian。

### 场景 B：让 AI 读笔记（检索）

在 WorkBuddy 或 Obsidian 聊天里输入：

```
读取笔记：[[学习记录/2026年8月15日工作计划]]
```

AI 会读取并把内容整理给你。

### 场景 C：让 AI 建笔记

```
创建新笔记：
- 路径：学习记录/2026-08-17 学习总结.md
- 标题：今日学习总结
- 内容：（描述你想写什么）
```

AI 会自动在正确的位置建好笔记，包含格式和内容。

### 场景 D：让 AI 画画布（思维导图）

```
创建思维导图：项目规划
- 中心主题：项目管理
- 子主题：需求分析、开发、测试、部署
```

AI 会生成一个 `.canvas` 思维导图，你可以在 Obsidian 里打开编辑。

### 场景 E：让 AI 管理知识库

```
为所有学习笔记添加标签 #工程管理
```

---

## 五、如何调用技能包（进阶）

你要用好"技能包"，记住这三句口令，在 WorkBuddy / Obsidian 聊天里说：

| 你想做什么 | 就说 | 对应技能包 |
|-----------|------|-----------|
| 处理笔记 | `加载技能包：obsidian-markdown` | markdown |
| 做思维导图 | `加载技能包：json-canvas` | canvas |
| 管理知识库 | `加载技能包：obsidian-bases` | bases |

加载后就能用对应能力了。**一般场景用不上手动加载**，但如果你想发挥 AI 全部实力，先加载技能包再下指令，效果最好。

---

## 六、常用快捷方式与启动顺序

**推荐启动顺序（按这个来最稳）：**

1. 启动 **Obsidian**（AI 笔记功能依赖它）
2. 启动 **WorkBuddy**（AI 对话引擎）
3. 打开笔记库，开始聊天

**桌面快捷方式清单：**

| 程序 | 快捷方式 | 作用 |
|-----|---------|------|
| Obsidian | `Obsidian.lnk` | 笔记软件 |
| WorkBuddy | `WorkBuddy.lnk` | AI 引擎 |

---

## 七、常见问题排查（遇到问题再看）

| 问题 | 可能原因 | 解决办法 |
|------|---------|---------|
| 聊天没反应 | WorkBuddy 没启动 | 双击桌面 `WorkBuddy.lnk` 启动 |
| AI 不回复 | CodeBuddy CLI 找不到 | 确认 WorkBuddy 完整安装（CLI 在 `resources/app.asar.unpacked/`） |
| 笔记读不到 | Obsidian 没启动 | Local REST API 依赖 Obsidian 运行，先启动 Obsidian |
| 插件没加载 | 新装的插件 | 重启 Obsidian（关闭所有 Obsidian.exe 再打开） |
| 改了配置没反应 | Obsidian 运行中覆盖 | 先关掉 Obsidian 再改配置 |
| 网络报证书错误 | 自带安全证书 | WorkBuddy 会自动处理，无需手动设置 |

---

## 八、给初学者的 3 条建议（划重点）

1. ✅ **放心用**：配置已全部完成，你只需要张嘴说想做什么，AI 自动干完，你就等着看结果。
2. 📝 **先说清要什么**：给 AI 下指令时，把"放哪里 / 叫什么 / 写什么内容"说清楚，效果最好。
3. 🔄 **善用 @引用**：在聊天里输入 `@` 再选笔记，AI 就能直接针对那篇笔记操作。

---

## 九、参考文件位置速查表

| 内容                | 完整路径                                                                       |
| ----------------- | -------------------------------------------------------------------------- |
| WorkBuddy 主程序     | `D:\AI-Tools\WorkBuddy\WorkBuddy.exe`                                      |
| WorkBuddy 技能包     | `D:\AI-Tools\WorkBuddy\skills\obsidian\`                                   |
| CodeBuddy CLI     | `D:\AI-Tools\WorkBuddy\resources\app.asar.unpacked\cli\bin\codebuddy`      |
| Obsidian 知识库      | `D:\AI\finished Brain\`                                                    |
| Workbuddian 插件    | `D:\AI\finished Brain\.obsidian\plugins\workbuddian\`                      |
| Local REST API 配置 | `D:\AI\finished Brain\.obsidian\plugins\obsidian-local-rest-api\data.json` |
| Hermes MCP 集成     | `~/.hermes/config.yaml`                                                    |

---

*本教程由 Hermes Agent 于 2026-08-17 配置检查后生成，所有状态均为实测确认。*
