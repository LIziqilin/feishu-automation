# 你的 AI 全家桶 —— 全景定位图（小白版）

> 生成：2026-08-19 ｜ 用途：一次看懂电脑上每个软件/插件/工具是干嘛的、怎么配合
> 主线一句话：**微信/元宝是遥控器 ➜ Hermes是大脑 ➜ Obsidian+AnythingLLM是记忆仓库 ➜ Ollama是本地方脑**

---

## 🗺️ 全景总览（一眼看懂分工）

```
     【遥控器·入口】                【大脑·执行】              【记忆·知识】
   腾讯元宝App  ──────┐
   个人微信    ──────┼──➜  Hermes Agent  ──➜  ① Obsidian（知识仓库）
   电脑桌面Hermes───┘    （7个Agent分工协作）  ─➜  ② AnythingLLM（学习/检索）
                              │  │  │
                              ▼  ▼  ▼
                          Ollama（本地AI脑）
                        qwen2.5系列模型兜底
```

---

## 一、三大"软件层"的角色（最关键）

| 层次 | 软件 | 它到底是干嘛的 | 一句话定位 |
|:--|:--|:--|:--|
| **入口（遥控器）** | 腾讯元宝App | 你在手机/电脑上发指令的地方 | "对讲机" |
| | 个人微信 | 你习惯的聊天入口（借Bot桥接） | "备用对讲机" |
| | Hermes桌面/终端 | 直接跟Hermes对话 | "本地对讲机" |
| **大脑（执行）** | **Hermes Agent** | 真正理解指令、查资料、写笔记、定时推送的总指挥 | "大脑" |
| | **WorkBuddy** | Hermes的得力助手，负责本地文档处理（Word/PDF/表格） | "左手" |
| | **元宝App自带AI** | 只能聊天问答，不能动你电脑 | "只会聊天的小伙伴" |
| **记忆（仓库）** | **Obsidian** | 你的知识库/笔记，全部产出落在这里 | "永远的记忆" |
| | **AnythingLLM** | 本地学习检索（RAG），问答时先到这里找资料 | "图书馆管理员" |
| **本地算力** | **Ollama** | 跑本地AI模型（qwen2.5系列），断网也能用 | "本地大脑" |

---

## 二、Hermes 7个Agent（你的"AI员工团队"）

你已经有 7 个分身，各管一摊（调度都在 `全局任务看板.md` 里记录）：

| 分身 | 名字 | 擅长什么 |
|:--|:--|:--|
| agent1 | 商业老师 | 商业模式、案例分析、教你做生意 |
| agent2 | 思维老师 | 逻辑思维、金字塔原理、怎么思考 |
| agent3 | 技术专家 | 写代码、装软件、修电脑、搞AI工具 |
| agent4 | 职场高手 | PPT、Excel、Word 文档 |
| agent5 | 知识库管家 | 整理笔记、归档资料 |
| **agent6** | **调度总监** | **分配任务、协调所有Agent**（就是现在跟你说话的这个） |
| agent7 | 多媒体拆解师 | 把视频/音频变成文字笔记 |

> 🔑 你的"六大能力"方案，就是给这个团队加一套统一技能，让大家知道怎么配合做：素材捕捉/学习跟踪/盲点管理/任务运营/双引擎/懂我。

---

## 三、Obsidian 里都有什么（你的知识仓库结构）

你已有一个**非常成熟**的体系：

```
finished Brain（主力库）
├── 00-索引_知识库导航.md   ← 总导航门牌
├── 01-工程总监养成/        ← 60天养成计划的全部学习
├── 02-记忆架构/            ← 让AI懂你的记忆
├── 03-技术笔记库/          ← 工程技术知识
├── 04-思维方法库/          ← 思维模型/方法 <──★ 我的AI能力中心建在这
│   └── AI能力中心/         ← 新：盲点/素材/项目跟踪
├── 05-学习记录/            ← 每日学习日志
├── 06-职场资料库/          ← 工作文档模板
├── 待办事项/               ← 任务待办
├── 多媒体拆解/             ← 视频→文字笔记（待用）
├── AI对话记录/             ← 你和AI的问答留痕
└── Daily Notes/            ← 每日日记
```

---

## 四、Obsidian 已装的插件（每个是干嘛的）

| 插件 | 作用 |
|:--|:--|
| **copilot** | AI 对话/写作助手（已验证可用） |
| **dataview** | 用代码自动统计/汇总笔记（导航里的进度表靠它） |
| **obsidian-local-rest-api** | 🔑 **让AI程序能读写你的笔记**（端口27124，Hermes入口） |
| **workbuddian** | 笔记里直接和WorkBuddy的AI聊天 |
| **templater-obsidian** | 一键插入笔记模板 |
| **obsidian-day-planner** | 日程/任务规划 |
| **obsidian-excalidraw-plugin** | 手绘/白板/思维导图 |
| **folder-notes** | 给文件夹配说明页 |
| **tag-wrangler** | 批量管理标签 |
| **recent-files** | 最近文件快速切换 |
| **ollama-assistant** | 本地Ollama模型对话 |
| **nutstore-sync** | 坚果云多端同步 |
| **local-backup** | 本地自动备份 |
| **marker-api / docxer** | 文档解析/生成 |
| **karpathywiki** | Karpathy学习笔记wiki |

---

## 五、电脑上其他重要工具（D:/AI-Tools 等）

| 工具 | 定位 |
|:--|:--|
| **AnythingLLM** | 本地学习/检索主力（端口3001，需开机自启） |
| **Ollama + qwen2.5模型** | 本地AI算力（qwen2.5-4b-stable主力/3b/7b，纯CPU跑，注意过热） |
| **WorkBuddy** | 文档处理（含3个Obsidian技能包：markdown/canvas/bases） |
| **MarkItDown / pdf2md** | PDF转Markdown（文档进知识库的搬运工） |
| **cpolar** | 内网穿透（可能用于远程访问AnythingLLM/Hermes） |
| **SyncTrayzor** | SyncThing的图形界面（多机同步知识库） |
| **Hermes MCP** | obsidian-rocket(13工具) + kb-tools(4工具) —— 让Hermes操作Obsidian/知识库 |
| **本机模型目录** | qwen2.5-4b / qwen3-4b 等 GGUF 模型 |

---

## 六、你的六大能力方案，怎么用这套全家桶

| 能力 | 用到的软件组合 |
|:--|:--|
| 素材捕捉（抖音/链接提炼） | 入口(元宝/微信) ➜ Hermes抓取 ➜ 提炼 ➜ 存Obsidian |
| 学习跟踪 | Hermes读Obsidian记录 ➜ 出报告 ➜ 更新索引 |
| 盲点管理 | Hermes扫描Obsidian+AnythingLLM ➜ 找缺口 ➜ 补充+闪卡督促 |
| 任务运营 | Hermes建待办/拆项目 ➜ Obsidian看板 ➜ cron定时推送 |
| 双引擎+知识优先 | Hermes先查AnythingLLM+Obsidian ➜ 命中用库内答 |
| 懂我 | Hermes记忆 → 02-记忆架构 |

---

## 七、我的建议（最优组合）

- **主大脑**：Hermes agent6（调度总监）
- **入口**：优先腾讯元宝App（官方稳定），个人微信备份
- **知识仓库**：Obsidian finished Brain（加上 AI能力中心）
- **学习检索**：AnythingLLM（启动开机自启）
- **本地算力**：Ollama qwen2.5（兜底）
- **文档处理**：WorkBuddy

---

*这套系统你已经有 80%，我帮你补的是：①入口自动化（元宝/微信接Hermes）；②六大能力技能；③盲点扫描；④定时督促。*
