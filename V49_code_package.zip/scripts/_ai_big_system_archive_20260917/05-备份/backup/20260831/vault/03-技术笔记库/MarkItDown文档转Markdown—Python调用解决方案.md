---
title: MarkItDown文档转Markdown—Python调用解决方案
tags: [#MarkItDown, #PDF, #文档转换, #Python, #numpy, #环境隔离]
---

# MarkItDown 文档转 Markdown — Python 调用解决方案

> 环境：Windows 10 · 多 Python 共存（3.10 / 3.11 / 3.14）
> 报错根因：多环境 PATH 串用导致的 numpy 冲突
> 一键启动器：`C:\Users\Administrator\scripts\markitdown.bat`

## 📌 一句话结论

MarkItDown (v0.1.7) 安装在**独立 Python 3.10**，但直接调用会崩——不是因为工具坏了，而是**外部 Python 运行时误加载了 Hermes venv 里的 cp311-numpy**。永久解法 = 用启动器隔离干净 PATH。

---

## 1️⃣ 为什么会崩（根因分析）

`直接调 markitdown` 报错：
```
ModuleNotFoundError: No module named 'numpy._core._multiarray_umath'
Importing the numpy C-extensions failed ... incompatible with ... cpython-314
```

真凶是**三个 Python 环境共存 + PATH 串用**：

| Python | 用途 | 备注 |
|:--|:--|:--|
| 3.11 | Hermes venv | `C:\Users\Administrator\AppData\Local\hermes\hermes-agent\venv` |
| 3.10 | **MarkItDown 安装处** | `C:\Users\Administrator\AppData\Local\Programs\Python\Python310` |
| 3.14 | 系统默认 `python3` | |

**崩溃链路**：MarkItDown 装在 3.10，但运行时 Hermes venv 路径排在 PATH 前面 → 外部 3.10/3.14 解释器经由 `sys.path` 加载了 venv 里 `cp311-win_amd64.pyd` 的 numpy → 解释器与二进制版本不匹配 → 崩溃。

### ⚠️ 关键结论（别删 venv 的 numpy！）
- Hermes venv 的 numpy 2.4.3 **本身是好的**（编译文件 `cp311` + 3.11 解释器，匹配）。
- 验证：`venv\Scripts\python.exe -c "import numpy"` → `numpy OK: 2.4.3`
- **删除 venv 里的 numpy 会直接破坏 Hermes 本体**。真正的修复是隔离环境，不是删包。

---

## 2️⃣ 手动临时修复（当前 shell 有效）

```bash
# 让 Python 3.10 排在最前，并把 Hermes venv 剔出查找路径
export PATH="/c/Users/Administrator/AppData/Local/Programs/Python/Python310:/c/Users/Administrator/AppData/Local/Programs/Python/Python310/Scripts:$PATH"
unset PYTHONPATH PYTHONHOME
python -m markitdown test2.pdf -o test2.md
```

> 一次性补装 PDF 依赖：`python -m pip install "markitdown[pdf]"`
> （装了 pdfminer-six / pdfplumber / pypdfium2 / Pillow 等）

---

## 3️⃣ 永久修复 — 启动器 `markitdown.bat`

**位置**：`C:\Users\Administrator\scripts\markitdown.bat`

**用法**（Windows 下二选一）：
- 🖱️ **拖拽**：把 PDF 直接拖到 `.bat` 文件上
- 💻 **命令行**：`markitdown.bat "D:\路径\文件.pdf"`

输出自动生成到 **与 PDF 同目录、同文件名、.md 后缀**（`test2.pdf` → `test2.md`）。

### 脚本核心逻辑（英文 ASCII 注释，防乱码）

```batch
setlocal
set "PY310=C:\Users\Administrator\AppData\Local\Programs\Python\Python310"
set "PY310_SCRIPTS=%PY310%\Scripts"
set "PYTHONPATH="
set "PYTHONHOME="
set "CLEAN_PATH=%SystemRoot%\system32;%SystemRoot%;%SystemRoot%\System32\Wbem;%SystemRoot%\System32\WindowsPowerShell\v1.0;%PY310%;%PY310_SCRIPTS%"
set "PATH=%CLEAN_PATH%"
"python.exe" -m markitdown "%~1" -o "%~dpn1.md"
```

**做了什么**：① 强制 Python 3.10 绝对路径 → ② 清空 `PYTHONPATH/HOME` → ③ 重设干净 PATH（仅系统核心 + 3.10，剔除 Hermes venv）→ ④ 转换。**已端到端验证，输出与手动转换逐字节一致。**

---

## 4️⃣ 排坑笔记

- **git-bash 里调 cmd 必须用完整路径**：`$SYSTEMROOT/System32/cmd.exe /c`。裸 `cmd.exe` 会被 git-bash 解析失败，只进交互提示符不执行。
- **`.bat` 注释要用英文 ASCII**：中文注释在 cmd(GBK) 下乱码，导致批处理解析错乱、命令被拆断。
- **`cmd //c` 的 `//` 会被 git-bash 当路径**，正确写法是 `/c` + 完整 cmd 路径。

---

## 🔗 相关
- [[Ollama低内存部署优化清单]] — 同目录技术笔记
- [[Ollama内存优化要点]] — 同目录技术笔记
