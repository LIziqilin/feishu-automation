---
title: Ollama低内存部署优化清单
tags: [#Ollama, #优化, #低配, #i5-8250U, #8GB]
---

# Ollama低内存部署优化清单

> 适配 i5-8250U · 8GB RAM · MX150 2GB
> 完整版在桌面：`C:\Users\Administrator\Desktop\重要文件文件夹\Ollama低内存部署优化清单.md`

## ⚡ 懒人一键优化（复制粘贴到CMD）

```batch
:: === 核心环境变量 ===
setx OLLAMA_FLASH_ATTENTION 1
setx OLLAMA_KEEP_ALIVE 1m
setx OLLAMA_GPU_LAYERS 8
setx MALLOC_ARENA_MAX 2

:: === 拉取轻量量化模型 ===
ollama pull qwen2.5:1.5b-q4_K_M
ollama pull deepseek-r1:1.5b-q4_K_M

:: === 改Hermes默认模型 ===
hermes config set model.default qwen2.5:1.5b-q4_K_M
```

## 关键要点

| 原设置 | 优化后 | 省多少 |
|:--|:--|:--:|
| qwen2.5:3b (1.9GB) | qwen2.5:1.5b-q4_K_M (~600MB) | **省1.3GB** |
| Keep Alive 5分钟 | Keep Alive 1分钟 | **快4倍释放** |
| 纯CPU推理 | GPU卸载8层 | **速度↑30%** |
| 不压缩内存 | 开启Flash Attention | **显存省25%** |
| C盘87%满 | 清理到30-40% | **不卡顿** |

## 🚫 不要做的事

- ❌ 装7B以上模型（跑不动）
- ❌ 同时开多个模型
- ❌ 关掉页面文件
