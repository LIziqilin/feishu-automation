# WorkBuddy Obsidian 全套技能包配置说明

> **配置时间**: 2026-08-17  
> **配置人员**: AI 助手（电脑/AI/知识管理专家）

---

## ✅ 一、已安装技能包

### 核心技能包（3 个）

| 技能包 | 文件 | 大小 | 功能 |
|--------|------|------|------|
| **obsidian-markdown** | `obsidian-markdown.skill` | 944 B | Markdown 笔记读写管理 |
| **json-canvas** | `json-canvas.skill` | 1.9 KB | Canvas 画布创建编辑 |
| **obsidian-bases** | `obsidian-bases.skill` | 2.8 KB | 知识库基础结构管理 |

**位置**: `D:\AI-Tools\workbuddy\skills\obsidian\`

---

## 🔧 二、配置文件说明

### 1. settings.json - 系统设置

**位置**: `C:\Users\Administrator\AppData\Roaming\@genie\workbuddy-desktop\settings.json`

**关键配置**:
```json
{
  "workspace": {
    "path": "D:\\AI-Tools\\workbuddy\\workspace"  // 非系统盘工作空间
  },
  "obsidian": {
    "vaultPath": "D:\\AI\\finished Brain",  // Obsidian 知识库绑定
    "enabled": true,
    "autoSync": true
  },
  "model": {
    "default": "auto",  // 自动选择模型
    "autoSelect": true
  },
  "memory": {
    "profession": "地产甲方水电工程师",
    "workContent": "...",
    "commonSoftware": [...],
    "habits": [...]
  }
}
```

### 2. user-profile.json - 个人记忆

**位置**: `C:\Users\Administrator\AppData\Roaming\@genie\workbuddy-desktop\user-profile.json`

**包含内容**:
- 职业信息：地产甲方水电工程师
- 工作内容：商业综合体水电工程管理
- 常用软件：Obsidian, WorkBuddy, AutoCAD, Excel 等
- 做事习惯：结构化、标准化、数据驱动
- 学习目标：60 天工程总监养成计划

### 3. vaults.json - 知识库配置

**位置**: `C:\Users\Administrator\AppData\Roaming\@genie\workbuddy-desktop\vaults.json`

**配置内容**:
- 主知识库路径：`D:\AI\finished Brain`
- Local REST API 连接信息
- API Key 自动配置

---

## 🚀 三、使用场景配置

### 场景 1: 个人知识库自动化

#### 1.1 批量提炼知识卡片

**指令**:
```
请扫描 D:\AI\finished Brain\学习记录 目录下的所有笔记，
将每篇笔记的核心内容提炼为标准化的知识卡片格式：
- 标题
- 核心概念（100 字内）
- 关键要点（3-5 条）
- 应用场景
- 相关标签
```

**技能包**: `obsidian-markdown` + `obsidian-bases`

#### 1.2 生成遗忘曲线复习清单

**指令**:
```
扫描我的知识库，识别超过 7 天未复习的笔记，
生成一份遗忘曲线复习清单，按优先级排序：
- 高优先级：核心概念类笔记，超过 14 天未复习
- 中优先级：案例分析类笔记，超过 10 天未复习
- 低优先级：参考资料类笔记，超过 7 天未复习

输出为 Markdown 表格，包含：笔记名称、最后复习时间、建议复习日期、优先级
```

**技能包**: `obsidian-bases`

#### 1.3 合并总结多篇笔记

**指令**:
```
请读取以下 5 篇关于"消防系统设计"的笔记：
- 消防系统分类
- 喷淋系统设计要点
- 消火栓系统配置
- 火灾自动报警系统
- 消防验收标准

合并总结为一篇完整的知识框架文档，包含：
1. 概述（300 字）
2. 核心知识点（结构化列表）
3. 设计流程（步骤化）
4. 常见问题及解决方案
5. 参考规范清单
```

**技能包**: `obsidian-markdown` + `obsidian-bases`

#### 1.4 费曼学习法自测题

**指令**:
```
根据费曼学习法，为笔记"商业综合体机电系统概述"生成自测思考题：
- 基础概念题（5 道）：检验基本概念理解
- 应用分析题（3 道）：检验实际应用能力
- 综合思考题（2 道）：检验系统思维能力

每题附带参考答案要点，存入笔记的"自测题"章节
```

**技能包**: `obsidian-markdown`

#### 1.5 统一规范标签和目录

**指令**:
```
对我的知识库进行标准化整理：
1. 统一标签格式：
   - 领域标签：#工程/水电、#工程/消防、#工程/电气
   - 类型标签：#类型/概念、#类型/案例、#类型/规范
   - 状态标签：#状态/待复习、#状态/已掌握

2. 规范目录结构：
   - 01-核心概念
   - 02-设计规范
   - 03-案例分析
   - 04-经验总结
   - 05-模板工具

3. 批量更新笔记的 frontmatter，添加分类信息
```

**技能包**: `obsidian-bases`

---

### 场景 2: 工作项目效率提升

#### 2.1 自动生成项目清单

**指令**:
```
读取项目资料文件夹 "D:\AI\finished Brain\项目资料\西安金辉喜来登酒店"，
自动生成：
1. 项目清单（Excel 格式）：
   - 项目名称、负责人、开始日期、结束日期、当前状态
2. 风险清单：
   - 风险项、影响程度、发生概率、应对措施、责任人
3. 交付文档清单：
   - 文档名称、类型、提交日期、审核状态
```

**技能包**: `obsidian-markdown` + `obsidian-bases`

#### 2.2 项目经验总结

**指令**:
```
项目"西安金辉喜来登酒店水泵供应工程"已结束，
请汇总项目过程中的踩坑经验，整理成标准化经验模板：

模板结构：
1. 项目背景（200 字）
2. 遇到的问题（按时间线）
3. 解决方案及效果
4. 经验教训（3-5 条）
5. 可复用的方法论
6. 相关文档索引

存入：D:\AI\finished Brain\经验总结\水泵工程_标准化模板.md
```

**技能包**: `obsidian-markdown`

#### 2.3 批量处理合同和报表

**指令**:
```
批量处理以下文档：
1. 合同文档（PDF → Markdown）：
   - 提取关键条款：工程范围、付款方式、违约责任
   - 生成合同摘要

2. 成本报表（Excel → Markdown）：
   - CAPEX（资本性支出）：设备采购、安装工程
   - OPEX（运营性支出）：运维成本、能耗成本
   - 生成成本分析摘要

3. 技术文档标准化：
   - 统一格式：标题、版本号、日期、作者
   - 添加标签：#技术/水泵、#技术/暖通
   - 建立索引链接
```

**技能包**: `obsidian-markdown` + `json-canvas`

---

### 场景 3: 资料预处理（配合 MarkItDown）

#### 3.1 PDF 转 Markdown 工作流

**完整流程**:

**步骤 1**: 用 MarkItDown 转换 PDF
```python
from markitdown import MarkItDown
md = MarkItDown()
result = md.convert("合同.pdf")
# 保存为临时 Markdown 文件
```

**步骤 2**: 用 WorkBuddy 清洗和提炼
```
请对转换后的 Markdown 文件进行：
1. 文本清洗：
   - 删除乱码和无效字符
   - 修正格式错误
   - 统一标点符号

2. 内容分段：
   - 按章节划分
   - 添加小标题
   - 提取关键段落

3. 提炼重点：
   - 提取核心条款（加粗标注）
   - 生成摘要（200 字）
   - 提取关键词（5-10 个）

4. 结构化存储：
   - 添加 frontmatter（标题、日期、类型、标签）
   - 存入对应分类目录
   - 建立相关笔记链接
```

**技能包**: `obsidian-markdown` + `obsidian-bases`

---

## 🔗 四、系统架构定位

### WorkBuddy 在整套系统中的角色

```
┌─────────────────────────────────────────┐
│  【顶层调度大脑】Hermes Agent           │
│  - 云端模型（Qwen3.5-Plus 等）           │
│  - 负责任务分解和调度                   │
│  - 调用各种工具和技能包                 │
└──────────────┬──────────────────────────┘
               │ 下发执行任务
               ↓
┌─────────────────────────────────────────┐
│  【本地执行工具】WorkBuddy              │
│  - 本地 AI 助手                          │
│  - 执行具体任务                         │
│  - 调用 Obsidian 技能包                  │
│  - 文本清洗、分段、提炼                 │
└──────────────┬──────────────────────────┘
               │ ↔ 双向互通
               ↓
┌─────────────────────────────────────────┐
│  【存储底座】Obsidian                   │
│  - 知识库存储                           │
│  - Workbuddian 插件连通                 │
│  - Local REST API 提供接口              │
└─────────────────────────────────────────┘

独立系统：
┌─────────────────────────────────────────┐
│  【资料检索】AnythingLLM                │
│  - 独立 RAG 系统                         │
│  - 不与 WorkBuddy 互通                   │
│  - 使用 Ollama 本地模型                  │
└─────────────────────────────────────────┘
```

### 各系统职责划分

| 系统 | 职责 | 模型 | 互通性 |
|------|------|------|--------|
| **Hermes Agent** | 顶层调度、任务分解、复杂推理 | 云端（Qwen3.5-Plus） | 调用 WorkBuddy |
| **WorkBuddy** | 本地执行、文本处理、技能调用 | 自动选择（auto） | ↔ Obsidian |
| **Obsidian** | 知识存储、笔记管理、双向链接 | - | ← WorkBuddy |
| **AnythingLLM** | 独立检索、RAG 问答 | Ollama 本地模型 | 独立运行 |
| **MarkItDown** | PDF/文档转换 | - | 输出给 WorkBuddy |

---

## ✅ 五、配置验证

### 验证步骤

**步骤 1**: 检查配置文件
```bash
ls -la /c/Users/Administrator/AppData/Roaming/@genie/workbuddy-desktop/
# 应看到：settings.json, user-profile.json, vaults.json
```

**步骤 2**: 检查技能包
```bash
ls -la /d/AI-Tools/workbuddy/skills/obsidian/
# 应看到：3 个.skill 文件
```

**步骤 3**: 测试 Obsidian 连接
```bash
curl -sk -H "Authorization: Bearer 579c9276444b294ea705e20c327b8f9ff9d80db756fdfd63939e474d9b3cc489" "https://localhost:27124/vault/"
# 应返回知识库文件列表
```

**步骤 4**: 在 WorkBuddy 中测试
```
在 WorkBuddy 对话框输入：
"读取 Obsidian 库首页笔记内容"

预期结果：
- 成功读取笔记列表
- 显示笔记标题和摘要
```

---

## 📋 六、日常使用清单

### 每日必做

1. **早上启动**
   - [ ] 打开 WorkBuddy
   - [ ] 检查 Obsidian 是否运行
   - [ ] 确认 SyncTrayzor 同步正常

2. **工作中**
   - [ ] 用 WorkBuddy 处理文档
   - [ ] 用技能包管理笔记
   - [ ] 定期保存和整理

3. **晚上收尾**
   - [ ] 用 obsidian-bases 整理当天笔记
   - [ ] 生成复习清单
   - [ ] 确认同步完成

### 每周必做

1. **知识整理**（周五下午）
   - [ ] 用 obsidian-bases 整理标签
   - [ ] 清理重复笔记
   - [ ] 建立知识链接

2. **经验总结**（周末）
   - [ ] 汇总本周项目经验
   - [ ] 更新标准化模板
   - [ ] 生成周报

3. **复习计划**（周日晚上）
   - [ ] 生成遗忘曲线清单
   - [ ] 安排下周复习计划
   - [ ] 标记重点内容

---

## 🆘 七、故障排查

### 问题 1: WorkBuddy 无法连接 Obsidian

**检查**:
```bash
# 1. 确认 Obsidian 运行
tasklist | grep obsidian

# 2. 确认 Local REST API 启用
ls "D:/AI/finished Brain/.obsidian/plugins/" | grep rest

# 3. 测试 API 连接
curl -sk "https://localhost:27124/vault/"
```

**解决**:
1. 重启 Obsidian
2. 启用 Local REST API 插件
3. 检查 API Key 是否正确

### 问题 2: 技能包不生效

**检查**:
```bash
ls /d/AI-Tools/workbuddy/skills/obsidian/
cat /d/AI-Tools/workbuddy/skills/obsidian/obsidian-markdown.skill | head -20
```

**解决**:
1. 确认技能包文件存在
2. 重启 WorkBuddy
3. 在技能中心重新安装

### 问题 3: 配置文件不生效

**检查**:
```bash
cat /c/Users/Administrator/AppData/Roaming/@genie/workbuddy-desktop/settings.json
```

**解决**:
1. 检查 JSON 格式是否正确
2. 重启 WorkBuddy
3. 删除配置文件重新生成

---

## ✨ 总结

**配置完成度：100%** ✅

你现在拥有：
- ✅ WorkBuddy 基础配置完成
- ✅ 个人记忆已填写
- ✅ Obsidian 知识库已绑定
- ✅ 3 个核心技能包已安装
- ✅ 5 大使用场景已配置
- ✅ 系统架构已明确

**下一步**: 在 WorkBuddy 对话框输入"读取 Obsidian 库首页笔记内容"进行测试！

---

*配置文档 v1.0*  
*最后更新：2026-08-17 13:00*
