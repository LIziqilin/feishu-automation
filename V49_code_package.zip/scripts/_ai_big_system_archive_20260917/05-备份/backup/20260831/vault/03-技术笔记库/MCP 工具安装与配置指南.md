# 🔧 MCP 工具安装与配置指南

> **版本**: v1.0  
> **创建时间**: 2026-08-17 16:30  
> **适用对象**: 小白用户  
> **执行人员**: AI 助手（电脑/AI/知识库专家）

---

## 📋 一、安装状态汇总

### 用户要求的 5 个工具

| 序号 | 工具名称 | 用户提供的包名 | 实际状态 | 正确包名/替代方案 |
|------|----------|---------------|----------|------------------|
| 1 | **Generator** | `@mcp/generator-server` | ❌ 包不存在 | 需确认正确包名 |
| 2 | **Aqua4AI** | `aqua4ai-mcp` | ❌ 包不存在 | 需确认正确包名 |
| 3 | **Scraping** | `@modelcontextprotocol/server-scraping` | ❌ 包不存在 | 使用 `firecrawl-mcp` 替代 |
| 4 | **Markmofox** | `markmofox-mcp` | ❌ 包不存在 | 需确认正确包名 |
| 5 | **Tokscale** | `tokscale@latest` | ✅ **可用** | `npx tokscale@latest` |

---

## 🔍 二、问题分析

### 核心问题：包名不正确

**用户提供的包名**:
- `@mcp/generator-server` → npm 查无此包
- `aqua4ai-mcp` → npm 查无此包
- `@modelcontextprotocol/server-scraping` → npm 查无此包
- `markmofox-mcp` → npm 查无此包

**可能的原因**:
1. 包名拼写错误
2. 是自定义包/私有包
3. 还未发布到 npm
4. 是 GitHub 仓库而非 npm 包

---

## ✅ 三、可用的 MCP 工具（官方）

### 官方 Model Context Protocol 服务器

**已验证可用的包**:

| 包名 | 功能 | 安装命令 |
|------|------|----------|
| `@modelcontextprotocol/server` | MCP 基础服务器 | `npm install -g @modelcontextprotocol/server` |
| `@modelcontextprotocol/server-filesystem` | 文件系统访问 | `npm install -g @modelcontextprotocol/server-filesystem` |
| `@modelcontextprotocol/server-memory` | 知识图谱记忆 | `npm install -g @modelcontextprotocol/server-memory` |
| `@modelcontextprotocol/server-github` | GitHub API | `npm install -g @modelcontextprotocol/server-github` |
| `@modelcontextprotocol/server-puppeteer` | 浏览器自动化 | `npm install -g @modelcontextprotocol/server-puppeteer` |
| `@modelcontextprotocol/server-sequential-thinking` | 序列思考 | `npm install -g @modelcontextprotocol/server-sequential-thinking` |

---

### 第三方 MCP 工具

**Firecrawl** (网页抓取替代方案):

| 包名 | 功能 | 安装命令 |
|------|------|----------|
| `firecrawl-mcp` | 网页搜索、抓取、分析 | `npm install -g firecrawl-mcp` |
| `firecrawl` | Firecrawl JS SDK | `npm install -g firecrawl` |

**Tokscale** (Token 计数):

| 包名 | 功能 | 使用方式 |
|------|------|----------|
| `tokscale` | Token 计数和分析 | `npx tokscale@latest` |

---

## 🛠️ 四、推荐安装方案

### 方案 A：安装官方 MCP 工具（推荐⭐）

**步骤 1**: 安装官方 MCP 服务器
```bash
# 基础服务器
npm install -g @modelcontextprotocol/server

# 文件系统访问
npm install -g @modelcontextprotocol/server-filesystem

# 记忆功能（知识图谱）
npm install -g @modelcontextprotocol/server-memory

# GitHub 集成（如需要）
npm install -g @modelcontextprotocol/server-github

# 浏览器自动化（如需要）
npm install -g @modelcontextprotocol/server-puppeteer
```

**步骤 2**: 安装 Firecrawl（网页抓取）
```bash
npm install -g firecrawl-mcp
```

**步骤 3**: 验证安装
```bash
npx @modelcontextprotocol/server --version
npx @modelcontextprotocol/server-filesystem --version
npx firecrawl-mcp --version
npx tokscale --version
```

---

### 方案 B：使用用户指定的工具（需确认包名）

**需要用户提供**:

1. **Generator**:
   - 正确的 npm 包名或 GitHub 仓库地址
   - 或者是自定义包？

2. **Aqua4AI**:
   - 正确的 npm 包名或 GitHub 仓库地址
   - 多媒体解析的具体功能需求？

3. **Scraping**:
   - 确认是否使用 `firecrawl-mcp` 替代
   - 或者有特定的 GitHub 仓库？

4. **Markmofox**:
   - 正确的 npm 包名或 GitHub 仓库地址
   - 思维导图功能的具体需求？

---

## 📝 五、Hermes Agent config.yaml 配置示例

### 最简配置（使用可用工具）

```yaml
mcp_servers:
  # Tokscale - Token 计数
  tokscale:
    command: npx
    args: ["tokscale@latest", "--light"]
  
  # Firecrawl - 网页抓取（替代 Scraping）
  firecrawl:
    command: npx
    args: ["firecrawl-mcp"]
    env:
      FIRECRAWL_API_KEY: "${FIRECRAWL_API_KEY}"
  
  # 官方 MCP - 文件系统
  filesystem:
    command: npx
    args: ["-y", "@modelcontextprotocol/server-filesystem"]
  
  # 官方 MCP - 记忆
  memory:
    command: npx
    args: ["-y", "@modelcontextprotocol/server-memory"]
```

### 完整配置（包含所有官方工具）

```yaml
mcp_servers:
  # Token 计数
  tokscale:
    command: npx
    args: ["tokscale@latest", "--light"]
  
  # 网页抓取
  firecrawl:
    command: npx
    args: ["firecrawl-mcp"]
    env:
      FIRECRAWL_API_KEY: "${FIRECRAWL_API_KEY}"
  
  # 文件系统
  filesystem:
    command: npx
    args: ["-y", "@modelcontextprotocol/server-filesystem", "--allowed-dirs", "D:\\AI-Tools"]
  
  # 记忆（知识图谱）
  memory:
    command: npx
    args: ["-y", "@modelcontextprotocol/server-memory"]
  
  # GitHub 集成
  github:
    command: npx
    args: ["-y", "@modelcontextprotocol/server-github"]
    env:
      GITHUB_TOKEN: "${GITHUB_TOKEN}"
  
  # 浏览器自动化
  puppeteer:
    command: npx
    args: ["-y", "@modelcontextprotocol/server-puppeteer"]
```

---

## 🔑 六、API Key 配置

### 需要的 API Key

| 服务 | 环境变量 | 获取方式 | 是否必须 |
|------|----------|----------|----------|
| **Firecrawl** | `FIRECRAWL_API_KEY` | https://firecrawl.com | 可选（有免费额度） |
| **GitHub** | `GITHUB_TOKEN` | GitHub Settings → Developer settings | 可选 |
| **Tavily** | `TAVILY_API_KEY` | https://tavily.com | 可选（用户要求） |

### 配置方法

**Windows 环境变量**:

**方法 1**: 临时设置（当前会话有效）
```bash
set FIRECRAWL_API_KEY=你的 API_KEY
set GITHUB_TOKEN=你的 GitHub_TOKEN
set TAVILY_API_KEY=你的 Tavily_API_KEY
```

**方法 2**: 永久设置（系统环境变量）
1. 右键"此电脑" → 属性
2. 高级系统设置 → 环境变量
3. 用户变量 → 新建
4. 变量名：`FIRECRAWL_API_KEY`
5. 变量值：`你的 API_KEY`

**方法 3**: 写入 `.env` 文件
```bash
# 在 Hermes 目录创建 .env 文件
echo FIRECRAWL_API_KEY=你的 API_KEY >> C:\Users\Administrator\AppData\Local\hermes\.env
echo GITHUB_TOKEN=你的 GitHub_TOKEN >> C:\Users\Administrator\AppData\Local\hermes\.env
echo TAVILY_API_KEY=你的 Tavily_API_KEY >> C:\Users\Administrator\AppData\Local\hermes\.env
```

---

## 🧪 七、验证测试

### 测试 1：Tokscale

```bash
npx tokscale@latest --version
# 预期输出：tokscale 4.x.x
```

**测试 Prompt**:
```
请计算这段文字的 token 数量：
"Hello, world! This is a test."
```

---

### 测试 2：Firecrawl（网页抓取）

```bash
npx firecrawl-mcp --version
# 预期输出：firecrawl-mcp 3.x.x
```

**测试 Prompt**:
```
请抓取这个网页的内容并总结：
https://example.com
```

---

### 测试 3：文件系统

```bash
npx -y @modelcontextprotocol/server-filesystem --version
# 预期输出：版本号
```

**测试 Prompt**:
```
请列出 D:\AI-Tools 目录下的所有文件
```

---

### 测试 4：记忆（知识图谱）

```bash
npx -y @modelcontextprotocol/server-memory --version
```

**测试 Prompt**:
```
请记住：我喜欢喝绿茶
然后确认已记住
```

---

## 📊 八、安装脚本（一键安装）

### Windows 批处理脚本

创建文件：`D:\AI-Tools\install-mcp-tools.bat`

```batch
@echo off
echo 🔧 开始安装 MCP 工具...

echo.
echo 📦 安装 Tokscale...
call npx tokscale@latest --version

echo.
echo 📦 安装 Firecrawl MCP...
call npm install -g firecrawl-mcp

echo.
echo 📦 安装官方 MCP 服务器...
call npm install -g @modelcontextprotocol/server
call npm install -g @modelcontextprotocol/server-filesystem
call npm install -g @modelcontextprotocol/server-memory

echo.
echo ✅ 安装完成！验证：
call npx tokscale@latest --version
call npx firecrawl-mcp --version
call npx @modelcontextprotocol/server-filesystem --version

echo.
echo 📝 下一步：
echo 1. 配置 API Key（如需要）
echo 2. 修改 config.yaml 添加 MCP 服务器
echo 3. 重启 Hermes Agent
echo 4. 测试 MCP 功能

pause
```

**使用方法**:
```bash
# 双击运行或在命令行执行
D:\AI-Tools\install-mcp-tools.bat
```

---

## 🔧 九、Hermes Agent 配置步骤

### 步骤 1：备份当前配置

```bash
copy C:\Users\Administrator\AppData\Local\hermes\config.yaml C:\Users\Administrator\AppData\Local\hermes\config.yaml.bak
```

### 步骤 2：编辑 config.yaml

**打开文件**: `C:\Users\Administrator\AppData\Local\hermes\config.yaml`

**在文件末尾添加**:
```yaml
# MCP 服务器配置
mcp_servers:
  tokscale:
    command: npx
    args: ["tokscale@latest", "--light"]
  
  firecrawl:
    command: npx
    args: ["firecrawl-mcp"]
    env:
      FIRECRAWL_API_KEY: "${FIRECRAWL_API_KEY}"
  
  filesystem:
    command: npx
    args: ["-y", "@modelcontextprotocol/server-filesystem", "--allowed-dirs", "D:\\AI-Tools"]
  
  memory:
    command: npx
    args: ["-y", "@modelcontextprotocol/server-memory"]
```

### 步骤 3：保存并重启 Hermes

```bash
# 如果 Hermes 在运行，先关闭
# 然后重新启动 Hermes Agent
```

### 步骤 4：验证配置

**测试命令**:
```
/Hermes 请列出可用的 MCP 工具
```

**预期输出**:
- tokscale
- firecrawl
- filesystem
- memory

---

## 💡 十、常见问题

### Q1: 包安装失败怎么办？

**A**: 检查网络或使用镜像
```bash
# 使用淘宝镜像
npm config set registry https://registry.npmmirror.com
```

---

### Q2: npx 命令找不到？

**A**: 确认 Node.js 已安装
```bash
node --version
npm --version
npx --version
```

如未安装，下载 Node.js: https://nodejs.org/

---

### Q3: API Key 如何获取？

**A**: 
- **Firecrawl**: https://firecrawl.com → Sign Up → API Keys
- **Tavily**: https://tavily.com → Dashboard → API Keys
- **GitHub**: GitHub Settings → Developer settings → Personal access tokens

---

### Q4: 用户要求的包不存在怎么办？

**A**: 
1. 确认包名是否正确
2. 检查是否是 GitHub 仓库（需要 git clone）
3. 寻找功能类似的替代包
4. 联系包的作者确认

---

## ✨ 十一、总结

### 已完成

✅ **Tokscale**: 可用，`npx tokscale@latest`

✅ **Firecrawl**: 可用作 Scraping 替代，`npm install -g firecrawl-mcp`

✅ **官方 MCP 工具**: 6 个官方服务器可用

### 待确认

⏳ **Generator**: 需确认正确包名

⏳ **Aqua4AI**: 需确认正确包名

⏳ **Markmofox**: 需确认正确包名

### 下一步

1. **确认缺失包的来源**（用户提供）
2. **安装官方 MCP 工具**（AI 助手可完成）
3. **配置 config.yaml**（AI 助手可完成）
4. **设置 API Key**（用户提供）
5. **验证测试**（共同完成）

---

## 📞 十二、需要用户确认

### 问题 1：缺失的包

**Generator、Aqua4AI、Markmofox** 的正确包名或 GitHub 地址是什么？

- A. 提供正确的 npm 包名
- B. 提供 GitHub 仓库地址
- C. 使用功能类似的替代包
- D. 暂时不安装，后续再说

### 问题 2：Scraping 替代方案

是否使用 **firecrawl-mcp** 替代 Scraping？

- A. 是，使用 firecrawl-mcp
- B. 否，有特定的包
- C. 暂时不需要

### 问题 3：API Key

是否有以下 API Key？

- Firecrawl API Key: 有 / 无
- Tavily API Key: 有 / 无（用户要求中提到）
- DeepSeek API Key: 有 / 无（已配置）

### 问题 4：安装优先级

**请选择**:
- A. 先安装可用的工具（Tokscale + 官方 MCP）
- B. 等待确认所有包名后再安装
- C. 只安装用户指定的 5 个工具

---

*指南版本：v1.0*  
*创建时间：2026-08-17 16:30*  
*执行人员：你的 AI 助手（电脑/AI/知识库专家）*
