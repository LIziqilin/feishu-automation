# Coze → Hermes 中转检索 对接说明（任务5）

> 目标架构：**用户 @Coze 请求检索 → Coze 无法直连 AnythingLLM → Coze 发飞书消息给 Hermes 机器人 → Hermes 本地执行检索后回复**
>
> 🔗 相关笔记：[[AI桥接连接方案大全_20260821]]（飞书/微信桥接全景）· [[AnythingLLM操作指南_v2]]（向量检索配置）· [[Hermes一体化架构方案]]（Hermes 网关）

## ✅ 已完成（Hermes 侧）

### 1. Hermes 本地检索脚本
- 路径：`AppData\Local\hermes\profiles\agent1_business\scripts\coze_anythingllm_retrieve.py`
- 功能：从 webhook payload 提取查询问题 → 调用本地 AnythingLLM (127.0.0.1:3001) 知识库检索 → 输出 JSON 结果
- 已验证：可正确检索"工程总监学习"工作区并返回专业回答

### 2. Hermes Webhook 订阅（命令/技能）
- 订阅名：`coze-retrieve`
- **Webhook URL**：`http://localhost:8644/webhooks/coze-retrieve`
- **HMAC Secret**：`pLS8ymHKQJZ7bMfhMtgEv-3_vDNzq9dOeHC5rr-9ZZc`
- 签名验证方式：`X-Hub-Signature-256: sha256=<HMAC-SHA256(<secret>, <body>)>`
- 事件：所有 (all)

### 3. Webhook 平台状态
- 平台已启用，端口 8644，health 检查：`http://localhost:8644/health` → `{"status":"ok"}`
- 脚本超时：30s（默认）→ **180s**（已调高，覆盖 AnythingLLM 检索耗时）
- 已验证端到端：POST 检索请求 → 收到 **HTTP 202 Accepted**（脚本成功执行并进入 agent 处理）
- 状态码语义：`202 accepted` = 已接收并处理；`404` = 路由不存在；`401` = 签名错误

---

## 📋 Coze 侧需要配置的事项

### A. 在 Coze 应用里添加一个"自定义插件/工作流节点"，指向 Hermes webhook
1. 在 Coze → 你的应用 → 创建**代码/自定义 HTTP 请求节点**（或工作流 HTTP 请求步骤）
2. 配置：
   - **Method**: `POST`
   - **URL**: `http://localhost:8644/webhooks/coze-retrieve`
   - **Headers**:
     - `Content-Type: application/json`
     - `X-Hub-Signature-256: sha256=<hmac>` （用 Secret 对 body 做 HMAC-SHA256，十六进制小写）
   - **Body**: `{"query": "用户要检索的问题"}`
3. **连通性注意**：`localhost:8644` 只在本机可达。若 Coze 是云端应用，需要：
   - 把 Hermes 网关暴露到公网（用内网穿透，如 ngrok / cloudflared 隧道），或用局域网地址 + 防火墙放行 8644 端口。
   - 隧道会生成一个公网 URL，取代 `http://localhost:8644`。

### B. 让 Hermes 把结果"回复"给用户
当前订阅 `deliver: log`（结果仅记日志，不主动外发）。要让回答真正回到用户，二选一：

**方案①（推荐，简单）**：把回复送回飞书会话
```bash
hermes webhook subscribe coze-retrieve \
  --prompt "根据本检索结果给用户专业中文回复。JSON: {payload}" \
  --script coze_anythingllm_retrieve.py \
  --deliver feishu --deliver-chat-id "<你的飞书chat_id>" \
  --secret "pLS8ymHKQJZ7bMfhMtgEv-3_vDNzq9dOeHC5rr-9ZZc"
```
（需要你的飞书账号与 Hermes 机器人存在会话，chat_id 从 Hermes 飞书会话记录中取）

**方案②**：Coze 主动"拉取/轮询"结果 —— 让 Hermes 把结果写入一个本地 JSON 或 Obsidian 笔记，Coze 在处理结束后读取该文件返回给用户。

---

## 🔍 测试方法（已验证）
```bash
# 健康检查
curl http://localhost:8644/health
# 发送检索请求（模拟 Coze）
curl -X POST http://localhost:8644/webhooks/coze-retrieve \
  -H "Content-Type: application/json" \
  -H "X-Hub-Signature-256: sha256=<hmac>" \
  -d '{"query":"工程总监停电应急处置关键步骤"}'
# 期望返回：{"status":"accepted","route":"coze-retrieve","delivery_id":"..."}
```

---

## ⚠️ 已知要点
- AnythingLLM 检索较慢（DeepSeek-V3 生成，约 20~90 秒），脚本超时已调至 180 秒，但 Coze 侧 HTTP 超时需相应调大（建议 ≥120 秒）。
- webhook 全局 secret 也在 `.env`：`WEBHOOK_SECRET=`；订阅级 secret 在 `webhook_subscriptions.json`。
- 若网关重启，webhook 订阅自动热加载，无需重复注册。
