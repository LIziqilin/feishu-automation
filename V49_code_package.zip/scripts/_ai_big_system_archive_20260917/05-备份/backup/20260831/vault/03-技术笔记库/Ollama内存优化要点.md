---
title: 8G笔记本Ollama内存优化要点
tags: [#Ollama, #内存优化, #8GB, #低配]
date: 2026-07-29
---

# 8G笔记本Ollama内存优化要点

> 硬件：i5-8250U · 8GB RAM · MX150 2GB
> 目标：日常空闲内存从2.8GB提升到4GB+

---

## 一、模型选择（最重要）

| 模型 | 大小 | 推荐度 |
|:--|:--:|:--:|
| **qwen2.5:1.5b-q4_K_M** 🏆 | ~600MB | ⭐⭐⭐ 日常主力 |
| qwen2.5:1.5b (FP16) | 986MB | ⭐⭐ 备选 |
| deepseek-r1:1.5b-q4_K_M | ~700MB | ⭐⭐ 推理用 |
| qwen2.5:3b | 1.9GB | ⚠️ 8GB慎用 |

**原则：** 模型每大1倍，内存占用翻倍。1.5B量化版是最优解。

---

## 二、环境变量（设置一次永久生效）

```batch
:: 核心优化（CMD管理员运行）
setx OLLAMA_FLASH_ATTENTION 1     :: 省20-30%显存
setx OLLAMA_KEEP_ALIVE 1m         :: 对话结束后1分钟卸载模型
setx OLLAMA_GPU_LAYERS 8          :: MX150分担8层计算
setx OLLAMA_NUM_PARALLEL 1        :: 一次只处理一个请求
setx OLLAMA_MAX_LOADED_MODELS 1   :: 一次只加载一个模型
setx MALLOC_ARENA_MAX 2           :: 减少内存碎片
```

> ⚠ 设置后需要重启Ollama（或重启电脑）生效

---

## 三、日常使用习惯

| 习惯 | 省多少 |
|:--|:--:|
| 关掉不用的浏览器标签 | 省200-500MB/标签 |
| 退出微信/QQ | 省500MB+ |
| 用qwen2.5:1.5b日常，3b只在需要时切 | 省900MB |
| 不同时开多个Agent聊天 | 防内存叠加 |
| 任务管理器→ollama优先级设"低于正常" | 防系统卡顿 |

---

## 四、C盘清理

**当前：** C盘剩16GB（87%满）
**目标：** 清理到剩30GB+

```batch
:: 管理员CMD
cleanmgr /sagerun:1
Dism /Online /Cleanup-Image /StartComponentCleanup
:: 把下载/文档/桌面挪到D盘
```

---

## 五、不要做的事

- ❌ 装7B以上模型（8GB跑不动）
- ❌ 同时跑多个模型
- ❌ OLLAMA_GPU_LAYERS 设太高（MX150只有2GB显存）
- ❌ 禁用Windows页面文件
- ❌ 把模型放在C盘

---

## 六、一句话

> **量化模型 + Flash Attention + 关掉不用的程序 + 模型用完即释放 = 8GB笔记本也能流畅跑AI。**
