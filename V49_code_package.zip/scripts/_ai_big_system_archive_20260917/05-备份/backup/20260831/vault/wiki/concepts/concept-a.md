---
generation_complete: true
---

---

type: concept  
created: 2026-08-14  
updated: 2026-08-14  
sources: ["[[sources/第1天_学习记录_20260801_ba57fd]]"]  
tags: [theory]  

## Definition
Quantum entanglement is a phenomenon in quantum mechanics where two or more particles become physically connected. It allows their states to correlate regardless of distance, leading to effects that cannot be independently measured. This theory explains non-locality and shows how measurement in one part of a system influences another, a fundamental aspect of quantum theory.  

## Key Characteristics
- Non-locality  
- Correlation between entangled particles  
- Measurement-induced effects  

## Applications
- Quantum computing and quantum teleportation  
- Quantum information theory studies  
- Foundations of quantum field theory  

## Related Concepts
- [[theory/quantum-entanglement]]  

## Related Entities
- [[entities/ai-researcher]]  
- [[entities/ml-algorithm]]  

aliases: ["Quantum Entanglement Theory", "Quantum Entanglement"]