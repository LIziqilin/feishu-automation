# Wiki Index

> Auto-generated knowledge base directory

> Note: Text in backticks after page names shows aliases — alternative names, abbreviations, or translations.


## Entities

- [[entities/ai-model-x|ai-model-x]] `aliases: AI Researcher, Source File, Transformer` - AI Model X is an advanced machine learning model used in industry and academia. It is characterized 
- [[entities/data-scientists|data-scientists]] `aliases: AI Scientists, AI Researchers` - [Detailed description of the entity with bidirectional links]  
- [[entities/machine-learning-frameworks|machine-learning-frameworks]] - Machine Learning Frameworks are foundational tools used in research, development, and deployment. Th
- [[entities/climate-data-center|climate-data-center]] - *Note: The aliases field includes the primary display name for this entity, as no alternative names 
- [[entities/john-doe|john-doe]] `aliases: [Alternate name for the entity], Source File` - John Doe is a software engineer with expertise in artificial intelligence and data science, working 
- [[entities/startup-tech-co|startup-tech-co]] - Startup Tech Co. is a global technology firm specializing in research and development in machine lea
- [[entities/ai-research-institute|ai-research-institute]] - type: entity  
- [[entities/ml-algorithm|ml-algorithm]] - No summary
- [[entities/source-file|source-file]] `aliases: ["[Alternate name for the entity]"]  # Replace with a natural alternative like "Source File" or technical term` - No summary
- [[entities/ai-researcher|ai-researcher]] `aliases: AI Researcher, AI Scientist` - No summary

## Concepts

- [[concepts/predictive-analytics|predictive-analytics]] `aliases: AI Researcher, Transformers, NN` - No summary
- [[concepts/field|field]] - Cognitive science studies the underlying principles and structures of human thought and behavior.  
- [[concepts/method|method]] `aliases: ["[Alternate name for the entity]", "System-generated alias", "AI Researcher"]  # REQUIRED` - No summary
- [[concepts/standard|standard]] `aliases: AI Researcher, AI System Standardizer` - No summary
- [[concepts/theory|theory]] - AI theory refers to foundational theories that provide the framework for understanding and building 
- [[concepts/concept-a|concept-a]] - type: concept  

## Sources

- [[sources/第1天_学习记录_20260801_ba57fd|第1天_学习记录_20260801_ba57fd]]
