---

**type: entity**  
created: 2026-08-14  
updated: 2026-08-14  
sources: ["[[sources/第1天_学习记录_20260801_ba57fd]]"]
tags: [person]  

aliases: ["AI Researcher", "AI Scientist"]  

## Description
An AI Researcher is a person involved in AI research and development.  

## Related Entities
[]  

## Related Concepts
[]  

generation_complete: true
---