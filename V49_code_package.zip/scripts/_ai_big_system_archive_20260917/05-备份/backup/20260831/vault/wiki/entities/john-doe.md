---

type: entity  
created: 2026-08-14  
updated: 2026-08-14  
sources: ["[[sources/第1天_学习记录_20260801_ba57fd]]"]
tags: [person]  

aliases: ["[Alternate name for the entity]", "Source File"]  

generation_complete: true
---  

## Description
John Doe is a software engineer with expertise in artificial intelligence and data science, working for a tech startup.  

## Related Entities
[[entities/ai-research-institute|ai-research-institute]]  

## Related Concepts
[[concepts/ml-algorithm|ml-algorithm]]  

---  

# John Doe  

## Description
[Detailed description of the entity with bidirectional links]  

## Related Entities
[[entities/ai-researcher|ai-researcher]]  

## Related Concepts
[[concepts/ai-research-institute|ai-research-institute]]  

---  

**Mentions in Source**  
- "Transformer" (example) – [[concepts/ai-researcher|ai-researcher]]  
- "Neural Network" – [[concepts/ai-research-institute|ai-research-institute]]  

**Note**: Aliases include "Source File" and "ai-researcher" to maintain consistency in terminology.