# 📊 评估：WorkBuddy 接入本地飞书的可行性

> 生成：2026-08-19 · 标签：#技术笔记库 #WorkBuddy #飞书 #可行性评估

## 一、结论：高度可行 ✅

"本地飞书"（飞书桌面客户端 + 个人账号）接入 WorkBuddy **技术路径清晰、现实基础齐备、可行性高**。

## 二、现实基础（已核查）
| 项 | 状态 |
|:--|:--|
| 飞书桌面端 | ✅ 运行中（9进程，已登录个人账号）|
| node + npm | ✅ v22.23.1 + 10.9.8 |
| WorkBuddy 飞书 connector | ✅ 官方提供（installed in marketplace）|
| 飞书开放平台 | ✅ 需个人/企业OAuth授权（open.feishu.cn）|
| Hermes 原生飞书 | ✅ 支持（feishu/feishu_doc/feishu_drive工具集）|
| lark-cli | ❌ 未装（可 `npm i -g @larksuite/cli`）|

## 三、接入方式（WorkBuddy官方方案）
1. `npm install -g @larksuite/cli`
2. `lark-cli config init`（配置）
3. `lark-cli auth login --recommend`（OAuth 授权个人飞书账号，浏览器扫码）
4. WorkBuddy 加载 feishu connector，即可让 Agent 调用飞书能力

**注意**：此方案连的是**飞书官方云开放平台(open.feishu.cn)**，操作的是飞书云端的文档/表格/知识库（通过你本地登录的账号授权）。**不是飞书私有化本地服务器**。若"本地飞书"指私有化部署，需额外确认私有化API地址。

## 四、接入后能力（20+ skills）
- **lark-doc** 文档读写/创建/思维笔记
- **lark-sheets** 电子表格
- **lark-base** 多维表格(Bitable) — 适合结构化知识
- **lark-drive** 云盘文件
- **lark-wiki** 飞书知识库
- **lark-im** 消息收发（替代微信桥接，更稳）
- **lark-calendar** 日历 / **lark-task** 任务 / **lark-note** 笔记
- **lark-approval** 审批 / **lark-attendance** 考勤 / **lark-contact** 通讯录
- **lark-slides** 幻灯片 / **lark-mail** 邮件 / ...

## 五、价值场景（对你）
1. **消息推送增强**：用 lark-im 替代当前微信桥接（飞书IM更稳定、支持机器人）
2. **知识库对接**：飞书wiki/多维表格 可与 finished Brain 双向同步
3. **文档自动化**：工程总监学习产出可写入飞书文档/表格
4. **日程/任务**：飞书日历、任务管理接入 agent 每日巡检
5. **审批流**：若用于工作，可接入飞书审批

## 六、成本与风险
| 维度 | 评估 |
|:--|:--|
| 成本 | OAuth免费；API按飞书开放平台规则（个人版免费额度）|
| 授权风险 | 需扫码授权读个人飞书数据（可控，可撤销）|
| 兼容性 | lark-cli 需 node≥18（满足）；技能成熟（官方维护）|
| 网络 | 连飞书云端，需联网（网关18:00后规则不适用，属API调用）|
| "本地"限制 | 若要求纯离线/私有化，需飞书私有化服务地址（一般用户用不到）|

## 七、建议执行路径
- **若你指"本地个人飞书客户端+云端API"** → 直接按第三部分三步骤接入，我协助安装授权，优先启用 lark-im（替代微信）和 lark-doc/base（知识协作）
- **若你确指"飞书私有化本地部署"** → 需提供私有化API的 app_id/域名，我再评估

## 八、附注
- WorkBuddy connectors-marketplace 已含 feishu connector，无需额外购买
- Hermes 7个agent的 `feishu_doc/feishu_drive` 当前在 `disabled_toolsets`（未启用）——接入后可选择性启用
