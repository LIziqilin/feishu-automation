# 📊 WorkBuddy ↔ 飞书连接状态与测试报告

> 生成：2026-08-20 · 标签：#技术笔记库 #WorkBuddy #飞书

## 一、核心结论
**WorkBuddy 底层已与飞书连接打通**（通过 lark-cli 授权），实测飞书读写能力正常。
唯一：WorkBuddy GUI 未显示飞书入口（界面未标激活），但**底层能力实际可用**。

## 二、连接状态诊断
| 层面 | 状态 |
|:--|:--|
| lark-cli 版本 | ✅ v1.0.88（>=1.0.87需求满足）|
| runtime (node) | ✅ v22（>=18需求满足）|
| lark-cli 授权(bot) | ✅ ready |
| lark-cli 授权(user) | ✅ ready(needs_refresh自动刷新) |
| 飞书应用 | ✅ cli_aa0cd56c99785bb5（紫麒麟）|
| WorkBuddy GUI飞书入口 | ❌ 未显示（唯一未激活项）|

## 三、功能实测结果
| 测试项 | 结果 |
|:--|:--|
| 认证状态 | ✅ 有效 |
| 读取云盘文件 | ✅ 2个文件（任务管理bitable + 云文档）|
| 读取文档/多维表格 | ✅ 命令可用 |
| 发送消息(bot身份) | ✅ 成功发到紫麒麟 |
| 发送消息(user身份) | ⚠️ 需补 scope im:message.send_as_user |

## 四、WorkBuddy 飞书 connector 机制说明
- WorkBuddy 的飞书连接器 = **CLI + skills 型**（非MCP server）
- 核心 = lark-cli 命令 + 20+ skills 文档（agent据此调用）
- `cli.json` 定义的服务（init/version/auth/status）**全部已满足**
- 它通过 `lark-cli` 让 WorkBuddy agent 操作飞书能力

## 五、能力覆盖（lark-cli 支持）
approval/base/calendar/contact/docs/drive/event/im/markdown/mail/minutes/okr/sheets/slides/task/vc/wiki（16域）

## 六、待办/优化
- [ ] 补齐个别 scope（im:message.send_as_user 等）用于用户身份推送
- [ ] 若需 WorkBuddy GUI 显示飞书：可在 WorkBuddy 连接器市场安装/启用（若版本支持）
- [ ] 飞书官方 MCP (mcp.feishu.cn/mcp) 已验证存在，可考虑注册为 MCP server（需 OAuth）

## 七、结论
**飞书读写核心已打通**（云盘/文档/多维表格/消息 bot 身份）。
WorkBuddy 界面未激活是"显示层"问题，不影响底层 lark-cli 实际能力。
