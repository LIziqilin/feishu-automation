# ⚡ Hermes token 用量分析与优化方案
> 生成：2026-08-19 · 标签：#技术笔记库 #token优化 #Hermes

## 一、为什么 token 用量大（根因分析）

### 1. 每请求固定开销约 7000-8000 token
- 各 agent 系统提示(SOUL.md) 700-1700 token×每次请求
- **tool_search 工具列表最高 6553 token** × 每次请求
- → 即使一句话，每个 agent 每次调用也消耗 ~8000 token

### 2. 上下文累积（最大消耗源）
- **主 Hermes 总 session 10.5MB**、agent6_scheduler 3.5MB
- 长会话(history=171条) → 每次请求带回全部历史 → **token 随对话线性暴涨**
- 实测单次请求最高 **17,819 token**（estimated_request_tokens）

### 3. cron 高频唤醒重复消耗
- 「工程总监学习哨兵」每30分钟×已完成 **107次** → 每次唤醒若 agent 响应则消耗完整上下文

### 4. 多 agent 复制累计
- 7 个 agent 各自保留独立 session & 系统提示

## 二、当前成本（实测余额：DeepSeek 9.98元）
- 模型 deepseek-v4-flash（输入0.14/输出0.28 元/百万token）
- 若每天消耗约 50万 token 总处理量 ≈ 0.2元/天 ≈ 6元/月（可控但可优化）

## 三、优化方案（按性价比排序）

### ✅ 立即可做（低风险，我已完成部分）
1. **已关思考**：所有 agent + AnythingLLM 关闭思考 → 省 30%+ 输出token
2. **清理大 session**：归档/精简 10.5MB 主 session + 3.5MB agent6 session
3. **修正废弃路径**（已完成）：避免 agent 因路径错误重复检索

### 🟡 中优先级（建议）
4. **降低工具列表(token数量)**：为高频 agent 裁剪不需要的 toolset（`disabled_toolsets` 已配置但可优化）
5. **精简系统提示**：各 agent 的 SOUL.md（当前4108字节agent1）可精简到关键规则
6. **上下文管理**：短会话及时归档；长会话压缩(auxiliary compression 已配 deepseek-v4-flash)

### 🔴 需权衡（可能影响功能）
7. **降低 cron 哨兵频率**：`工程总监 sentinel` 从每30分钟→每2小时（它已完成107次，可能过高）
8. **合并 agent**：若某些 agent 少用，可停用其 gateway

## 四、预期效果
- 仅做 1-3 项即可省 **40-50% token**
- 做全 1-7 项可省 **70%+**

## 五、注意
- 余额仅 9.98元，建议关注用量
- 深思考任务(agent2思维)如需要可单独保留思考
