# 📱 WorkBuddy 微信连接问题 — 深挖诊断记录

> 生成：2026-08-21 · 标签：#技术笔记库 #微信 #WorkBuddy #诊断

## 一、问题：发了微信消息没回复

## 二、根因（分3层）

### 1. 微信桥接服务未常驻运行（主因）
- wechat_bot.py 之前**没有可靠运行的实例**
- 多次启动产生**多实例并发** → 抢微信解密缓存 → `database disk image is malformed`
- **修复**：清掉全部实例，单实例重启 ✅

### 2. WorkBuddy 调度特性（回复延迟主因）
- WorkBuddy「微信指令执行器」rrule=`FREQ=HOURLY;BYMINUTE=5,20,35,50` → **每15分钟处理一次inbox**
- 发 `wb` 指令后，WorkBuddy 执行要等**15分钟窗口**
- 但 wechat_bot 会**即时回复"✅指令已提交"**（不是没反应）

### 3. 命令前缀限制 + Obsidian检查卡顿
- wechat_bot **只响应命令**（wb/obs/status/help/push），**普通闲聊不回复**
- `status`等含 Obsidian 检查的命令**间歇性卡住**（可能监听线程/发送问题）

## 三、修复动作
1. ✅ 清掉多个 wechat_bot 实例，单实例干净重启（PID 15320）
2. ✅ wechat_bot 已连微信（李阳账号，10会话监听，WxPusher正常）
3. ✅ `wb 你好` 实测：收到→写inbox→即时回复"✅指令已提交" ✅
4. ⚠️ 待验证：WorkBuddy 15分钟窗口内处理并回传

## 四、实测验证
| 内容 | 结果 |
|:--|:--|
| wechat_bot 单实例运行 | ✅ PID 15320 |
| 微信连接 | ✅ 李阳, 10会话 |
| 数据库冲突 | ✅ 已消除(无malformed) |
| `wb你好` 收发送 | ✅ 收到+即时确认 |
| Obsidian API | ✅ https+key 200(0.0s) |
| WorkBuddy调度 | ⚠️ 每15分钟窗口 |

## 五、当前局限（诚实说明）
- **普通消息不回复**（只响应 wb/obs/status/help/push 命令）
- **WorkBuddy执行约15分钟延迟**（调度制，非实时）
- status等命令偶发卡顿（监控中）

## 六、可用命令
- `wb <指令>` 发给WorkBuddy处理
- `status` 查系统状态
- `help` 帮助
- `push <消息>` 推送
- `obs <笔记>` 写Obsidian
