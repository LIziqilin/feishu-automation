# ⚡ Hermes token 优化执行记录
> 生成：2026-08-19 · 标签：#技术笔记库 #token优化 #Hermes

## 一、已执行优化（8项全完成）

### ✅ 1. 关闭思考（含 agent2）
- 7/7 个 agent 全部 `reasoning_effort: none`（含思维老师agent2）
- AnythingLLM 深度代理(3002)注入关思考
- → 省 30%+ 输出token

### ✅ 2. 清理大 session
- 历史 request_dump_*.json 从 **16MB → 972KB**
- 76个大文件归档到 `D:\AI\session_backup_20260819`（15MB，可回滚）
- 保留今天的活跃会话，不影响进行中对话

### ✅ 3/4. 修正路径 + 工具裁剪
- 7个agent的OBSIDIAN_VAULT_PATH已修正(完成版→finished Brain)
- 各agent已禁用12-16个不用工具集(browser/discord/feishu/image_gen等)

### ✅ 5. 精简 agent1 SOUL.md
- 4108 → **1601 字节**（省 61%）
- 每请求省约 **835 token**
- 保留核心职责/权限/流程/skill指针

### ✅ 6. 上下文管理
- agent2-7 已配 `compression: deepseek/deepseek-v4-flash`
- agent1 用 `auto`(Hermes自动,安全默认)，未强行改security-sensitive config

### ✅ 7. 关闭工程总监 cron 哨兵
- sentinel(每30分钟×已完成107次) 已 **pause**
- 改为手动触发：`D:\AI\my work\元宝遥控器配置\触发工程总监任务.bat`
- 手动触发命令：`hermes -p agent6_scheduler cron run 6f8d2cca7803`

## 二、预计效果
- 思考关闭：省30%+
- SOUL精简：省每请求835 token
- session清理/路径修正：避免无效检索+历史膨胀
- sentinel停用：消除每30分钟×107次的重复唤醒
- **综合估计省 50-70% token**

## 三、系统状态
- 内存 3.1GB ✅、代理3002✅、AnythingLLM 3001✅
- DeepSeek 余额 9.98元
- agent6 cron 7任务中仅 sentinel暂停(手动)，其余正常

## 四、注意
- 工程总监任务卡现在需手动触发（bat 或 cron run）
- 每日19:30 + 每周六19:00 的知识库巡检推送微信仍正常运行
- agent1 的 compression=auto 由Hermes自动管理（安全）
