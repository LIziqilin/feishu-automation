# 🪶 AnythingLLM 接入飞书「Anything LLM助手」完成记录

> 生成：2026-08-21 · 标签：#技术笔记库 #飞书 #AnythingLLM

## 一、成果
**本地 AnythingLLM 已接入飞书应用「Anything LLM助手」，端到端验证通过！**

## 二、实现方式
- **桥接脚本**：`D:\AI-Tools\feishuSDK\oapi-sdk-python-demo-main\quick_start\robot\anyllm_bridge.py`
- **原理**：飞书长连接(websocket)接收消息 → 调本地 AnythingLLM API(基于Obsidian知识库回答) → 回复到飞书

## 三、配置
| 项 | 值 |
|:--|:--|
| 飞书应用 | 「Anything LLM助手」 cli_aa0d9ed52338dbd1 |
| AnythingLLM API | http://127.0.0.1:3001（数据库读key）|
| 工作区 | 「我的第二大脑 obsidian」(16c94976-...) |
| 运行方式 | `python anyllm_bridge.py` |

## 四、前置依赖
- **AnythingLLM 运行**(3001) ✅
- **Ollama 运行**(11434，嵌入引擎) ✅ 已后台启动
- 飞书应用事件订阅(长连接+接收消息) ✅ 已配置
- 应用已发布 ✅

## 五、端到端验证
```
飞书发"你好" → 桥接[收到] → 调AnythingLLM(基于知识库) → [发送]成功✅ → 回复到飞书
```
实测：收到并回复多条消息，Everything正常。

## 六、测试的对话示例
- 问"用一句话介绍你" → AnythingLLM答："我是基于仓颉2.0知识精馏体系构建的AI助手，专长于工程管理、设备全生命周期成本分析及消防/电梯等系统运维合规问题..."

## 七、说明/待办
- 桥接脚本当前以**后台进程**运行（proc_7d5842a99364）
- **开机自启**未配置(可选后续做成启动任务)
- 如需切换工作区，改 `A_WORKSPACE` 变量(四个工作区可用:2/3/4/5)
