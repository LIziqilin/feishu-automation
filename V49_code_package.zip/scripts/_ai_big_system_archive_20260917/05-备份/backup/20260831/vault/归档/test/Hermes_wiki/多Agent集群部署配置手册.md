---
title: 多Agent集群部署配置手册
tags: [Hermes, Ollama, 部署, 配置, 7Agent]
date: 2026-07-31
---

# 多Agent集群部署配置手册

> 硬件：i5-8250U · 8GB RAM · MX150 2GB
> 本次优化由 Agent6 调度总监于 2026-07-31 执行

## 一、Agent模型分配总表

| Agent | 角色 | 主模型 | 提供方 | Fallback | 备注 |
|:--|:--|:--|:--|:--|:--|
| agent1_business | 商业老师 | qwen2.5:3b | ollama | qwen2.5:1.5b | 推理重，保留3b |
| agent2_thinking | 思维老师 | qwen2.5:3b | ollama | deepseek-r1:1.5b | 推理重，保留3b |
| agent3_tech | 技术专家 | qwen2.5:3b | ollama | qwen2.5:1.5b | 代码质量，保留3b |
| agent4_office | 职场高手 | qwen2.5:1.5b | ollama | deepseek-r1:1.5b | 任务轻，降1.5b省内存 |
| agent5_vault_manager | 知识库管家 | qwen2.5:1.5b | ollama | deepseek-r1:1.5b | 文件操作，降1.5b |
| agent6_scheduler | 调度总监 | qwen2.5:7b | ollama | deepseek-v4-pro | 用户指定7b，质量优先 |
| agent7_media_parser | 多媒体拆解师 | deepseek-v4-flash | deepseek云端 | qwen2.5:3b | 云端主力，本地降级 |

## 二、统一配置规范（Hermes硬性要求）

```yaml
model:
  context_length: 65536   # 必须 ≥64000，Hermes校验
  ollama_num_ctx: 65536   # 必须 ≥64000，Hermes工具调用校验
  # 低于64K会导致初始化失败: "Ollama runtime context is too small for Hermes tool use"
```

## 三、Ollama内存优化（8GB关键）

```batch
setx OLLAMA_FLASH_ATTENTION 1        :: 省20-30%显存
setx OLLAMA_KEEP_ALIVE 1m            :: 空闲1分钟卸载（防内存耗尽）
setx OLLAMA_GPU_LAYERS 8             :: MX150分担8层
setx OLLAMA_NUM_PARALLEL 1           :: 一次一个请求
setx OLLAMA_MAX_LOADED_MODELS 1      :: 同一时间仅1个模型
setx MALLOC_ARENA_MAX 2              :: 减少内存碎片
```

> ⚠️ KEEP_ALIVE=1m导致7b频繁冷加载（每次约220秒）。
> 对策：agent6调用时显式传 `keep_alive: "10m"` 保持驻留。

## 四、AnythingLLM（只查询）

- 端口：3001 | API Key：hermes-agent（SQLite中）
- 向量库：lancedb | Embedding：nomic-embed-text（本地）
- 回答模型：qwen2.5:3b（本地）
- **避免重复储存**：hotdir保持为空，禁止投递文件副本
- 文档只从Obsidian主仓库（D:\AI\完成版知识库）读入
- ⚠️ 已知问题：API上传的中文文档在lancedb检索召回异常（待人工复核，GUI中删除重加可修复）

## 五、Hermes wiki ↔ Obsidian共享

- 物理目录：`D:\AI\Hermes_wiki`（Hermes侧写入）
- Junction：`D:\AI\完成版知识库\Hermes_wiki` → `D:\AI\Hermes_wiki`
- 环境变量：`OBSIDIAN_VAULT_PATH=D:\AI\完成版知识库`（已写入所有agent .env）
- 双向读写已验证

## 六、本地HTTP链路

- 所有agent base_url：`http://127.0.0.1:11434/v1`
- AnythingLLM：`http://127.0.0.1:11434`
- 无需外网即可完成全部本地推理

## 七、密钥管理

- agent7（deepseek）：`.env` 需要 `DEEPSEEK_API_KEY`（不是HERMES_CUSTOM_DEEPSEEK_API_KEY）
- agent6 fallback同样需要
- Ollama无需密钥（key_env: HERMES_CUSTOM_OLLAMA_API_KEY 占位即可）
